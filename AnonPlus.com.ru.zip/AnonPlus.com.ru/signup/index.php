<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 
 if ($user) header ('Location: '.HTTP.'/uid'.$user['id']);

 if (isset ($_POST['signup'])) {

    $login = Core::check ($_POST['signup_login']);
    $pass = Core::check ($_POST['signup_password']);
    $sex = intval(abs ($_POST['signup_sex']));
    $sex = ($sex > 1 or $sex < 0) ? 0 : $sex;

    if (empty ($login)) { 
      $log_login = '<br /><small><font color = "darkred">Введите Ник!</font></small>';
      $ok = false;
    }
    else $ok = true;

    if (empty ($pass)) {
      $log_pass = '<br /><small><font color = "darkred">Введите пароль!</font></small>';
      $ok2 = false;
    }
    else $ok2 = true;

    if ($ok == true) {

      $login_query = $DB -> query ("SELECT * FROM `users` WHERE `login` = ".$DB -> quote ($login)."");
      if ($login_query -> RowCount () > 0) Core::redirect ("Этот ник уже зарегистрирован!", HTTP."/signup/");
      else $ok3 = true;

    } 

    if ($ok == true and $ok3 == true) {

      if (!preg_match('|^[a-z0-9\-]+$|i', $login)) {
        $log_login = '<br /><small><font color = "darkred">Ник должен содержать только буквы английского алфавита, а так-же цыфры!</font></small>';
        $ok4 = false;
      }
      else $ok4 = true;
    }

    if ($ok4==true) {

      if (strlen ($login)<3 || strlen ($login)>15) {
      $log_login = '<br /><small><font color = "darkred">Ник должен быть не меньше 3 и не больше 15 символов!</font></small>';
      $ok5 = false;
      }
      else $ok5 = true;

    }

    if ($ok2 == true) {

      if (strlen ($pass)<6 || strlen ($pass)>30) {
        $log_pass = '<br /><small><font color = "darkred">Пароль должен быть не меньше 6 и не больше 30 символов!</font></small>';
        $ok6 = false;
      }
      else $ok6 = true;
    
    }

     if ($ok5 == true and $ok6 == true) {
        
         ## Генерируем USID
         $USID = md5 (time ().$login);

         ## Отделяем CK в USID
         $CK = mt_rand(1000,9999);

         ## Генерируем автозакладку
         $tm = sha1 (mt_rand(00000,99999).mt_rand(00000,99999));

         ## Генерием tc
         $tc = mt_rand(1111, 9999);

         $DB -> query ("INSERT INTO `users` SET
                                    `login` = ".$DB -> quote ($login).",
                                    `password` = ".$DB -> quote ($pass).",
                                    `tm` = '".$tm."',
                                    `tc` = '".$tc."',
                                    `usid` = ".$DB -> quote ($USID).",
                                    `CK` = '".$CK."',
                                    `data_registration` = '".time ()."',
                                    `sex` = '".$sex."'");

         ## Находим юзера с таким логином и паролем
         $data = $DB -> query ("SELECT `tm` FROM `users` WHERE `login` = ".$DB -> quote ($login)." LIMIT 1") -> fetch ();

         setcookie('UID', $data['id'], time()+86400*24, '/');
         setcookie('USID', $USID, time()+86400*24, '/');

         Core::redirect_ok ("hello ".$data['login']."", HTTP."/");

         header ('Location: '.HTTP.'/tm/'.$data['tm']);

    }
 }

 $description = 'Регистрация на '.DOMAIN;
 $keywords = NULL;
 $title = 'Регистрация';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Регистрация

         </div>
 ';

 echo $ERR_AUTH;

 echo '

         <form action = "" method = "POST">

             <div class = "block">

                 Ник: <br />
                 <input type = "text" name = "signup_login" value = "">
                 '.$log_login.'
             

             </div>
         
             <div class = "block">

                 Пол: <br />
                 <input type="radio" name="signup_sex" value="0" checked="checked" /> <font color = "#066">Мужской</font> <br />   
                 <input type="radio" name="signup_sex" value="1"/> <font color = "#79358C">Женский</font> <br />

             </div>
         
             <div class = "block">

                 Пароль: <br />
                 <input type = "text" name = "signup_password"> 
                 '.$log_pass.'

             </div>

             <div class = "block">  

                 <input type = "submit" name = "signup" value = "Продолжить">

             </div>

         </form>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Регистрация

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>