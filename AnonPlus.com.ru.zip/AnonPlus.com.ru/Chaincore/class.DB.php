<?php
 ob_start ();
 session_start ();
 error_reporting(0);

 Define ('HTTP', 'http://ruswap.ru');
 Define ('ROOT', $_SERVER['DOCUMENT_ROOT'].'/');
 Define ('DOMAIN', 'ruswap.ru');
 Define ('SITE_NAME', 'Ruswap');

 $err_log = (isset ($_SESSION['err'])) ? $_SESSION['err'] : '';
 $ok_log = (isset ($_SESSION['ok'])) ? $_SESSION['ok'] : '';

 Define ('ERROR', $err_log);
 Define ('OK', $ok_log); 

 require_once ROOT.'/Chaincore/incfiles/conf.php';

 require_once ROOT.'/Chaincore/includes/pdo.class.php';

 require_once ROOT.'/Chaincore/includes/core.class.php';

 require_once ROOT.'/Chaincore/includes/user.class.php';

 require_once ROOT.'/Chaincore/incfiles/cookie.php';

 require_once ROOT.'/Chaincore/incfiles/auth_log.php';

 function Autoload($class_name) { 
 @include_once (ROOT.'/Chaincore/includes/'.strtolower($class_name).'.class.php'); 
 } 
 spl_autoload_register('Autoload'); 


 if ($user) {

     require_once ROOT.'/Chaincore/incfiles/rating.php';
     $diff = time() - $user['online'];
     if($diff <= 180){
         $new_online_time = $user['online_time'] + $diff;
         $queryOnlineUser = $DB -> query ("UPDATE `users` SET `online_time` = '".$new_online_time."' WHERE `id` = '".$user['id']."'");
     }
     $queryOnlineUser = $DB -> query ("UPDATE `users` SET `online` = '".time()."' WHERE `id` = '".$user['id']."'");
     $queryOnlineUser = $DB -> query ("UPDATE `friends` SET `online` = '".time()."' WHERE `friend_id` = '".$user['id']."'");
     
     $rand = mt_rand(0,50);
     if($rand == 0){
         $rand_m = mt_rand(5,10);
         $_SESSION['ok'] = "Поздравляем! Ты получил ".$rand_m." халявных монеток. Потратить их можно на подарки пользователям или другие платные услуги.";
         $user['coins']+=$rand_m;
         $DB->query("UPDATE users SET coins=".$user['coins']." WHERE id=".$user['id']);
     }
     
   }

 Define ('GEN', microtime(1)); 


?> 