<?php
 $queryRating = $DB -> query ("SELECT `time` FROM `rating_log` WHERE `user_id` = '".$user['id']."' ORDER BY `id` DESC LIMIT 1");

 if ($queryRating -> RowCount () < 1) $DB -> query ("INSERT INTO `rating_log` SET `user_id` = '".$user['id']."', `rating` = '0.1', `time` = '".time ()."'");
 $rating = $queryRating -> fetch ();

 if ($rating['time'] < time () -18000) {

     $min = 0;
     $max = 0.4;
     $rand = (float) Core::CropStr (($min + mt_rand() / mt_getrandmax() * ($max - $min)), 3);

     $DB -> query ("UPDATE `users` SET `rating` = `rating` + '".$rand."' WHERE `id` = '".$user['id']."'");
     $DB -> query ("UPDATE `rating_log` SET `rating` = '".$rand."', `time` = '".time ()."' WHERE `user_id` = '".$user['id']."'");

 }

?>