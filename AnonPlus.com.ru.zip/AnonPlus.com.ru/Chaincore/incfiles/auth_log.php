<?php

 if ($user) {

     $auth = $DB -> query ("SELECT * FROM `history_auth` WHERE `user_id` = '".$user['id']."' ORDER BY `id` DESC LIMIT 1") -> fetch ();

     if ($auth['ua'] != $_SERVER['HTTP_USER_AGENT']) {

     	$UA = Core::check ($_SERVER['HTTP_USER_AGENT']);
     	$IP = Core::check ($_SERVER['REMOTE_ADDR']);

        $rand1 = mt_rand(1111, 9999);
        $rand2 = mt_rand(1111, 9999);
        $accessHash = (!empty ($user['email'])) ? sha1($rand1.$rand2) : NULL;

     	$DB -> query ("INSERT INTO `history_auth` SET `user_id` = '".$user['id']."', `ip` = ".$DB -> quote ($IP).", `ua` = ".$DB -> quote ($UA).", `time` = '".time ()."', `status` = '".(!empty ($user['email']) ? '0' : '0')."', `hash` = '".(!empty ($user['email']) ? $accessHash : '')."'");
  
        // if ($auth['status'] == 1) mail($user['email'], 'Безопасность вашего аккаунта может быто под угрозой!', 'Здравствуйте, <b>'.$user['login'].'</b> \n На вашем аакаунте были замечены подозрительные действия, возможно вам хотели взломать! Введите этот код на '.DOMAIN.':  \n <b>'.$accessHash.'</b> \n Или перейдите по этой ссылке: <a href = "'.HTTP.'/?code='.$accessHash.'">'.DOMAIN.'/?code='.$accessHash.'</a> \n С ув. администрация <a href = "'.HTTP.'">'.DOMAIN.'</a>');

     }

 }



?>