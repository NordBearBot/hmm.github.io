<?php

 if (isset($_COOKIE['UID']) and isset($_COOKIE['USID'])) {
 
	 $uid = Core::check($_COOKIE['UID']);
	 $usid = Core::check($_COOKIE['USID']);
	
	 $query = $DB -> prepare ("SELECT * FROM `users` WHERE `id` = ? and `usid` = ? LIMIT 1");
     $query -> execute (array($uid, $usid));
	 $query -> RowCount();
	
     if ($query > 0) $user = $query -> fetch();
	
     if ($user['id'] != $uid or $user['usid'] != $usid) {
	
         setcookie('UID', '', -1, '/');
         setcookie('USID', '', -1, '/');
         session_destroy();
		 
     }
	
 }

?>