<?php

 $conf = array (
    
    "user_online"  => time () -300,

    "spam_blog" => time () -60,

    "spam_comment" => time () -120,

    "spam_files" => time () -120,

    "edit_comment" => time () -180

 );

?>