<?php

 $conf = array (
    
    "user_time"  => time () -300,

    "spam_blog" => time () -60,

    "spam_comment" => time () -120,

    "spam_files" => time () -120,

    "chat_online" => time () -60

 );

?>