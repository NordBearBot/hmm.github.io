<?php
 class User {

 public static function friend ($user_id, $friend_id) {

     global $DB;

     $user_id = (int) abs ($user_id);
     $friend_id = (int) abs ($friend_id);

     $queryFriend = $DB -> query ("SELECT `id` FROM `friends` WHERE `user_id` = '".$user_id."' AND `friend_id` = '".$friend_id."'") -> RowCount ();

     if ($queryFriend < 1) return false;
     else return true;

 }

 public static function journal_add ($user_id, $reply_id, $message, $type, $url) {

     global $DB;

     $user_id = (int) abs ($user_id);
     $reply_id = (int) abs ($reply_id);

     $queryAddJournal = $DB -> query ("INSERT INTO `journal` SET 
     	               `user_id` = '".$user_id."',
     	               `reply_id` = '".$reply_id."',
     	               `message` = ".$DB -> quote ($message).",
     	               `time` = '".time ()."',
     	               `type` = '".$type."',
     	               `url` = '".$url."'");

 }

 public static function journal_update ($journal_id, $user_id) {

 	global $DB;
    
    $journal_id = (int) abs ($journal_id);

 	$queryTestJournal = $DB -> query ("SELECT `id` FROM `journal` WHERE `id` = '".$journal_id."' AND `reply_id` = '".$user_id."'");

 	if ($queryTestJournal -> RowCount () > 0) $DB -> query ("UPDATE `journal` SET `act` = '0' WHERE `id` = '".$journal_id."'");
 
 }

 public static function avatar ($id, $size, $type = NULL, $style = NULL) {
     
     global $DB;
     $id = intval ( abs ($id));
     $mini = ($type == 'mini' ? 'style = "-webkit-border-radius: 20px;-khtml-border-radius: 20px;border-radius: 20px; '.($style != NULL ? 'width: 32px;' : 'width: 35px;').'"' : NULL);

     $ank = $DB -> query ("SELECT `avatar` FROM `users` WHERE `id` = '".$id."'") -> fetch ();
     if ($ank['avatar'] == 0) return '<img class = "photo" '.$mini.' src = "'.HTTP.'/files/system.images/user.default.avatar/'.$size.'/default.png" />';
     else {

         $data = $DB -> query ("SELECT `pic_id`, `pic_key`, `pic_folder`, `pic_type`, `user_id` FROM `users_avatar` WHERE `user_id` = '".$id."' ORDER BY `id` DESC LIMIT 1") -> fetch ();
         return '<!-- <a href = "'.HTTP.'/uid'.$data['user_id'].'/pictures/?folder='.$data['pic_folder'].'&pic='.$data['pic_id'].'"> --> <img class = "photo" '.$mini.' src = "'.HTTP.'/files/user.files/pictures/'.$size.'/photo'.$data['pic_id'].'_'.$data['pic_key'].'.'.$data['pic_type'].'" /> <!-- </a> -->';

     }

 }

}

?> 