<?php

class device {

public static function mobile() {

$mobile_ua = strtolower(substr($_SERVER['HTTP_USER_AGENT'], 0, 4));

$mobile_agents = array(
'w3c ','acs-','alav','alca','amoi','audi','avan','benq','bird','blac',
'blaz','brew','cell','cldc','cmd-','dang','doco','eric','hipt','inno',
'ipaq','java','jigs','kddi','keji','leno','lg-c','lg-d','lg-g','lge-',
'maui','maxo','midp','mits','mmef','mobi','mot-','moto','mwbp','nec-',
'newt','noki','oper','palm','pana','pant','phil','play','port','prox',
'qwap','sage','sams','sany','sch-','sec-','send','seri','sgh-','shar',
'sie-','siem','smal','smar','sony','sph-','symb','t-mo','teli','tim-',
'tosh','tsm-','upg1','upsi','vk-v','voda','wap-','wapa','wapi','wapp',
'wapr','webc','winw','winw','xda ','xda-');

if (preg_match('/(up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone|android)/i', strtolower($_SERVER['HTTP_USER_AGENT']))) {
return true;
}
else if ((strpos(strtolower($_SERVER['HTTP_ACCEPT']),'application/vnd.wap.xhtml+xml') > 0) or ((isset($_SERVER['HTTP_X_WAP_PROFILE']) or isset($_SERVER['HTTP_PROFILE'])))) {
return true;
}
else if (strpos(strtolower($_SERVER['ALL_HTTP']),'OperaMini') > 0) {
return true;
}
else if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']),'macintosh') > 0) {
return false;
}
else if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']),'linux') > 0) {
return false;
}
else if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']),'windows') > 0) {
return false;
} 
else if (in_array($mobile_ua,$mobile_agents)) {
return true;
}
else {
return true;
}
}

 public static function browser($agent) {

     preg_match("/(MSIE|Opera|Firefox|Chrome|Version|Opera Mini|Netscape|Konqueror|SeaMonkey|Camino|Minefield|Iceweasel|K-Meleon|Maxthon)(?:\/| )([0-9.]+)/", $agent, $browser_info);
     
     list(,$browser,$version) = $browser_info;

     if ($browser == 'MSIE') return 'IE '.$version;
     
     if ($browser == 'Firefox') {

         ## проверяем, не разработка ли это на основе Firefox
         preg_match("/(Flock|Navigator|Epiphany)\/([0-9.]+)/", $agent, $ff);
         if ($ff) return $ff[1].' '.$ff[2];

     }

     if ($browser == 'Opera' && $version == '9.80') return 'Opera '.substr($agent,-5);
     if ($browser == 'Version') return 'Safari '.$version;
     if (!$browser && strpos($agent, 'Gecko')) return 'Browser based on Gecko';
     return $browser.' '.$version;

 }

}

?>