<?php
 class Core {

      public static function check($msg) {

         if (is_array($msg)) {
             foreach($msg as $key => $val) {
                 $msg[$key] = self::check($val);
             }
         } else {
             $msg = htmlspecialchars($msg);
             $search = array(' ','|', '\'', '$', '\\', '^', '%', '`', "\0", "\x00", "\x1A", chr(226) . chr(128) . chr(174));
             $replace = array(' ','&#124;', '&#39;', '&#36;', '&#92;', '&#94;', '&#37;', '&#96;', '', '', '', '');
             $msg = str_replace($search, $replace, $msg);
             $msg = stripslashes(trim($msg));

             $msg = preg_replace("/ +/", " ", $msg);
             $msg = preg_replace("/(\r\n){3,}/", "\r\n\r\n", $msg);

             $msg = str_replace('javascript', 'javasсript', $msg);
             $msg = str_replace('script', 'sсript', $msg);
             
         } return $msg;
    
     }
     
     public static function utf_strlen($msg) {

         if (function_exists('mb_strlen')) return mb_strlen($msg, 'utf-8');
         if (function_exists('iconv_strlen')) return iconv_strlen($msg, 'utf-8');
         if (function_exists('utf8_decode')) return strlen(utf8_decode($msg));
         return strlen(utf_to_win($msg));
    
     } 

      public static function CheckUser () {
        global $user;
        if (!$user) self::redirect ("Извините, эта функция доступна только зарегистрированным пользователям. <br /> Регистрация быстрая и бесплатная.", HTTP."/auth/");
     }
     
     public static function redirect($message, $redirect) {

         $_SESSION['err'] = $message;
         header("Location: $redirect");
         exit();

     } 

     public static function redirect_ok ($message, $redirect) {

         $_SESSION['ok'] = $message;
         header("Location: $redirect");
         exit();

     }
     
     public static function Error () {

            echo (isset($_SESSION['err']) ? '
            <div class="err">
            ' . $_SESSION['err'] . '
            </div>' : '');
            
     }
     
     public static function Ok () {

            echo (isset($_SESSION['ok']) ? '
            <div class="ok">
            ' . $_SESSION['ok'] . '
            </div>' : '');
            
     }

    public static function user ($idUser, $b, $color_id, $link, $type = NULL) {
 
    global $user, $DB;
    
    $query = $DB -> query ("SELECT `id`, `login`, `level`, `sex`, `online`, `ban` FROM `users` WHERE `id` = '".intval ($idUser)."'");
    $res = $query -> fetch ();
    
    if ($res['id'] == 0) {

        $res['login'] = 'Система';
        $res['sex'] = 1;
        $res['online'] = time ();

    }

    $time = time() - 300;
    
    if ($res['online'] > $time) { 

        if ($res['level'] == 1) {
             $ico = ($res['sex'] == 0) ? ''.HTTP.'/files/system.images/user.icons/admin_man_on.png' : ''.HTTP.'/files/system.images/user.icons/admin_woman_on.png';
        }
        elseif ($res['level'] == 2 or $res['level'] == 3 or $res['level'] == 4 or $res['level'] == 5) {
             $ico = ($res['sex'] == 0) ? ''.HTTP.'/files/system.images/user.icons/mod_man_on.png' : ''.HTTP.'/files/system.images/user.icons/mod_woman_on.png';
        }
        elseif ($res['level'] == 10) {
             $ico = ($res['sex'] == 0) ? ''.HTTP.'/files/system.images/user.icons/tester_on.png' : ''.HTTP.'/files/system.images/user.icons/tester_on.png';
        }
        elseif ($res['level'] == 0) {
             $ico = ($res['sex'] == 0) ? ''.HTTP.'/files/system.images/user.icons/man_on.png' : ''.HTTP.'/files/system.images/user.icons/woman_on.png'; 
        }
        elseif ($res['level'] == -1) {
             $ico = '/files/system.images/user.icons/anonym.png';
        }

    }
    else {

        if ($res['level'] == 1) {
             $ico = ($res['sex'] == 0) ? ''.HTTP.'/files/system.images/user.icons/admin_man_off.png' : ''.HTTP.'/files/system.images/user.icons/admin_woman_off.png';
        }
        elseif ($res['level'] == 2 or $res['level'] == 3 or $res['level'] == 4 or $res['level'] == 5) {
             $ico = ($res['sex'] == 0) ? ''.HTTP.'/files/system.images/user.icons/mod_man_off.png' : ''.HTTP.'/files/system.images/user.icons/mod_woman_off.png';
        }
        elseif ($res['level'] == 10) {
             $ico = ($res['sex'] == 0) ? ''.HTTP.'/files/system.images/user.icons/tester_off.png' : ''.HTTP.'/files/system.images/user.icons/tester_off.png';
        }
        elseif ($res['level'] == 0) {
             $ico = ($res['sex'] == 0) ? ''.HTTP.'/files/system.images/user.icons/man_off.png' : ''.HTTP.'/files/system.images/user.icons/woman_off.png'; 
        }
        elseif ($res['level'] == -1) {
            $ico = '/files/system.images/user.icons/anonym.png';
        }
    
    }

    if ($type == 'NoStyle') {

       $viewUser = '<img src = "'.$ico.'"> '.Core::check ($res['login']);

    }
    else {

    $b1 = ($b == 1) ? '<b>' : NULL;
    $b2 = ($b == 1) ? '</b>' : NULL;

    $a = ($link == 1 and $res['id'] != 0) ? '<a class = "link_user" href = "'.HTTP.'/uid'.$res['id'].'">' : NULL;
    $a2 = ($link == 1 and $res['id'] != 0) ? '</a>' : NULL;

    $color = ($color_id == 1) ? '#79358c' : '#79358c';

    $s = ($res['ban'] == 2) ? '<s>' : NULL;
    $s2 = ($res['ban'] == 2) ? '</s>' : NULL;

    $viewUser = '<img src = "'.$ico.'"> '.$s.$a.'<span class = "login_link">'.$b1.''.Core::check ($res['login']).''.$b2.'</span>'.$a2.$s2.'';

    }

    return $viewUser;
 } 
      public static function avatar ($id, $size) {
     
     global $DB;
     $id = intval ( abs ($id));
     $size = intval ( abs ($size));

     $ank = $DB -> query ("SELECT `avatar` FROM `users` WHERE `id` = '".$id."'") -> fetch ();
     if ($ank['avatar'] == 0) return '<img class = "photo" src = "'.HTTP.'/files/system.images/user.default.avatar/'.$size.'/default.png" />';
     else {

         $data = $DB -> query ("SELECT `pic_id`, `pic_key`, `pic_folder`, `pic_type`, `user_id` FROM `users_avatar` WHERE `user_id` = '".$id."' ORDER BY `id` DESC LIMIT 1") -> fetch ();
         
         if ($size == 64) return '<a href = "'.HTTP.'/uid'.$data['user_id'].'/pictures/?folder='.$data['pic_folder'].'&pic='.$data['pic_id'].'"><img class = "photo" src = "'.HTTP.'/files/user.files/pictures/'.$size.'/photo'.$data['pic_id'].'_'.$data['pic_key'].'.'.$data['pic_type'].'" /></a>';
         else return '<img class = "photo" src = "'.HTTP.'/files/user.files/pictures/'.$size.'/photo'.$data['pic_id'].'_'.$data['pic_key'].'.'.$data['pic_type'].'" />';

     }

 }

   public static function date_time ($time) {
 
     $timep="".date("j M Y", $time)."";
     $time_p[0]=date("j n Y", $time);
     $time_p[1]=date("H:i", $time);
     
     if ($time_p[0]==date("j n Y"))$timep=date("H:i", $time);
     if ($time_p[0]==date("j n Y"))$timep=date("H:i", $time);
     if ($time_p[0]==date("j n Y", time()-60*60*24)) $timep="Вчера в ".$time_p[1];
     
     $timep=str_replace("Jan","Янв",$timep);
     $timep=str_replace("Feb","Фев",$timep);
     $timep=str_replace("Mar","Марта",$timep);
     $timep=str_replace("May","Мая",$timep);
     $timep=str_replace("Apr","Апр",$timep);
     $timep=str_replace("Jun","Июня",$timep);
     $timep=str_replace("Jul","Июля",$timep);
     $timep=str_replace("Aug","Авг",$timep);
     $timep=str_replace("Sep","Сент",$timep);
     $timep=str_replace("Oct","Окт",$timep);
     $timep=str_replace("Nov","Ноября",$timep);
     $timep=str_replace("Dec","Дек",$timep);
     
     return $timep;
     
  }
  
   public static function user_online_show($time){
      if($time < 60){
          return $time.' сек.';
      }
      else{
          if($time < 3600) return (int)($time/60).' мин. и '.($time%60).' сек.';
          else{
              if($time < 3600*24) return (int)($time/3600).' час. и '.(int)(($time%3600)/60)." мин.";
              else return ($time/(3600*24)).' дн.';
          }
      }
  }
  
  public static function userSite ($reg) {
     
     $dt1 = date_create();
     $dt2 = date_create();

     $dt1->setTimestamp($reg);
     $dt2->setTimestamp(time ());

     $iv = $dt1->diff($dt2);
     $date = $iv->format('%Y.%m.%d');

     $exp = explode(".", $date);

     if ($exp['0'] == '00') {

        if ($exp['1'] < 1) $view = ($exp['2'] < 8 ? 
            'меньше недели': ($exp['2'] > 8 ? 
            'больше недели' : 'больше недели'));
        else $view = (($exp['1'] > 0 and $exp['1'] < 2) ? 
            'около месяца': (($exp['1'] > 0 and $exp['1'] < 2) ? 
            'несколько месяцев': ($exp['1'] == 6 ? 
            'пол года': (($exp['1'] > 7 and $exp['1'] < 11) ? 
            'почти год' : 'почти год'))));

     }
     else $view = $exp['0'] == '01' ? '1 год': ($exp['0'] == '02' ? '2 года': ($exp['0'] == '03' ? '3 года': ($exp['0'] == '04' ? '4 года': ($exp['0'] == '05' ? '5 лет' : ''))));
    
     return 'На сайте '.$view;

  }  
  
 public static function UserEnd ($id) {

    global $DB;
    $id = (int) abs ($id); 

    $data = $DB -> query ("SELECT `online` FROM `users` WHERE `id` = '".$id."'") -> fetch ();

    return $online = ($data['online'] > time()-300)  ? 'Online' : 'Был в сети <b>'.self::date_time ($data['online']).'</b>';

 }
 
 public static function UserRating ($r) {

    return $rating = ($r == intval ($r)) ? $r.'.0' : $r;

 }

public static function page($k_page = 1) {
    $page = 1;
    if (isset($_GET['page'])) {
        if ($_GET['page'] == 'end') $page = intval($k_page);
        elseif (is_numeric($_GET['page'])) $page = intval($_GET['page']);
    }
    if ($page < 1) $page = 1;
    if ($page > $k_page) $page = $k_page;
    return $page;
}
public static function k_page($k_post = 0, $k_p_str = 10) {
    if ($k_post != 0) {
        $d = $k_post/$k_p_str;
        $v_pages = ceil($d);
    return $v_pages;
    } else {
        return 1;
    }
}
public static function str($link = '?', $k_page = 1, $page = 1) {
    if ($page < 1) $page = 1;
    echo '<div class = "place" style = "padding-bottom: 5px;">';
    if ($page > 1) echo '<a href="'. $link .'page='. ($page - 1) .'">&larr; Назад</a> ';
    if ($page > 1 && $page < $k_page) echo '<span style="color:#000;">|</span>';
    if ($page < $k_page) echo ' <a href="'. $link .'page='. ($page + 1) .'">Вперед &rarr;</a>';
    echo '<br>';
    if ($page != 1) echo '<a href="'. $link .'page=1"><span class="unsel">1</span></a>';
    else echo '<span class="sel">1</span>';
    for ($ot = -3; $ot <= 3; $ot++) {
        if ($page + $ot > 1 && $page + $ot < $k_page) {
            if ($ot == -3 && $page + $ot > 3) echo " ..";
            if ($ot != 0) echo ' <a href="'. $link .'page='. ($page + $ot) .'"><span class="unsel">'. ($page + $ot) .'</span></a>';
            else echo ' <span class="sel">'. ($page + $ot) .'</span>';
            if ($ot == 3 && $page + $ot < $k_page - 1) echo ' ..';
        }
    }
    if ($page != $k_page) echo ' <a href="'. $link .'page=end"><span class="unsel">'. $k_page .'</span></a>';
    elseif ($k_page > 1) echo ' <span class="sel">'. $k_page .'</span>';
    echo '</div>';
}

 public static function CropStr($msg, $len) {

         $wordsafe = FALSE; $dots = true; $slen = strlen($msg);
         if ($slen <= $len) {
         return $msg;}
         if ($wordsafe) {
         $end = $len;
         while (($msg[--$len] != ' ') && ($len > 0)) {};
         if ($len == 0) {
         $len = $end;}}
         if ((ord($msg[$len]) < 0x80) || (ord($msg[$len]) >= 0xC0)) {
         return substr($msg, 0, $len) . ($dots ? ' ...' : '');}
         while (--$len >= 0 && ord($msg[$len]) >= 0x80 && ord($msg[$len]) < 0xC0) {};
         return substr($msg, 0, $len) . ($dots ? ' ...' : '');
    
 }

 public static function bb($msg) {

     return nl2br (self::code (self::smiles ($msg)));

 }

 public static function code($msg) {
  
     $msg = preg_replace('#\[b\](.*?)\[/b\]#si', '<b>\1</b>', $msg);
     $msg = preg_replace('#\[i\](.*?)\[/i\]#si', '<i>\1</i>', $msg);
     $msg = preg_replace('#\[u\](.*?)\[/u\]#si', '<u>\1</u>', $msg);
     $msg = preg_replace('#\[color=(.*?)\](.*?)\[/color\]#si', '<span style="color:\1">\2</span>', $msg);
     $msg = preg_replace('#\[bgcolor=(.*?)\](.*?)\[/bgcolor\]#si', '<span style="background-color:\1">\2</span>', $msg);
     $msg = preg_replace('#\[quote\](.*?)\[/quote\]#si', '<span class = "quote">\1</span>', $msg);
     $msg = preg_replace('#\[url=(.*?)\](.*?)\[/url\]#si', '<a href="\1">\2</a>', $msg);
     $msg = str_replace('javascript', 'javasсript', $msg);
     $msg = str_replace('script', 'sсript', $msg);
     return $msg;

  }
  
   public static function without_bb($msg) {
  
     $msg = preg_replace('#\[b\](.*?)\[/b\]#si', '\1', $msg);
     $msg = preg_replace('#\[i\](.*?)\[/i\]#si', '\1', $msg);
     $msg = preg_replace('#\[u\](.*?)\[/u\]#si', '\1', $msg);
     $msg = preg_replace('#\[color=(.*?)\](.*?)\[/color\]#si', '\2', $msg);
     $msg = preg_replace('#\[bgcolor=(.*?)\](.*?)\[/bgcolor\]#si', '\2', $msg);
     $msg = preg_replace('#\[quote\](.*?)\[/quote\]#si', '\1', $msg);
     $msg = preg_replace('#\[url=(.*?)\](.*?)\[/url\]#si', '\2', $msg);
     $msg = str_replace('javascript', 'javasсript', $msg);
     $msg = str_replace('script', 'sсript', $msg);
     
     return $msg;
  }

 public static function smiles($message) {

    if(!file_exists($file=ROOT.'/core/inc/smiles.ini'))
    return false;
    $info_smiles = file($file, FILE_IGNORE_NEW_LINES);
    foreach($info_smiles as $name_str=>$cur_str)
    {
        $arr_str=explode(",", $cur_str);
        foreach($arr_str as $key=>$value)
        $message=str_replace($value, '<img src="'.HTTP.'/files/smiles/'.$name_str.'.gif" alt=""/>', $message);
    }
    return $message;
 }

 public static function lenta ($id, $object, $message, $url, $type, $share = NULL) {

     global $DB;

    $id = (int) abs ($id);
    $type = (int) abs ($type);
    $object = (int) abs ($object);
    $share = (int) abs ($share);

    $share_sql = ($share > 0) ? ", `share` = '".$share."'" : '';

    return $DB -> query("INSERT INTO `lenta` SET
                        `user_id` = '".$id."',
                        `object_id` = '".$object."',
                        `message` = ".$DB -> quote ($message).",
                        `type` = '".$type."',
                        `url` = ".$DB -> quote ($url).",
                        `time` = '".time ()."' ".$share_sql."");

 }

 public static function count_view($type, $object) {

    global $user, $DB;

       $AddCount = $DB -> prepare ("INSERT INTO `count_view` SET
                         `id` = NULL,
                         `user_id` = ?,
                         `type` = ?,
                         `object_id` = ?");
       $AddCount -> execute (Array ($user['id'], $type, $object));

 }  

 public static function translit($str) {
    $rus = array('А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я', 'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я');
    $lat = array('A', 'B', 'V', 'G', 'D', 'E', 'E', 'Gh', 'Z', 'I', 'Y', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'F', 'H', 'C', 'Ch', 'Sh', 'Sch', 'Y', 'Y', 'Y', 'E', 'Yu', 'Ya', 'a', 'b', 'v', 'g', 'd', 'e', 'e', 'gh', 'z', 'i', 'y', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's', 't', 'u', 'f', 'h', 'c', 'ch', 'sh', 'sch', 'y', 'y', 'y', 'e', 'yu', 'ya');
    return str_replace($rus, $lat, $str);
  }

 public static function remark_reason ($type = NULL, $number_reason) {

     if ($type == 'chat') return ($number_reason == 0 ? 'Грубость и оскорбления' : ($number_reason == 1 ? 'Нецензурная лексика' : ($number_reason == 2 ? 'СПАМ, реклама' : ($number_reason == 3 ? 'Иное' : 'Иное'))));
     else if ($type == 'forum_theme') return ($number_reason == 0 ? 'Грубость и оскорбления' : ($number_reason == 1 ? 'Нецензурная лексика' : ($number_reason == 2 ? 'СПАМ, реклама' : ($number_reason == 3 ? 'Разжигание ненависти' : ($number_reason == 4 ? 'Флуд, Оффтопик' : ($number_reason == 5 ? 'Нежелание пользоваться поиском' : ($number_reason == 6 ? 'Некорректное название темы' : ($number_reason == 7 ? 'Бессмысленная тема' : ($number_reason == 8 ? 'Намеки на ДП' : ($number_reason == 9 ? 'ДП' : ($number_reason == 10 ? 'Педофилия' : ($number_reason == 11 ? 'Иное' : 'Иное'))))))))))));
     else if ($type == 'forum_comment') return ($number_reason == 0 ? 'Грубость и оскорбления' : ($number_reason == 1 ? 'Нецензурная лексика' : ($number_reason == 2 ? 'СПАМ, реклама' : ($number_reason == 3 ? 'Разжигание ненависти' : ($number_reason == 4 ? 'Флуд, Оффтопик' : ($number_reason == 5 ? 'Намеки на ДП' : ($number_reason == 6 ? 'ДП' : ($number_reason == 7 ? 'Педофилия' : ($number_reason == 8 ? 'Иное' : 'Иное')))))))));
     else if ($type == 'ban_file') return ($number_reason == 0 ? 'Нет метки (18+)' : ($number_reason == 1 ? 'Грубость и оскорбления' : ($number_reason == 2 ? 'Намеки на ДП' : ($number_reason == 3 ? 'ДП' : ($number_reason == 4 ? 'Педофилия' : ($number_reason == 5 ? 'Не верная категория' : ($number_reason == 6 ? 'Иное' : 'Иное')))))));
                  
 }

}

?> 