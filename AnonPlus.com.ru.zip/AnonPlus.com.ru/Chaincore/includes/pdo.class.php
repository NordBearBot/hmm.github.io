<?php

 $hostSQL = 'localhost';
 $userSQL = 'dario169_Chain';
 $dbSQL =   'dario169_Chain';
 $passSQL = ',%dc,$?Q;*HF';
 $charsetSQL = 'utf8';

 $dsn = "mysql:host=$hostSQL;dbname=$dbSQL;charset=$charsetSQL";
 $opt = array(
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
 );
 
 try {
   $DB = new PDO ($dsn, $userSQL, $passSQL, $opt);
 } 
 catch (PDOException $DB) { 
   echo 'Error connect to database!';
   exit ();	
 }
 
 $languageDB = $DB -> query ("SET character_set_client = utf8");
 $languageDB = $DB -> query ("SET NAMES 'utf8'");


?> 