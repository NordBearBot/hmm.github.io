<?php

 class Blog {

 	 public static function channel ($blog_id) {

 		 global $DB;
 		 $id = (int) abs ($blog_id);

         $blog = $DB -> query ("SELECT `channel` FROM `blogs` WHERE `id` = '".$blog_id."'") -> fetch ();

         return ($blog['channel'] == 0 ? 'Личный блог' : ($blog['channel'] == 1 ? '' : ''));


 	 }

     public static function share ($blog_id) {

     	 global $DB;
     	 $id = (int) abs ($blog_id);

     	 $blog = $DB -> query ("SELECT * FROM `blogs` WHERE `id` = '".$blog_id."'") -> fetch ();
         $ank = $DB -> query ("SELECT `login` FROM `users` WHERE `id` = '".$blog['user_id']."'") -> fetch ();

 	     return '

 	     <div class = "place" style = "padding-top: 0; border: none;">

 	     <a href = "'.HTTP.'/uid'.$blog['user_id'].'/blog/?i='.$blog['id'].'">

 	         <div style="border-left: 3px solid #666; padding-left: 10px;">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/action_share.gif">

                 <b class = "private_info">'.$ank['login'].'</b>

                 '.Core::CropStr (Core::without_bb ($blog['message']), 300).'

             </div>

         </a>

         </div>

         ';

     }

     public static function share_link ($blog_id) {

         global $DB, $user;
         $id = (int) abs ($blog_id);

         $blog = $DB -> query ("SELECT * FROM `blogs` WHERE `id` = '".$blog_id."' LIMIT 1") -> fetch ();
         $object = ($blog['share'] > 0) ? $blog['share'] : $blog['id'];

         $share = ($blog['share'] > 0) ? $DB -> query ("SELECT `user_id` FROM `blogs` WHERE `id` = '".$blog['share']."' LIMIT 1") -> fetch () : 0;

         $try = $DB -> query ("SELECT * FROM `blogs` WHERE `share` = '".$object."' AND `user_id` = '".$user['id']."' LIMIT 1") -> RowCount ();

         return (($try < 1 and $share['user_id'] != $user['id']) ? '<a href="'.HTTP.'/share/id'.$blog['id'].'" class="adv_user_link adv_user_link_text" id="shared_link" title="Поделиться"><span class="ico"></span> <span></span></a>' : '');

     }

     public static function access ($access) {

         $access = (int) abs ($access);
         $access = ($access > 2) ? 0 : $access;

         return '<span style = "margin-left: 5px;">'.($access == 0 ? '<img id = "menu_list" src="'.HTTP.'/files/system.images/status.data/access_all.png" title="Доступен всем">' :
                ($access == 1 ? '<img src="'.HTTP.'/files/system.images/status.data/access_friends.png" title="Доступен друзьям">' :
                ($access == 2 ? '<img src="'.HTTP.'/files/system.images/status.data/access_me.png" title="Доступен автору">' : ''))).'</span>';


     }

 }

?>