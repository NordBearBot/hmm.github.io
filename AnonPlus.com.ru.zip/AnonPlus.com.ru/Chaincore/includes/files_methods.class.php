<?php

class files_Methods {

 public static function dir_name($type) {

    return ($type == 'jpg' || $type == 'jpeg' || $type == 'png' || $type == 'gif' ? 'pictures' :
           ($type == '3gp' || $type == 'mp4' || $type == 'avi' || $type == 'mpeg' || $type == 'flv' ? 'video' :
           ($type == 'mp3' || $type == 'aac' || $type == 'wav' || $type == 'wma' || $type == 'amr' ? 'audio' :
           'other')));

 } 

 public static function filesize_get($file)  { 

     if(!file_exists($file)) return "Файл  отсутствует."; 

   $filesize = filesize($file); 
    
   if($filesize > 1024) 
   { 
       $filesize = ($filesize/1024); 
       if($filesize > 1024) 
       { 
            $filesize = ($filesize/1024); 
           if($filesize > 1024) 
           { 
               $filesize = ($filesize/1024); 
               $filesize = round($filesize, 1); 
               return $filesize." ГБ";    
                 
           } 
           else 
           { 
               $filesize = round($filesize, 1); 
               return $filesize." MБ";    
           }   
             
       } 
       else 
       { 
           $filesize = round($filesize, 1); 
           return $filesize." Кб";    
       } 
    
   } 
   else 
   { 
       $filesize = round($filesize, 1); 
       return $filesize." байт";    
   } 
   
} 

 public static function typeFile ($type) {

     if ($type == NULL or empty ($type)) $type = 'unknown';

     if ($type == 'png') $img_type = '<img id = "menu_list" src = "'.HTTP.'/files/system.images/file.type/type.png.png">';
     else if ($type == 'jpg') $img_type = '<img id = "menu_list" src = "'.HTTP.'/files/system.images/file.type/type.jpg.png">';
     else $img_type = '<img id = "menu_list" src = "'.HTTP.'/files/system.images/file.type/type.unknown.png">';

     return $img_type;

 }

public static function download($path, $id, $key, $type) {
  

    if ($type == 'png' || $type == 'jpg' || $type == 'gif' || $type == 'jpeg') {
    if (file_exists($path)) {
    header('Location: '.HTTP.'/files/user.files/pictures/file'.$id.'_'.$key.'.'.$type.'');
    } else { die('Файл не найден'); } 
    } else {

    if (headers_sent()) 
    die('Headers Sent'); 
  
   
    if(ini_get('zlib.output_compression')) 
    ini_set('zlib.output_compression', 'Off'); 


    if (file_exists($path)) { 
     

    $fsize = filesize($path); 
    $path_parts = pathinfo($path); 
    $ext = strtolower($path_parts["extension"]); 
     

    switch ($ext) { 
    case "pdf": $ctype="application/pdf"; break; 
    case "exe": $ctype="application/octet-stream"; break; 
    case "zip": $ctype="application/zip"; break; 
    case "doc": $ctype="application/msword"; break; 
    case "xls": $ctype="application/vnd.ms-excel"; break; 
    case "ppt": $ctype="application/vnd.ms-powerpoint"; break; 
    default: $ctype="application/force-download"; 
    } 

    header("Pragma: public"); 
    header("Expires: 0"); 
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0"); 
    header("Cache-Control: private",false); 
    header("Content-Type: $ctype"); 
    header("Content-Disposition: attachment; filename=\"".basename($path)."\";" ); 
    header("Content-Transfer-Encoding: binary"); 
    header("Content-Length: ".$fsize); 
    ob_clean(); 
    flush(); 
    readfile($path); 
  
    } else { die('Файл не найден'); }
    } 
}

}

?>