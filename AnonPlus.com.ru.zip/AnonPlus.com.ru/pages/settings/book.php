<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $book_access_checked0 = ($user['book_access'] == 0) ? 'checked="checked"' : '';
 $book_access_checked1 = ($user['book_access'] == 1) ? 'checked="checked"' : '';
 $book_access_checked2 = ($user['book_access'] == 2) ? 'checked="checked"' : '';

 $book_comment_checked0 = ($user['book_comments'] == 0) ? 'checked="checked"' : '';
 $book_comment_checked1 = ($user['book_comments'] == 1) ? 'checked="checked"' : '';
 $book_comment_checked2 = ($user['book_comments'] == 2) ? 'checked="checked"' : '';

 if (isset ($_POST['save'])) {

     $book_access = (int) abs ($_POST['book_access']);
     $book_comment = (int) abs ($_POST['comment_access']);
     $CK = (int) abs ($_POST['CK']);

     if ($CK == $user['CK']) {

         $access = ($book_access < 0 or $book_access > 2) ? 0 : $book_access;
         $comment = ($book_comment < 0 or $book_comment > 2) ? 0 : $book_comment;

         if ($access == 2 and $comment != 2) $comment = 2;
         if ($access == 1 and $comment == 0) $comment = 1;

         $DB -> query ("UPDATE `users` SET `book_access` = '".$access."', `book_comments` = '".$comment."' WHERE `id` = '".$user['id']."'");
         Core::redirect_ok ("Изменения сохранены", HTTP."/settings/book/");
     
     }
     else Core::redirect ("Не верный CK!", HTTP."/settings/book/");


 }

 $title = $user['login'].' / Настройки / Гостевая';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'
             
             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/settings/">

                 Настройки

             </a>

         </div>
 ';

 Core:: Ok ();
 Core:: Error ();

 echo '
         <div class = "nav">

             Гостевая

         </div>

 ';

 echo '

         <form action = "" method = "POST">

         <div class = "block">

             Комментируют:

             <br />

             <input type="radio" name="comment_access" value="0" '.$book_comment_checked0.' /> <img src = "'.HTTP.'/files/system.images/status.data/access_all.png"> Все 

             <br />

             <input type="radio" name="comment_access" value="1" '.$book_comment_checked1.' /> <img src = "'.HTTP.'/files/system.images/status.data/access_friends.png"> Друзья

             <br />

             <input type="radio" name="comment_access" value="2" '.$book_comment_checked2.' /> <img src = "'.HTTP.'/files/system.images/status.data/access_me.png"> Только я

         </div>

         <div class = "block">

             Доступ:

             <br />

             <input type="radio" name="book_access" value="0" '.$book_access_checked0.' /> <img src = "'.HTTP.'/files/system.images/status.data/access_all.png"> Все 

             <br />

             <input type="radio" name="book_access" value="1" '.$book_access_checked1.' /> <img src = "'.HTTP.'/files/system.images/status.data/access_friends.png"> Друзья

             <br />

             <input type="radio" name="book_access" value="2" '.$book_access_checked2.' /> <img src = "'.HTTP.'/files/system.images/status.data/access_me.png"> Только я

         </div>

         <div class = "block">

             <input type = "submit" name = "save" value = "Сохранить">

         </div>

         <input type="hidden" name="CK" value="'.$user['CK'].'" />

         </form>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'
             
             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/settings/">

                 Настройки

             </a>

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>