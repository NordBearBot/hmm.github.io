<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $mail_access_checked0 = ($user['mail_access'] == 0) ? 'checked="checked"' : '';
 $mail_access_checked1 = ($user['mail_access'] == 1) ? 'checked="checked"' : '';
 $mail_access_checked2 = ($user['mail_access'] == 2) ? 'checked="checked"' : '';
 $mail_access_checked3 = ($user['mail_access'] == 3) ? 'checked="checked"' : '';

 if (isset ($_POST['save'])) {

     $mail_access = (int) abs ($_POST['mail_access']);
     $CK = (int) abs ($_POST['CK']);

     if ($CK == $user['CK']) {

         $access = ($mail_access < 0 or $mail_access > 3) ? 0 : $mail_access;

         $DB -> query ("UPDATE `users` SET `mail_access` = '".$access."' WHERE `id` = '".$user['id']."'");
         Core::redirect_ok ("Изменения сохранены", HTTP."/settings/mail/");
     
     }
     else Core::redirect ("Не верный CK!", HTTP."/settings/mail/");


 }

 $title = $user['login'].' / Настройки / Гостевая';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'
             
             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/settings/">

                 Настройки

             </a>

         </div>
 ';

 Core:: Ok ();
 Core:: Error ();

 echo '
         <div class = "nav">

             Почта

         </div>

 ';

 echo '

         <div class = "block">

             <font color = "darkred">

                 * Ограничив обитателя доступом к почте, Вы не сможите продолжить с ним ранее начатый диалог!

             </font>

         </div>

 ';

 echo '

         <form action = "" method = "POST">

         <div class = "block">

             Кто может мне писать:

             <br />

             <input type="radio" name="mail_access" value="0" '.$mail_access_checked0.' /> <img src = "'.HTTP.'/files/system.images/status.data/access_all.png"> Все 

             <br />

             <input type="radio" name="mail_access" value="1" '.$mail_access_checked1.' /> <img src = "'.HTTP.'/files/system.images/site.icons/fav.png"> Знакомые мне контакты

             <br />

             <input type="radio" name="mail_access" value="2" '.$mail_access_checked2.' /> <img src = "'.HTTP.'/files/system.images/site.icons/friends.gif"> Друзья

             <br />

             <input type="radio" name="mail_access" value="3" '.$mail_access_checked3.' /> <img src = "'.HTTP.'/files/system.images/status.data/access_me.png"> Никто

         </div>

         <div class = "block">

             <input type = "submit" name = "save" value = "Сохранить">

         </div>

         <input type="hidden" name="CK" value="'.$user['CK'].'" />

         </form>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'
             
             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/settings/">

                 Настройки

             </a>

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>