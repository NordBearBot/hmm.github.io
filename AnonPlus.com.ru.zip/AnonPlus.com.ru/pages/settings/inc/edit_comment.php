<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 ## Находим пользователя
 $queryUser = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".intval( abs ($_GET['id']))."'");

 ## Если не существует пользователь
 if ($queryUser -> RowCount () < 1) {

    if ($user) Core::redirect ("Пользователь не существует!", HTTP."/uid".$user['id']."");
    else Core::redirect ("Пользователь не существует!", HTTP."/people/");

 }

 $ank = $queryUser -> fetch ();

 $comment_id = (int) abs ($_GET['edit']);

 ## Находим комментарий
 $queryComment = $DB -> query ("SELECT * FROM `user_book` WHERE `book_id` = '".$ank['id']."' AND `id` = '".$comment_id."' AND `user_id` = '".$user['id']."'");
 if ($queryComment -> RowCount () < 1) Core::redirect ("Комментарий не существует!", HTTP."/uid".$ank['id']."/book/");

 $comment = $queryComment -> fetch ();

 if ($comment['time'] < $conf['edit_comment']) Core::redirect ("Время редактирования этого комментария вышло!", HTTP."/uid".$ank['id']."/book/");

 if (isset ($_POST['comment'])) {

     $CK = (int) abs ($_POST['CK']);
     $message = Core::check ($_POST['message']);

     if ($CK == $user['CK']) {

         if (empty ($message)) $err = '<div class = "err">Комментарий не должен быть пустым!</div>';
         else if (strlen($message) > 3000) $err = '<div class = "err">Комментарий не должен превышать 3000 символов!</div>';
         else if (empty ($err)) {

             $DB -> query ("UPDATE `user_book` SET `message` = ".$DB -> quote ($message)." WHERE `id` = '".$comment_id."'");
             Core::redirect_ok ("Комментарий изменён", HTTP."/uid".$ank['id']."/book/");

         }

     }
     else Core::redirect ("Не верный CK!", HTTP."/uid".$ank['id']."/book/?edit=".$comment['id']."");

 }

 $title = $ank['login'].' / Гостевая / Изменить комментарий';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'
             
             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/book/">

                 Гостевая
             
             </a>

         </div>

         <div class = "nav">

             Изменить комментарий

         </div>
 ';

 Core:: Ok ();
 Core:: Error ();

 echo '

         <div class = "block">

             Вы написали:

         </div>

         '.$err.'

         <div class = "nav">

             <form action = "" method = "POST">

                 <textarea name="message"  placeholder = "Изменить комментарий...">'.$comment['message'].'</textarea>

                 <br />

                 <input type = "submit" name = "comment" value = "Изменить"/>

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

             </form>

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'
             
             </a>

             <span class = "ico next"></span>
             
             Гостевая

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>