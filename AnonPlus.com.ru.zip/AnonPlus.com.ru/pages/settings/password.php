<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();


 if (isset ($_POST['save'])) {

     $def_password = Core::check ($_POST['def_password']);
     $new_password = Core::check ($_POST['new_password']);
     $new2_password = Core::check ($_POST['new2_password']);

     $CK = (int) abs ($_POST['CK']);

     if ($CK == $user['CK']) {

         $def_log = (empty ($def_password)) ? '<br /> <small style = "color: darkred;">Это поле не должно быть пустым!</small>' : NULL;
         $new_log = (empty ($new_password)) ? '<br /> <small style = "color: darkred;">Это поле не должно быть пустым!</small>' : NULL;
         $new2_log = (empty ($new2_password)) ? '<br /> <small style = "color: darkred;">Это поле не должно быть пустым!</small>' : NULL;

         if (empty ($def_log) and empty ($new_log) and empty ($new2_log)) {

             $new_log = (strlen ($new_password)<6 || strlen ($new_password)>30) ? '<br /><small><font color = "darkred">Пароль должен быть не меньше 6 и не больше 30 символов!</font></small>' : NULL;
             $new2_log = (strlen ($new2_password)<6 || strlen ($new2_password)>30) ? '<br /><small><font color = "darkred">Пароль должен быть не меньше 6 и не больше 30 символов!</font></small>' : NULL;

            if (empty ($new_log) and empty ($new2_log)) {

                 if ($new_password != $new2_password) Core::redirect ("Пароли не совпадают!", HTTP."/settings/password");
                 
                 if ($def_password != $user['password']) Core::redirect ("Не верно введён текущий пароль!", HTTP."/settings/password");

                 $DB -> query ("UPDATE `users` SET `password` = ".$DB -> quote ($new_password)." WHERE `id` = '".$user['id']."'");

                 Core::redirect_ok ("Пароль изменён", HTTP."/settings/password");

            }

         }
     
     }
     else Core::redirect ("Не верный CK!", HTTP."/settings/mail/");


 }

 $title = $user['login'].' / Настройки / Изменить пароль';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'
             
             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/settings/">

                 Настройки

             </a>

         </div>

         <div class = "nav">

             Изменить пароль

         </div>

 ';

 Core:: Ok ();
 Core:: Error ();

 echo '

         <form action = "" method = "POST">

         <div class = "block">

             Старый пароль:

             <br />

             <input type = "text" name = "def_password" '.(isset ($def_password) ? 'value = "'.$def_password.'"' : '').' >

             '.$def_log.'

         </div>

         <div class = "block">

             Новый пароль:

             <br />

             <input type = "password" name = "new_password">

             '.$new_log.'

         </div>

         <div class = "block">

             Повторите пароль:

             <br />

             <input type = "password" name = "new2_password">

             '.$new2_log.'

         </div>

         <div class = "block">

             <input type = "submit" name = "save" value = "Сохранить">

         </div>

         <input type="hidden" name="CK" value="'.$user['CK'].'" />

         </form>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'
             
             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/settings/">

                 Настройки

             </a>

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>