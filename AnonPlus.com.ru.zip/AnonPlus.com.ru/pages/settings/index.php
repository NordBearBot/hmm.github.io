<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $UA = Core::check ($_SERVER['HTTP_USER_AGENT']);
 $IP = Core::check ($_SERVER['REMOTE_ADDR']);

 $title = $user['login'].' / Настройки';

 include_once ROOT.'/template/header.php';
 

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'
             
             </a>

             <span class = "ico next"></span>

             Настройки

         </div>
 ';

 Core:: Ok ();
 Core:: Error ();

 echo '

         <div class = "background_place">

         <div class = "main_place">

             <div class = "place">

                 <span class="private_info">

                     <small>

                         IP: <b>'.$IP.'</b>

                         <br />

                         <!-- UA: '.$UA.'

                         <br /> -->

                         Browser: <b>'.device::browser ($UA).'</b>

                     </small>

                 </span>

             </div></div>
             
             <div class = "main_place">
             <div class = "place">

                 <span class="private_info">

                     <small>

                         Количество твоих монеток: '.$user['coins'].'

                     </small>

                 </span>

             </div>

         </div>

         <div class = "main_place">

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 Приватность

             </a>

         </div>

         <a class = "home" href = "'.HTTP.'/settings/book/">

             <img src = "'.HTTP.'/files/system.images/site.icons/book.png"> Гостевая

         </a>

         <a class = "home" href = "'.HTTP.'/settings/mail/">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/email.png"> Почта

         </a>

         <a class = "home" href = "'.HTTP.'/settings/friend/">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/friends.gif"> Предложение Дружбы

         </a>

         </div>

         <div class = "main_place">

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 Безопасность аккаунта

             </a>

         </div>

         <a class = "home" href = "'.HTTP.'/settings/password/">

             <img src = "'.HTTP.'/files/system.images/site.icons/key.png"> Изменить пароль

         </a>

         <a class = "home" href = "'.HTTP.'/settings/email/">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/email.png"> Настройки Email

         </a>

         </div>

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'
             
             </a>

             <span class = "ico next"></span>

             Настройки

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>