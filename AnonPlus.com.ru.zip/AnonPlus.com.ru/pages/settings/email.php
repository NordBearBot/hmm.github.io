<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $title = $user['login'].' / Настройки / Настройки Email';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'
             
             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/settings/">

                 Настройки

             </a>

         </div>

         <div class = "nav">

             Настройки Email

         </div>

 ';

 Core:: Ok ();
 Core:: Error ();

 if (empty ($user['email'])) {

     $emailTest = $DB -> query ("SELECT * FROM `email_act` WHERE `user_id` = '".$user['id']."' AND `time` > '".(time ()-3600)."' AND `status` = '1' LIMIT 1");

     if ($emailTest -> RowCount () > 0) {

         if (isset ($_POST['code']) or isset ($_GET['code'])) {

             $email = $emailTest -> fetch ();

             $code = (isset ($_POST['code']) ? $_POST['code'] : (isset ($_GET['code']) ? $_GET['code'] : ''));

             if ($code != $email['hash']) Core::redirect ("Не верный код!", HTTP."/settings/email/");
             else {

                  $DB -> query ("UPDATE `email_act` SET `status` = '0' WHERE `user_id` = '".$user['id']."'");
                  $DB -> query ("UPDATE `users` SET `email` = ".$DB -> quote ($email['email'])." WHERE `id` = '".$user['id']."'");
                  Core::redirect_ok ("Email адрес успешно привязан", HTTP."/settings/email/");

             }

         }
 
         echo '

         <div class = "block">

             На ваш email адрес отправлен код, введите его здесь или перейдите по ссылке в письме.
             <font colot = "red">Код будет действителен в течении 1 часа!</font>

         </div>

         <form action = "" method = "POST">

             <div class = "block">

                 Введите код:

                 <br />

                 <input type = "text" name = "code">

                 <br />

                 <input type = "submit" name = "save" value = "Подтвердить">

             </div>

         </form>

         ';




     }
     else {  

     if (isset ($_POST['save'])) {

        $email = Core::check ($_POST['email']);
        
        if (empty ($email)) $e_log = '<br /> <small style = "color: darkred;">Это поле не должно быть пустым!</small>';
        else if (!preg_match("/^[a-zA-Z0-9_\-.]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-.]+$/", $email)) $e_log = '<br /> <small style = "color: darkred;">Не правильно введён email адрес!</small>';

        if (empty ($e_log)) {
 
             $emailC = $DB -> query ("SELECT `email` FROM `users` WHERE `email` = ".$DB -> quote ($email)." LIMIT 1");

             if ($emailC -> RowCount () > 0) $e_log = '<br /> <small style = "color: darkred;">Этот email уже прикреплён к другому аккаунту!</small>';
             else {

                 $rand1 = mt_rand(1111, 9999);
                 $rand2 = mt_rand(1111, 9999);
                 $accessHash = sha1($rand1.$rand2);

                 $DB -> query ("INSERT INTO `email_act` SET `user_id` = '".$user['id']."', `email` = ".$DB -> quote ($email).", `time` = '".time ()."', `hash` = '".$accessHash."'");

                 mail($email, 'Привязка email адреса', 'Здравствуйте, <b>'.$user['login'].'</b> \n Что бы привязать этот email адрес, введите этот код на '.DOMAIN.':  \n <b>'.$accessHash.'</b> \n Или перейдите по этой ссылке: <a href = "'.HTTP.'/settings/email/?code='.$accessHash.'"">'.DOMAIN.'/settings/email/?code='.$accessHash.'</a> \n С ув. администрация <a href = "'.HTTP.'">'.DOMAIN.'</a>');

                 header ('Location: '.HTTP.'/settings/email/');

             }


        }

     }

     echo '

         <div class = "block">

             <small style = "color:red;">

                 Вводите свой рабочий email адрес, на него будет отправлен код, который нужно будет подтвердить здесь.

                 <br />

                 Так же с помощью email вы сможите восстановить пароль к аккаунту.

             </small>

         </div>

         <form action = "" method = "POST">

         <div class = "block">

             Ваш Email адрес:

             <br />

             <input type = "text" name = "email">

             '.$e_log.'

         </div>

         <div class = "block">

             <input type = "submit" name = "save" value = "Сохранить">

         </div>

         <input type="hidden" name="CK" value="'.$user['CK'].'" />

         </form>

     ';


     }

 }
 else {

     echo '

         <div class = "block">

            Ваш email: <b>'.$user['email'].'</b>

         </div>

     ';

 }

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'
             
             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/settings/">

                 Настройки Email

             </a>

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>