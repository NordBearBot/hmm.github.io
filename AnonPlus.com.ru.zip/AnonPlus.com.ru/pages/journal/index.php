<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 
 Core::CheckUser ();

 $queryUpdateStatusJournal = $DB -> query ("UPDATE `journal` SET `status` = '0' WHERE `reply_id` = '".$user['id']."'");

 $sect = (int) abs ($_GET['section']);

 ## Сортировка
 $section = ($sect == 1 ? "" :  "AND `act` = '1'");

 ## Пагинация
 $c_p = $DB -> query ("SELECT * FROM `journal` WHERE `reply_id` = '".$user['id']."' ".$section."") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 ## Выбираем записи из БД
 $queryJournal = $DB -> query ("SELECT * FROM `journal` WHERE `reply_id` = '".$user['id']."' ".$section." ORDER BY `time` DESC LIMIT $start, ".$p_page."");

 $title = $user['login'].' / Журнал';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>
             
             <span class = "ico next"></span>

             Журнал

         </div>
 ';
 
 Core:: Error ();
 Core:: Ok ();

 $new = (empty ($sect) or $sect != 1) ? '<span id = "t"></span>' : '';
 $all = ($sect == 1) ? '<span id = "t"></span>' : '';

 $link_new = (empty ($sect) or $sect != 1) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/journal/?" class = "no_act act_l_b act_r_b">';
 $link_all = ($sect == 1) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/journal/?section=1" class = "no_act act_l_b act_r_b">';

 echo '
          <div class = "background_place">

             <div class = "main_place">

             <div class = "block" style = "border: none; padding-bottom: 0px;">

             <div class = "part" style = "width: 50%;">

                 '.$link_new.' Новые </a>

                 '.$new.'

             </div>

             <div class = "part" style = "width: 50%;">

                  '.$link_all.' Все </a>

                 '.$all.'

             </div>



         </div>

 ';

 if ($queryJournal -> RowCount () < 1) echo '<div class = "place private_info"> Уведомлений нет. <br /> В журнале будут отображаться все ответы на ваши комментарии или записи. </div></div>';
 else {

     while ($journal = $queryJournal -> fetch ()) {

         $ank = $DB -> query ("SELECT `id`, `login`, `sex` FROM `users` WHERE `id` = '".$journal['user_id']."'") -> fetch ();
         $sex = ($ank['sex'] == 1) ? 'а' : '';
         $type = ($journal['type'] == 1 ? 'блоге' : ($journal['type'] == 2 ? 'фото' : ($journal['type'] == 3 ? 'гостевой' : ($journal['type'] == 4 ? 'файле' : ($journal['type'] == 5 ? 'форуме' : '')))));

         echo '

         <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

             <div id = "avatar">

                 '.User::avatar ($ank['id'], 40).'

             </div>

             <a class = "private_info" href = "'.HTTP.'/uid'.$ank['id'].'"><b>'.$ank['login'].'</b></a> ответил'.$sex.' вам в '.$type.':

             <small class = "private_info" id = "right">

                 '.Core::date_time ($journal['time']).'

             </small>

             <br />

             <a class = "private_info" href = "'.HTTP.$journal['url'].'&journal='.$journal['id'].'">

                 '.$journal['message'].'
             
             </a>

         </div>

         ';

     }
     
     echo '

     </div>

     ';    

 }

 $p_section = ($sect == 1 ? 'section=1' : '');

 if ($k_page > 1) Core::str(''.HTTP.'/journal/?'.$p_section.'&', $k_page, $page);

 echo '
         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>

             <span class = "ico next"></span>

             Журнал

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>