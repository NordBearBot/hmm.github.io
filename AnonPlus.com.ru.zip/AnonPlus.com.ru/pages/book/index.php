<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 ## Находим пользователя
 $queryUser = $DB -> query ("SELECT `id`, `login`, `book_access`, `book_comments` FROM `users` WHERE `id` = '".intval( abs ($_GET['id']))."'");

 ## Если не существует пользователь
 if ($queryUser -> RowCount () < 1) {

    if ($user) Core::redirect ("Пользователь не существует!", HTTP."/uid".$user['id']."");
    else Core::redirect ("Пользователь не существует!", HTTP."/people/");

 }

 $ank = $queryUser -> fetch ();
 
 if ($ank['book_access'] == 2 and $user['id'] != $ank['id']) Core::redirect ("Гостевая закрыта для всех!", HTTP."/err");

 if ($ank['book_access'] == 1 and $user['id'] != $ank['id']) if (User::friend ($user['id'], $ank['id']) == false) Core::redirect ("Гостевая открыта только для друзей!", HTTP."/err");

 ## Отмечаем уведомление в журнале как прочитаноt
 if ($user and isset ($_GET['journal'])) User::journal_update ($_GET['journal'], $user['id']);

 ## Редактирование комментария
 if (isset ($_GET['edit']) and !empty ($_GET['edit'])) { include_once $_SERVER['DOCUMENT_ROOT'].'/pages/book/inc/edit_comment.php'; exit; }

 ## Удаляем комментарий
 if (isset ($_GET['delete']) and $user['id'] == $ank['id']) {

     $CK = (int) abs ($_GET['CK']);

     ## Если верный CK
     if ($CK == $user['CK']) {

         $comment_id = (int) abs ($_GET['delete']);
 
         ## Находим комментарий и проверяем пренадлежит ли он автору этой гостевой
         $queryTestComment = $DB -> query ("SELECT `id` FROM `user_book` WHERE `id` = '".$comment_id."' AND `book_id` = '".$user['id']."'");

         ## Если есть совпадение
         if ($queryTestComment -> RowCount () > 0) {

             ## Удаляем клмментарий
             $DB -> query ("DELETE FROM `user_book` WHERE `id` = '".$comment_id."'");

             ## Оповещаем о удаленном комментарии
             Core::redirect_ok ("Комментарий удален", HTTP."/uid".$user['id']."/book");

         }
         else Core::redirect ("Комментарий не найден!", HTTP."/uid".$user['id']."/book");

     }
     else Core::redirect ("Не верный CK!", HTTP."/uid".$user['id']."/book");

 }

 ## Пагинация для комментариев
 $c_p = $DB -> query ("SELECT * FROM `user_book` WHERE `book_id` = '".$ank['id']."'") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryComments = $DB -> query ("SELECT * FROM `user_book` WHERE `book_id` = '".$ank['id']."' ORDER BY `time` DESC LIMIT $start, ".$p_page."");
 $countComments = $DB -> query ("SELECT * FROM `user_book` WHERE `book_id` = '".$ank['id']."'") -> RowCount ();

 if (isset ($_POST['comment'])) {

     Core::CheckUser ();

     $message = Core::check ($_POST['message']);
     $CK = (int) abs ($_POST['CK']);

     if ($CK == $user['CK']) {

         if (empty ($message)) $err = '<div class = "err">Введите комментарий!</div>';
         else {

             if (strlen($message) > 3000) $err = '<div class = "err">Комментарий не должен превышать 3000 символов!</div>';
             else {

                 $queryAddComment = $DB -> query ("INSERT INTO `user_book` SET
                                                  `book_id` = '".$ank['id']."',
                                                  `user_id` = '".$user['id']."',
                                                  `reply_id` = '0',
                                                  `message` = ".$DB -> quote ($message).",
                                                  `time` = '".time ()."'");

                 if ($user['id'] != $ank['id']) User::journal_add ($user['id'], $ank['id'], $message, 3, '/uid'.$ank['id'].'/book/?');

                 header ('Location: '.HTTP.'/uid'.$ank['id'].'/book/');

             }

         }
     
     }
     else Core::redirect ("Не верный CK!", HTTP."/uid".$ank['id']."/book/");

 }

 $description = $ank['login'].' / Гостевая';
 $keywords = NULL;
 $title = $ank['login'].' / Гостевая';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'
             
             </a>

             <span class = "ico next"></span>

             Гостевая

         </div>

         <div class = "background_place">
 ';

 Core:: Ok ();
 Core:: Error ();

 if ($queryComments -> RowCount () < 1) {

    echo '
         
         <div class = "main_place">

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 Комментариев

                 <span class="count_web" style="padding: 0 8px 0 8px;">'.$countComments.'</span>

             </a>

         </div>

         <div class = "place">

             Комментарии отсуствуют

         </div>

    ';

 }
 else {

     echo '

         <div class = "main_place">

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 Комментариев

                 <span class="count_web" style="padding: 0 8px 0 8px;">'.$countComments.'</span>

             </a>

         </div>

     ';

     while ($comment = $queryComments -> fetch ()) {

         echo '

         <div class = "comment">

             <div id = "avatar">

                 '.Core::avatar ($comment['user_id'], 40).'

             </div>

             <div id = "content">

                 '.Core::user ($comment['user_id'], 1, 1, 1).'

                 <small id = "right">

                     '.Core::date_time ($comment['time']).'

                 </small>

                 <br />

                 '.Core::bb ($comment['message']).'

             </div>

         </div>

         <div id = "content_nav"> &nbsp;

             <a class = "edit_c" href = "">Ответ</a>

             <span id = "right">

                 '.($comment['user_id'] == $user['id'] && $comment['time'] > $conf['edit_comment'] ? '<a class = "edit_c" href = "'.HTTP.'/uid'.$ank['id'].'/book/?edit='.$comment['id'].'">Изменить</a> ' : '').'
             
                 '.($user['id'] == $ank['id'] ? '<a href = "'.HTTP.'/uid'.$user['id'].'/book/?delete='.$comment['id'].'&CK='.$user['CK'].'" class = "delete_c">Удалить</a> ' : ' ').'

             </span>

         </div>

         ';


     }

 if ($k_page > 1) Core::str(''.HTTP.'/uid'.$ank['id'].'/book/?', $k_page, $page);

 }

 if ($ank['book_comments'] == 2) {

     if ($ank['id'] != $user['id']) echo '<div class = "err">Комментировать запрещено всем!</div>';
     else {

         echo '

         '.$err.'

         <div class = "nav">

             <form action = "" method = "POST">

                 <textarea name="message"  placeholder = "Оставить комментарий...">'.(isset ($_POST['comment']) ? $message : '').'</textarea>

                 <br />

                 <input type = "submit" name = "comment" value = "Написать"/>

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

             </form>

         </div>

         ';

     }

 }

 if ($ank['book_comments'] == 1) {

     if (User::friend ($user['id'], $ank['id']) == true or $ank['id'] == $user['id']) {

         echo '

         '.$err.'

         <div class = "nav">

             <form action = "" method = "POST">

                 <textarea name="message"  placeholder = "Оставить комментарий...">'.(isset ($_POST['comment']) ? $message : '').'</textarea>

                 <br />

                 <input type = "submit" name = "comment" value = "Написать"/>

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

             </form>

         </div>

         ';

     }
     else echo '<div class = "err">Комментировать разрешено только друзьям!</div>';

 }

 if ($ank['book_comments'] == 0) {

     echo '

         '.$err.'

         <div class = "nav">

             <form action = "" method = "POST">

                 <textarea name="message"  placeholder = "Оставить комментарий...">'.(isset ($_POST['comment']) ? $message : '').'</textarea>

                 <br />

                 <input type = "submit" name = "comment" value = "Написать"/>

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

             </form>

         </div>

     ';

 }

 echo '
 
         </div>

         </div>

 ';

 if ($user['id'] == $ank['id']) echo '<a href = "'.HTTP.'/settings/book/" class = "home"><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/settings.png"> Настройки гостевой</a>';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'
             
             </a>

             <span class = "ico next"></span>
             
             Гостевая

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>