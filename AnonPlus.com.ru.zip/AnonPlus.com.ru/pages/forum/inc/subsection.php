<?php

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $section_id = (int) abs ($_GET['section']);
 $sub_id = (int) abs ($_GET['sub']);

 $querySubSection = $DB -> query ("SELECT * FROM `forum_subsection` WHERE `id` = '".$sub_id."' AND `section_id` = '".$section_id."' LIMIT 1");

 if ($querySubSection -> RowCount () < 1) Core::redirect ("Подраздел не существует!", HTTP."/forum/?");

 $sub = $querySubSection -> fetch ();
 $section = $DB -> query ("SELECT * FROM `forum_section` WHERE `id` = '".$sub['section_id']."'") -> fetch ();

 if ($user and isset ($_GET['new_theme'])) { require_once $_SERVER['DOCUMENT_ROOT'].'/pages/forum/inc/new_theme.php'; exit; }

 if (isset ($_GET['theme'])) { require_once $_SERVER['DOCUMENT_ROOT'].'/pages/forum/inc/theme.php'; exit; }

 $description = 'Форум / '.$section['name'].' / '.$sub['name'].'';
 $keywords = 'Форум, '.$section['name'].', '.$sub['name'].'';
 
 $title = 'Форум / '.$section['name'].' / '.$sub['name'].'';
 
 require_once $_SERVER['DOCUMENT_ROOT'].'/template/header.php';

 echo '

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">
                 
                 Форум

             </a>

             <span class = "ico next"></span> 

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'">

                '.$section['name'].'

             </a>

             <span class = "ico next"></span>

             '.$sub['name'].'

         </div>

 ';

 Core:: Error ();
 Core:: Ok ();

 $c_p = $DB -> query ("SELECT * FROM `forum_themes` WHERE `subsection` = '".$sub['id']."'") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryThemes = $DB -> query ("SELECT * FROM `forum_themes` WHERE `subsection` = '".$sub['id']."' ORDER BY `time` DESC LIMIT $start, ".$p_page."");

 if ($queryThemes -> RowCount () < 1) echo '<div class = "block">Темы отсуствуют!</div>';
 else {

     echo '

         <div class = "background_place">

             <div class = "main_place">

     ';

     while ($theme = $queryThemes -> fetch ()) {

     	 $u = $DB -> query ("SELECT `login` FROM `users` WHERE `id` = '".$theme['user_id']."'") -> fetch ();

         if ($theme['closed'] == 1) $closed = ' <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/topic_locked.png">';
         else $closed = NULL;

         $count = $DB -> query ("SELECT `id` FROM `forum_comments` WHERE `theme_id` = '".$theme['id']."'") -> RowCount ();
         $countLogin = $DB -> query ("SELECT `user_id` FROM `forum_comments` WHERE `theme_id` = '".$theme['id']."'ORDER BY `time` DESC LIMIT 1") -> fetch ();
         $reply = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".$countLogin['user_id']."'") -> fetch ();

         $r = (!empty ($reply['id'])) ? '/ '.$reply['login'] : NULL;

     	 echo '

                 <div>

                     <a href="'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id'].'" class="list-link">
                
                         <div class="list-link__text">

                             '.$theme['name'].' 

                             <small class = "count_web">

                                 '.$count.'

                             </small>

                             '.$closed.'  

                             <small id = "right">

                                 '.Core::date_time ($theme['time']).'

                             </small>

                             <br>

                             <span class="private_info">

                                 <small>

                                     '.$u['login'].' '.$r.'

                                 </small>

                             </span>

                         </div>
 
                     </a>

                 </div>

     	';     

     }

     if ($k_page > 1) Core::str(''.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&', $k_page, $page);

     echo '

             </div>

         </div>

     ';

 }

 ## Получаем данные о банах узера в чате
 $vote = ($user) ? $DB -> query ("SELECT `ban_time`, `time` FROM `user_ban_list` WHERE `user_id` = '".$user['id']."' AND ((`type` = 'forum_theme') OR (`type` = 'forum_comment')) ORDER BY `ban_time` DESC") -> fetch () : 0;

 if ($user and $sub['id'] != 5 and (time () > ($vote['time']+$vote['ban_time']))) {

     echo '

         <a class = "list-link" style = "padding: 13px; border-top: 1px solid #eee;" href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&new_theme">

             
             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/add.png">

             Новая тема

         </a>

     ';
 
 }

 echo '

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">
                 
                 Форум

             </a>

             <span class = "ico next"></span> 

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'">

                '.$section['name'].'

             </a>

             <span class = "ico next"></span>

             '.$sub['name'].'

         </div>

 ';
 require_once $_SERVER['DOCUMENT_ROOT'].'/template/footer.php';

?>
