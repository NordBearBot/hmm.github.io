<?php

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 if ($sub['id'] == 5) Core::redirect ("Нельзя создавать темы в Архиве!", HTTP."/forum/");

 ## Получаем данные о банах узера
 $vote = $DB -> query ("SELECT `ban_time`, `time` FROM `user_ban_list` WHERE `user_id` = '".$user['id']."' AND ((`type` = 'forum_theme') OR (`type` = 'forum_comment')) ORDER BY `ban_time` DESC") -> fetch ();
 if (time () < ($vote['time']+$vote['ban_time'])) Core::redirect ("Вы забанены в форуме, дождитесь окончания бана!", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']);

 $title = 'Форум / Новая тема';
 
 require_once $_SERVER['DOCUMENT_ROOT'].'/template/header.php';

 echo '

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">
                 
                 Форум

             </a>

             <span class = "ico next"></span> 

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'">

                '.$section['name'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'">

                '.$sub['name'].'

             </a>

         </div>

 ';

  if (isset ($_POST['add'])) {

     $name = Core::check ($_POST['name']);
     $msg = Core::check ($_POST['msg']);
     $CK = (int) abs ($_POST['CK']);

     if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']."&new_theme.");

     $err = (empty ($name) ? '<div class = "err">Введите название темы!</div>' : (Core::utf_strlen ($name) > 70 ? '<div class = "err">Название не должно первышать 70 символов!</div>' : NULL));
     $err2 = (empty ($msg) ? '<div class = "err">Введите описание темы!</div>' : (Core::utf_strlen ($msg) > 20000 ? '<div class = "err">Описание не должно первышать 20000 символов!</div>' : NULL));

     if (empty ($err) and empty ($err2)) {

         $DB -> query ("INSERT INTO `forum_themes` SET
        	                        `subsection` = '".$sub['id']."',
        	                        `user_id` = '".$user['id']."',
        	                        `name` = ".$DB -> quote ($name).",
        	                        `msg` = ".$DB -> quote ($msg).",
        	                        `time` = '".time ()."'");

         $DB -> query ("UPDATE `forum_subsection` SET `count_theme` = `count_theme` +1 WHERE `id` = '".$sub['id']."'");

         $theme = $DB -> query ("SELECT * FROM `forum_themes` WHERE `user_id` = '".$user['id']."' ORDER BY `time` DESC LIMIT 1") -> fetch ();

        header ('Location: '.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id'].'');

     }

 }

         echo '

         <div class = "background_place">

             <div class = "main_place">

                 <form action = "" method = "POST">

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                     Новая тема

                     </a>

                 </div>

                 <div class = "place private_info user_info" style = "border-bottom: 1px solid #eee;">

                     Внимание! Перед созданием темы воспользуйтесь Поиском, Если такая тема уже существует, то вы получите предупреждение, а тема будет закрыта. 

                     <br />

                     Если вам нужна помощь, зайдите сюда: Сервис помощи обитателям.

                 </div>

                 '.$err.'

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     Тема: 

                     <small class = "private_info" id = "right">70 знаков</small>

                     <br />

                     <input type = "text" name = "name"> 

                 </div>

                 '.$err2.'

                 <div class = "place user_info">

                     Описание:

                     <small class = "private_info" id = "right">20000 знаков</small></small>

                     <br />

                     <textarea name = "msg"></textarea> 

                     <br />

                     <input type = "submit" name = "add" value = "Создать">

                     <input type="hidden" name="CK" value="'.$user['CK'].'" />

                 </div>

                 </form>

             </div>

         </div>

         '; 

 echo '

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">
                 
                 Форум

             </a>

             <span class = "ico next"></span> 

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'">

                '.$section['name'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'">

                '.$sub['name'].'

             </a>

         </div>

 ';

 require_once $_SERVER['DOCUMENT_ROOT'].'/template/footer.php';

?>
