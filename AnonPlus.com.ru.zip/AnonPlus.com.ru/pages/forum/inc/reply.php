<?php

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 
 Core::CheckUser ();

 $comment_id = (int) abs ($_GET['reply']);
 $queryComment = $DB -> query ("SELECT * FROM `forum_comments` WHERE `id` = '".$comment_id."' AND `theme_id` = '".$theme['id']."' LIMIT 1");
 
 if ($queryComment -> RowCount () < 1) Core::redirect ("Комментарий не найден!", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']."&theme=".$theme['id']);
 $comment = $queryComment -> fetch ();

 ## Получаем данные о банах узера
 $vote = $DB -> query ("SELECT `ban_time`, `time` FROM `user_ban_list` WHERE `user_id` = '".$user['id']."' AND ((`type` = 'forum_theme') OR (`type` = 'forum_comment')) ORDER BY `ban_time` DESC") -> fetch ();
 if (time () < ($vote['time']+$vote['ban_time'])) Core::redirect ("Вы забанены в форуме, дождитесь окончания бана!", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']);

 if ($theme['closed'] == 1) if ($user['level'] != 1 or $user['level'] != 4) header ('Location: '.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id']);
 
 if ($comment['user_id'] == $user['id']) Core::redirect ("Нельзя отвечать на свои комментарии!", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']."&theme=".$theme['id']);

 if (isset ($_POST['reply'])) {

     $msg = (string) Core::check ($_POST['message']);
     $CK = (int) abs ($_POST['CK']);
     
     if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']."&theme=".$theme['id']."&reply=".$comment['id']);
     $err = (empty ($msg) ? '<div class = "err">Введите комментарий!</div>' : (Core::utf_strlen ($msg) > 10000 ? '<div class = "err">Комментарий не должен превышать 10000 символов!</div>' : NULL));

     if (empty ($err)) {

         $DB -> query ("INSERT INTO `forum_comments` SET
                       `theme_id` = '".$theme['id']."',
                       `user_id` = '".$user['id']."',
                       `reply_id` = '".$comment['user_id']."',
                       `msg` = ".$DB -> quote ($msg).",
                       `time` = '".time ()."'");

         ## Уведомление в журнал
         User::journal_add ($user['id'], $comment['user_id'], $msg, 5, '/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id']);

         header ('Location: '.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id']);

     }
 
 }

 $title = 'Форум / '.$ank['login'].': '.$theme['name'];
 
 require_once $_SERVER['DOCUMENT_ROOT'].'/template/header.php';

 echo '

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">
                 
                 Форум

             </a>

             <span class = "ico next"></span> 

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'">

                '.$section['name'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'">

                '.$sub['name'].'

             </a>

         </div>

 ';
 echo '
 
         <div class = "background_place">

             <div class = "main_place">

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                         Ответ

                     </a>

                 </div>

                 <div class = "place">

                     <div id = "avatar">

                         '.User::avatar ($comment['user_id'], 40, 'mini', $avatar_mini_style).'

                     </div>

                     <div id = "username_avatar">

                         '.Core::user ($comment['user_id'], 1, 1, 1).'

                         <small id = "right" class = "private_info">

                             '.Core::date_time ($comment['time']).'

                         </small>

                     </div>

                     <span id = "top_v" style = "margin-left: 15px; margin-top: 13px;"></span>

                     <div class = "status">

                         '.Core::bb ($comment['msg']).'
                         
                     </div>

                 </div>

                 <div class = "nav">

                     <form action = "" method = "POST">

                         <textarea name="message"  placeholder = "Ответ..."></textarea>

                         <br />

                         <input type = "submit" name = "reply" value = "Написать"/>

                         <input type="hidden" name="CK" value="'.$user['CK'].'" />

                     </form>

                 </div>

                 <a class="home" href="'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id'].'">

                     &larr; Вернуться в тему

                 </a>
 
             </div>

         </div>

 ';

 echo '

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">
                 
                 Форум

             </a>

             <span class = "ico next"></span> 

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'">

                '.$section['name'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'">

                '.$sub['name'].'

             </a>

         </div>

 ';

 require_once $_SERVER['DOCUMENT_ROOT'].'/template/footer.php';

?>