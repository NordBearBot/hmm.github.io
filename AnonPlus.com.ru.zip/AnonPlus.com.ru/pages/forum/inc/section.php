<?php

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $section_id = (int) abs ($_GET['section']); 

 $querySection = $DB -> query ("SELECT * FROM `forum_section` WHERE `id` = '".$section_id."' LIMIT 1");

 if ($querySection -> RowCount () < 1) Core::redirect ("Раздел не существует!", HTTP."/forum/?");
 $section = $querySection -> fetch ();

 if (isset ($_GET['sub'])) { require_once $_SERVER['DOCUMENT_ROOT'].'/pages/forum/inc/subsection.php'; exit; }

 if (isset ($_GET['new'])) {
    if ($user['level'] == 1 or $user['level'] == 5) {
 
         $title = $section['name'].' / Новый подраздел';

         require_once $_SERVER['DOCUMENT_ROOT'].'/template/header.php';

         if (isset ($_GET['go']) and isset ($_POST['go'])) {

            if (empty ($_POST['name'])) $err = '<br /><small><font color = "darkred">Введите название подраздела!</font></small>';
            else {

               $queryAddSection = $DB -> prepare ("INSERT INTO `forum_subsection` SET `id` = 'NULL', `section_id` = ?, `name` = ?, `info` = ?");
               $queryAddSection -> execute (Array ($section['id'], $_POST['name'], $_POST['info']));

               Core::redirect_ok ("Подраздел создан!", HTTP."/forum/?section=".$section['id']."");

            }

         }

         if (isset ($_POST['add'])) {

             $name = Core::check ($_POST['name']);
             $info = Core::check ($_POST['info']);
             $CK = (int) abs ($_POST['CK']);

             if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/forum/?new");
             if (empty ($name)) Core::redirect ("Введите название раздела!", HTTP."/forum/?new");

             $DB -> query ("INSERT INTO `forum_subsection` SET `section_id` = '".$section['id']."', `name` = ".$DB -> quote ($name).", `info` = ".$DB -> quote ($info)."");

             Core::redirect_ok ("Подраздел создан!", HTTP."/forum/?section=".$section['id']);

         }
   
         echo '

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">
                 
                 Форум

             </a>

             <span class = "ico next"></span> 

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'">
                 
                 '.$section['name'].'

             </a>

             <span class = "ico next"></span> 

             Новый подраздел

         </div>

        ';

         echo '

             <form action = "" method = "POST">

                 <div class = "block">

                     Название раздела: <br />
                     <input type = "text" name = "name"> 

                     <br />

                     Описание: <br />
                     <textarea name = "info"></textarea> 

                     <input type = "submit" name = "add" value = "Создать">

                     <input type="hidden" name="CK" value="'.$user['CK'].'" />

                 </div>

             </form>

         ';

         echo '

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">
                 
                 Форум

             </a>

             <span class = "ico next"></span> 

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'">
                 
                 '.$section['name'].'

             </a>

             <span class = "ico next"></span> 

             Новый подраздел

         </div>

         ';

         require_once $_SERVER['DOCUMENT_ROOT'].'/template/footer.php';
         exit;
    }
    else header ('Location: '.HTTP.'/forum/?section='.$section['id'].'');
 }

 $description = 'Vizaire.Ru / Форум / '.$section['name'].'';
 $keywords = 'Форум, '.$section['name'].'';
 
 $title = 'Форум / '.$section['name'].'';
 
 require_once $_SERVER['DOCUMENT_ROOT'].'/template/header.php';

 echo '

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">
                 
                 Форум

             </a>

             <span class = "ico next"></span> 

             '.$section['name'].'

         </div>

 ';

 Core:: Error ();
 Core:: Ok ();

     $querySubSections = $DB -> query ("SELECT * FROM `forum_subsection` WHERE `section_id` = '".$section['id']."'");

     if ($querySubSections -> RowCount () > 0) {

         echo '

         <div class = "background_place">

             <div class = "main_place">

         ';

         while ($sub = $querySubSections -> fetch ()) {

             echo '

             <a class = "home" href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'">

                 '.$sub['name'].'

                 <small class = "count">

                     '.$sub['count_theme'].'

                 </small>

                 <br />

                 <small>

                     '.$sub['info'].'

                 </small>

             </a>

             ';

         }

         echo '

             </div>

         </div>

         ';

     }
     else echo '<div class = "block"><font color = "darkred">Подразделов нет!</font></div>';    

     if ($user['level'] == 1) {

          echo '

         <a class = "list-link" style = "padding: 13px; border-top: 1px solid #eee;" href = "'.HTTP.'/forum/?section='.$section['id'].'&new">

             
             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/add.png">

             Добавить подраздел

         </a>

         ';

     }

 echo '

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">
                 
                 Форум

             </a>

             <span class = "ico next"></span> 

             '.$section['name'].'

         </div>

 ';

 require_once $_SERVER['DOCUMENT_ROOT'].'/template/footer.php';

?> 