<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 if ($user and ($user['level'] == 4 or $user['level'] == 1)) {

 $c_p = $DB -> query ("SELECT * FROM `forum_themes` WHERE `status_check` = '1'") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryChatMod = $DB -> query ("SELECT * FROM `forum_themes` WHERE `status_check` = '1' ORDER BY `id` DESC LIMIT $start, ".$p_page."");
 $countMod = $DB -> query ("SELECT * FROM `forum_themes` WHERE `status_check` = '1'") -> RowCount ();

 $title = 'Форум / Модерирование тем';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">

                 Форум

             </a>

             <span class = "ico next"></span> 
 
             Модерирование тем

         </div>
 ';
 
 Core:: Error ();
 Core:: Ok ();

 echo '

         <div class = "background_place">


 ';

 if ($queryChatMod -> RowCount () < 1) {

     echo '

             <div class = "main_place">

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                         Непроверенные темы

                     </a>

                 </div>

                 <div class = "place">

                     Темы отсуствуют!

                 </div>

             </div>

     ';

 }
 else {

     echo '

         <div class="main_place b-title b-title_first" style = "margin-bottom: 0;">

             <a class="b-title__link">

                 Непроверенные темы

                 <span class = "count_web">

                     '.$countMod.'

                 </span>

             </a>

         </div>

     ';

     while ($theme = $queryChatMod -> fetch ()) {

         $sub = $DB -> query ("SELECT `section_id`, `id`, `name` FROM `forum_subsection` WHERE `id` = '".$theme['subsection']."'") -> fetch ();
         $section = $DB -> query ("SELECT `id`, `name` FROM `forum_section` WHERE `id` = '".$sub['section_id']."'") -> fetch ();

         echo '

             <div class = "main_place">

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     '.Core::user ($theme['user_id'], 1, 1, 1).' <span class = "private_info">'.$theme['name'].'</span>

                     <small id = "right" class = "private_info">

                         '.Core::date_time ($theme['time']).'

                     </small>

                     <br />

                     '.Core::CropStr ($theme['msg'], 200).'

                 </div>

                 <div class = "place private_info">

                     Форум / '.$section['name'].' / '.$sub['name'].'

                 </div>

                 <a class = "home" href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id'].'">Войти в тему</a>

             </div>

         ';

     }

     if ($k_page > 1) Core::str(''.HTTP.'/forum/?list_check&', $k_page, $page);

 }
 
 echo '

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">

                 Форум

             </a>

             <span class = "ico next"></span> 
 
             Модерирование тем

         </div>
 ';

 include_once ROOT.'/template/footer.php';
 
 }
 else header('Location: '.HTTP.'/forum');

?>