<?php 

 $queryTryRemark = $DB -> query ("SELECT `id` FROM `user_ban_list` WHERE `type` = 'forum_theme' AND `object_id` = '".$theme['id']."'");
 if ($queryTryRemark -> RowCount () > 0) Core::redirect ("Уже было выдано нарушение за эту тему!", HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id']);

 $ank = $DB -> query ("SELECT `login`, `id` FROM `users` WHERE `id` = '".$theme['user_id']."'") -> fetch ();

 if (isset ($_POST['ban'])) {

     $CK = (int) abs ($_POST['CK']);
     if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id']);

     $msg = (string) Core::check ($_POST['msg']);
     $err = (Core::utf_strlen ($msg) > 1000) ? '<div class = "err">Сообщение не должно превышать 1000 символов!</div>' : NULL;

     if (empty ($err)) {

         $what = (int) abs ($_POST['what']);
         $what = ($what > 11) ? 11 : $what;

         $time = (int) abs ($_POST['time']);
         $time = ($time > 6) ? 0 : $time;
 
         $time_ban = ($time == 0 ? 3600 : ($time == 1 ? 10800 : ($time == 2 ? 43200 : ($time == 3 ? 86400 : ($time == 4 ? 172800 : ($time == 5 ? 432000 : ($time == 6 ? 864000 : 3600)))))));
     
         $DB -> query ("INSERT INTO `user_ban_list` SET
                       `type` = 'forum_theme',
                       `object_id` = '".$theme['id']."',
                       `user_id` = '".$theme['user_id']."',
                       `moder_id` = '".$user['id']."',
                       `time` = '".time ()."',
                       `ban_time` = '".$time_ban."',
                       `what` = '".$what."',
                       `message` = ".$DB -> quote ($msg)."");

         Core::redirect_ok ("Пользователь забанен!", HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id']);

     }

 }

 $title = 'Форум / Забанить обитателя';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">

                 Форум

             </a>

             <span class = "ico next"></span> 
 
             Забанить обитателя

         </div>
 ';
 
 Core:: Error ();
 Core:: Ok ();

 echo '

         <div class = "background_place">

             <form action = "" method = "POST">

             <div class = "main_place">

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                         Бан

                     </a>

                 </div>

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     '.Core::user ($ank['id'], 1, 1, 1).'

                     <small class = "private_info" id = "right">

                         '.Core::date_time ($theme['time']).'

                     </small>

                     <br />

                     '.Core::CropStr (Core::bb ($theme['msg']), 500).'

                 </div>

                 <div class = "place" style = "border-bottom: 1px solid #eee;">

                     <a class = "private_info" href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'">

                         Форум / '.$section['name'].' / '.$sub['name'].'

                     </a>

                 </div>

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     <b>Причина</b>:

                     <br />

                     <input type="radio" name="what" value="0" checked="checked" /> Грубость и оскорбления

                     <br />

                     <input type="radio" name="what" value="1"/> Нецензурная лексика

                     <br />

                     <input type="radio" name="what" value="2"/> СПАМ, реклама

                     <br />

                     <input type="radio" name="what" value="3"/> Разжигание ненависти

                     <br />

                     <input type="radio" name="what" value="4"/> Флуд, Оффтопик

                     <br />

                     <input type="radio" name="what" value="5"/> Нежелание пользоваться поиском

                     <br />

                     <input type="radio" name="what" value="6"/> Некорректное название темы

                     <br />

                     <input type="radio" name="what" value="7"/> Бессмысленная тема  

                     <br />

                     <input type="radio" name="what" value="8"/> Намеки на ДП

                     <br />

                     <input type="radio" name="what" value="9"/> ДП

                     <br />

                     <input type="radio" name="what" value="10"/> Педофилия

                     <br />

                     <input type="radio" name="what" value="11"/> Иное

                 </div>

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     <b4>Бан на:</b4>

                     <br />

                     <select name = "time">
                         
                         <option value="0">1 ч.</option>
                        
                         <option value="1">3 ч.</option>

                         <option value="2">12 ч.</option>  

                         <option value="3">24 ч.</option>

                         <option value="4">48 ч.</option>

                         <option value="5">120 ч.</option>

                         <option value="6">240 ч.</option>        

                     </select> 

                 </div>

                 '.$err.'

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     Комментарий:

                     <br />

                     <textarea name = "msg"></textarea>

                     <br />

                     <input type = "submit" name = "ban" value = "Забанить">

                     <input type = "hidden" name = "CK" value = "'.$user['CK'].'">

                 </div>

             </div>

             </form>

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">

                 Форум

             </a>

             <span class = "ico next"></span> 
 
             Забанить обитателя

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>