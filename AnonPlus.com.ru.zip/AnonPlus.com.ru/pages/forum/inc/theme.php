<?php
 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $theme_id = (int) abs ($_GET['theme']);

 $queryTheme = $DB -> query ("SELECT * FROM `forum_themes` WHERE `id` = '".$theme_id."' AND `subsection` = '".$sub['id']."'");

 if ($queryTheme -> RowCount () < 1) Core::redirect ("Тема не существует", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']."");
 $theme = $queryTheme -> fetch ();

 if (isset ($_GET['check']) and ($user['level'] == 1 or $user['level'] == 4)) {

     $CK = (int) abs ($_GET['CK']);
     if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']."&theme=".$theme['id']);

     if ($theme['status_check'] == '1') {

         $DB -> query ("UPDATE `forum_themes` SET `status_check` = '0', `check_user_id` = '".$user['id']."', `check_time` = '".time ()."' WHERE `id` = '".$theme['id']."'");
         Core::redirect_ok ("Тема успешно отмечена как проверенная!", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']."&theme=".$theme['id']);
     
     } else Core::redirect ("Тема уже проверена!", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']."&theme=".$theme['id']);

 }

 $ank = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".$theme['user_id']."'") -> fetch ();

 if ((isset ($_GET['ban_theme']) and ($user['level'] == 1 or $user['login'] == 4))) { require_once $_SERVER['DOCUMENT_ROOT'].'/pages/forum/inc/ban_theme.php'; exit; }
 if ((isset ($_GET['ban_comment']) and ($user['level'] == 1 or $user['login'] == 4))) { require_once $_SERVER['DOCUMENT_ROOT'].'/pages/forum/inc/ban_comment.php'; exit; }

 if (isset ($_GET['reply'])) { require_once $_SERVER['DOCUMENT_ROOT'].'/pages/forum/inc/reply.php'; exit; }

 $closed = ($theme['closed'] == 1) ? ' <img src = "'.HTTP.'/files/system.images/site.icons/topic_locked.png">' : '';

 if ($theme['closed'] == 1) {

     $u = $DB -> query ("SELECT `id`, `login`, `level` FROM `users` WHERE `id` = '".$theme['closed_id']."'") -> fetch ();
     $level = ($u['level'] == 1 ? 'Администратором' : ($u['level'] == 4 ? 'Модератором' : ''));

     $status_closed_txt = '<div class = "block"><small>Тема закрыта '.$level.' <a href = "'.HTTP.'/uid'.$u['id'].'"><b>'.$u['login'].'</b></small></div>';

 }

 if ($user['level'] == 1 or $user['level'] == 4) $vote = $DB -> query ("SELECT `moder_id`, `id` FROM `user_ban_list` WHERE `type` = 'forum_theme' AND `object_id` = '".$theme['id']."'") -> fetch ();
 
 if ($user and isset ($_GET['journal'])) User::journal_update ($_GET['journal'], $user['id']);

 $queryTest = $DB -> query ("SELECT `id` FROM `bookmarks` WHERE `user_id` = '".$user['id']."' AND `type` = '4' AND `object_id` = '".$theme['id']."'") -> RowCount ();
 $bookmark = ($queryTest < 1) ? '<a href="'.HTTP.'/bookmarks/add/?type=4&id='.$theme['id'].'" class="adv_user_link" id="bookmark_link" title="Добавить в закладки"><span></span></a>' : '<a href="'.HTTP.'/bookmarks/delete/?type=4&id='.$theme['id'].'" class="adv_user_link" id="bookmark_link" title="Удалить из закладок"><span style="background-position: -32px -16px; !important;"></span></a>';
 
 if ((isset ($_GET['closed']) and ($user['level'] == 1 or $user['level'] == 4))) {
 
     $prepare_status_theme = (int) abs ($_GET['closed']);
     $CK = (int) abs ($_GET['CK']);

     if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']."&theme=".$theme['id']);

     if ($prepare_status_theme == 1 and $theme['closed'] == 0) {

         $DB -> query ("UPDATE `forum_themes` SET `closed` = '1', `closed_id` = '".$user['id']."' WHERE `id` = '".$theme['id']."'");
         header ('Location: '.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id']);

     }
     else if ($prepare_status_theme == 0 and $theme['closed'] == 1) {

         $DB -> query ("UPDATE `forum_themes` SET `closed` = '0', `closed_id` = '' WHERE `id` = '".$theme['id']."'");
         header ('Location: '.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id']);

     }

     header ('Location: '.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id']);

 }

 if ((isset ($_GET['del_com']) and ($user['level'] == 1 or $user['level'] == 4))) {
 
     $comment_id = (int) abs ($_GET['del_com']);
     $CK = (int) abs ($_GET['CK']);

     if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']."&theme=".$theme['id']);

     $queryTest = $DB -> query ("SELECT `id` FROM `forum_comments` WHERE `id` = '".$comment_id."' AND `theme_id` = '".$theme['id']."'");

     if ($queryTest -> RowCount () < 1) Core::redirect ("Комментарий не найден!", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']."&theme=".$theme['id']);

     $DB -> query ("DELETE FROM `forum_comments` WHERE `id` = '".$comment_id."'");

     header ('Location: '.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id']);

 }

 if ((isset ($_GET['delete']) and ($user['level'] == 1 or $user['level'] == 4))) {
 
     $prepare_delete_theme = (int) abs ($_GET['delete']);
     $CK = (int) abs ($_GET['CK']);

     if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']."&theme=".$theme['id']);

     if ($prepare_delete_theme == 1 and $theme['delete'] == 0) {

         $DB -> query ("UPDATE `forum_subsection` SET `count_theme` = `count_theme` -1 WHERE `id` = '".$sub['id']."'");
         $DB -> query ("UPDATE `forum_subsection` SET `count_theme` = `count_theme` +1 WHERE `id` = '5'");

         $DB -> query ("UPDATE `forum_themes` SET 
                               `delete` = '1',
                               `closed` = '1',
                               `closed_id` = '".$user['id']."',
                               `delete_subsection` = '".$theme['subsection']."',
                               `delete_user_id` = '".$user['id']."',
                               `subsection` = '5'
                               WHERE `id` = '".$theme['id']."'");

         $DB -> query ("INSERT INTO `forum_comments` SET
                       `theme_id` = '".$theme['id']."',
                       `user_id` = '0',
                       `msg` = 'Тема удалена ".($user['level'] == 1 ? 'Администратором' : 'Модератором')." [url=".HTTP."/uid".$user['id']."]".$user['login']."[/url]',
                       `time` = '".time ()."'");


         header ('Location: '.HTTP.'/forum/?section=167&sub=5&theme='.$theme['id']);

     }
     else if ($prepare_delete_theme == 0 and $theme['delete'] == 1) {

         $DB -> query ("UPDATE `forum_subsection` SET `count_theme` = `count_theme` +1 WHERE `id` = '".$theme['delete_subsection']."'");
         $DB -> query ("UPDATE `forum_subsection` SET `count_theme` = `count_theme` -1 WHERE `id` = '5'");

         $DB -> query ("UPDATE `forum_themes` SET 
                               `subsection` = '".$theme['delete_subsection']."',
                               `delete_user_id` = '".$user['id']."',
                               `delete` = '0' 
                               WHERE `id` = '".$theme['id']."'");
         $DB -> query ("INSERT INTO `forum_comments` SET
                       `theme_id` = '".$theme['id']."',
                       `user_id` = '0',
                       `msg` = 'Тема восстановлена ".($user['level'] == 1 ? 'Администратором' : 'Модератором')." [url=".HTTP."/uid".$user['id']."]".$user['login']."[/url]',
                       `time` = '".time ()."'");
         $subs = $DB -> query ("SELECT `section_id` FROM `forum_subsection` WHERE `id` = '".$theme['delete_subsection']."'") -> fetch ();

         header ('Location: '.HTTP.'/forum/?section='.$subs['section_id'].'&sub='.$theme['delete_subsection'].'&theme='.$theme['id']);

     }

 }

 $description = $theme['name'].' - Форум '.DOMAIN;
 $keywords = 'Форум, '.$section['name'].', '.$sub['name'].', '.$theme['name'].'';
 
 $title = $theme['name'].' - Форум '.DOMAIN;
 
 require_once $_SERVER['DOCUMENT_ROOT'].'/template/header.php';

 echo '

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">
                 
                 Форум

             </a>

             <span class = "ico next"></span> 

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'">

                '.$section['name'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'">

                '.$sub['name'].'

             </a>

         </div>

 ';

 Core::Error ();
 Core::Ok ();

 if (($theme['status_check'] == 1 and ($user['level'] == 1 or $user['level'] == 4))) echo '<a class = "home" href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id'].'&check&CK='.$user['CK'].'">Отметить тему как проверенную</a>';
 if (($theme['status_check'] == 0 and ($user['level'] == 1 or $user['level'] == 4))) echo '<div class = "place private_info">Тему проверил '.Core::user ($theme['check_user_id'], 1, 1, 1).' <small id = "right">'.Core::date_time ($theme['check_time']).'</small></div>';

 echo '
         <div class = "background_place">

             <div class = "main_place">

                 <div class = "place" style = "padding: 8px; line-height: 1.4; border-bottom: 1px solid #eee;">

                     <div id = "avatar">
           
                         '.Core::avatar ($theme['user_id'], 40).'
           
                     </div>

                     <div id = "content">

                         '.Core::user ($theme['user_id'], 1, 1, 1).'

                         <small class = "private_info" id = "right">

                             '.Core::date_time ($theme['time']).'

                         </small>

                         <b>'.Core::check ($theme['name']).'</b> '.$closed.'

                         <br />

                         '.Core::bb ($theme['msg']).'
               
                     </div> 

                 </div>

                 '.$status_closed_txt.'

 ';
 
 if (($user['level'] == 1 or $user['level'] == 4)) {

     $status_topic_link = ($theme['closed'] == 0) ? HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id'].'&closed=1&CK='.$user['CK'] : HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id'].'&closed=0&CK='.$user['CK'];
     $delete_topic_link = ($theme['delete'] == 0) ? HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id'].'&delete=1&CK='.$user['CK'] : HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id'].'&delete=0&CK='.$user['CK'];
     
     echo '

                 <div class = "block">

                     <a class = "private_info" href = "'.$status_topic_link.'">

                         '.($theme['closed'] == 0 ? 'Закрыть' : 'Открыть').'

                     </a>

                     <a class = "private_info" id = "right" href = "'.$delete_topic_link.'">

                         '.($theme['delete'] == 0 ? 'Удалить' : 'Восстановить').'

                     </a>

                 </div>

                 '.(empty ($vote['moder_id']) ? '<a class = "home" href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id'].'&ban_theme=0">Бан</a>' : '<div class = "block private_info">Забанил: '.Core::user ($vote['moder_id'], 1, 1, 1).' <a href = "'.HTTP.'/uid'.$theme['user_id'].'/remarks/?ban='.$vote['id'].'">(Нарушение)</a></div>').'

     ';

 }

 echo '

                 <div class = "nav">

                     <div class="bottom_fix" id="bottomToolsBlock"></div>
                     <div id="sharing_buttons" class="t_center"></div>
                     <script type="text/javascript" async="" src="'.HTTP.'/template/js/socialButtons.js"></script>

                 </div>

                 <div class = "block">

                     '.$bookmark.'

                 </div>

             </div>


 ';


 if (isset ($_POST['add'])) {

     $msg = (string) Core::check ($_POST['msg']);
     $CK = (int) abs ($_POST['CK']);
     
     if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/forum/?section=".$section['id']."&sub=".$sub['id']."&theme=".$theme['id']);
     $err = (empty ($msg) ? '<div class = "err">Введите комментарий!</div>' : (Core::utf_strlen ($msg) > 10000 ? '<div class = "err">Комментарий не должен превышать 10000 символов!</div>' : NULL));

     if (empty ($err)) {

         $DB -> query ("INSERT INTO `forum_comments` SET
                       `theme_id` = '".$theme['id']."',
                       `user_id` = '".$user['id']."',
                       `msg` = ".$DB -> quote ($msg).",
                       `time` = '".time ()."'");

         ## Уведомление в журнал
         if ($theme['user_id'] != $user['id']) User::journal_add ($user['id'], $theme['user_id'], $msg, 5, '/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id']);

         header ('Location: '.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id']);

     }
 
 }

 ## Пагинация для комментариев
 $c_p = $DB -> query ("SELECT * FROM `forum_comments` WHERE `theme_id` = '".$theme['id']."'") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryComments = $DB -> query ("SELECT * FROM `forum_comments` WHERE `theme_id` = '".$theme['id']."' ORDER BY `time` DESC LIMIT $start, ".$p_page."");

 $countComments = $DB -> query ("SELECT * FROM `forum_comments` WHERE `theme_id` = '".$theme['id']."'") -> RowCount ();

 ## Получаем данные о банах узера
 $vote = $DB -> query ("SELECT `ban_time`, `time`, `moder_id` FROM `user_ban_list` WHERE `user_id` = '".$user['id']."' AND ((`type` = 'forum_theme') OR (`type` = 'forum_comment')) ORDER BY `ban_time` DESC") -> fetch ();
 
 echo '

             <div class = "main_place">

 ';

 if ($queryComments -> RowCount () < 1) echo '<div class="b-title b-title_first"> <a class="b-title__link">Комментарии</a></div> <div class = "place">Комментарии отсуствуют</div>';
 else {

     echo '

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                         Комментариев 

                         <span class = "count_web">

                             '.$countComments.'

                         </span>

                     </a>

                 </div>

     ';

   while ($comm = $queryComments -> fetch ()) {

         if ($comm['reply_id'] > 0) {

            $u = $DB -> query ("SELECT `login`, `id`, `sex` FROM `users` WHERE `id` = '".$comm['reply_id']."'") -> fetch ();
            $sex = ($u['sex'] == 1) ? '' : 'а';
            $userName = "<a style='cursor:hand;cursor:pointer;' onclick='document.getElementById('reply').style.display='''>".$u['login']."</a>";

         }

         echo '

                 <div class = "place user_info" style = "padding: 8px; padding-bottom: 5px; line-height: 1.4;">

                     <div id = "avatar">

                         '.Core::avatar ($comm['user_id'], 40).'
           
                     </div>

                     <div id = "content">

                         '.Core::user ($comm['user_id'], 1, 1, 1).'

                         '.($comm['reply_id'] > 0 ? '<span class = "private_info">ответил'.$sex.'</span> '.$userName : '').'

                         <small class = "private_info" id = "right">

                             '.Core::Date_time ($comm['time']).'

                         </small>

                         <br />

                         '.Core::bb ($comm['msg']).'

                     </div> 

                 </div>

                 <div id = "content_nav" style = "padding: 0 7px 3px 8px;">
                          
                         '.(((($comm['user_id'] != $user['id']) and ($theme['closed'] == 0))) ? '<a class = "edit_c" href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id'].'&reply='.$comm['id'].'">Ответ</a>' : '').'
                         
                         '.((($user['level'] == 1 or $user['level'] == 4)) ? '<a id = "right" class = "delete_c" href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id'].'&del_com='.$comm['id'].'&CK='.$user['CK'].'">Удалить</a>' : '').'
                         
                         '.((($user['level'] == 1 or $user['level'] == 4)) ? '<span id = "right"><a class = "delete_c" href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id'].'&ban_comment='.$comm['id'].'">Бан</a> | </span>' : '').'

                 </div>

         ';

     }

     if ($k_page > 1) Core::str(HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$theme['id'].'&', $k_page, $page);

 }

 if ((($user and $theme['closed'] == 0) or ($user['level'] == 1 or $user['level'] == 4)) and (time () > ($vote['time']+$vote['ban_time']))) {

 echo '

                 <div class = "nav">
         
                     <form action = "" method = "POST">
         
                         <textarea name = "msg"  placeholder = "Комментарий"></textarea>

                         '.$err.'

                         <br />

                         <input type = "submit" value = "Написать" name = "add">

                         <input type = "hidden" name = "CK" value = "'.$user['CK'].'" />
 
                     </form>
          
                 </div>
         ';
 }
 else if (time () < ($vote['time']+$vote['ban_time'])) {
     
     $ban_time = ($vote['ban_time'] == 3600 ? 1 : ($vote['ban_time'] == 10800 ? 3 : ($vote['ban_time'] == 43200 ? 12 : ($vote['ban_time'] == 86400 ? 24 : ($vote['ban_time'] == 172800 ? 48 : ($vote['ban_time'] == 432000 ? 120 : ($vote['ban_time'] == 86400 ? 240 : 0)))))));
    
     echo '

                 <div class = "err">

                     Вы заблокированы в форуме на <b>'.$ban_time.' ч.</b>

                     <br />

                     Модератором '.Core::user ($vote['moder_id'], 1, 1, 1).'

                     <br />

                     <a href = "'.HTTP.'/uid'.$user['id'].'/remarks">Все нарушения</a>

                 </div>

     ';
 
 }

 echo '

             </div>

         </div>

 ';       

 echo '

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">
                 
                 Форум

             </a>

             <span class = "ico next"></span> 

             <a href = "'.HTTP.'/forum/?section='.$section['id'].'">

                '.$section['name'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum/?section='.$sub['id'].'">

                '.$sub['name'].'

             </a>

         </div>

 ';

 require_once $_SERVER['DOCUMENT_ROOT'].'/template/footer.php';

?>