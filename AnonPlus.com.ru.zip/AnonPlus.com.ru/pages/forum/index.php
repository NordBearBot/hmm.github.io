<?php

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 // if ($user['level'] < 1) Core::redirect ("Тех. работы!", HTTP."/");

 if (isset ($_GET['list_check']) and ($user['level'] == 1 or $user['level'] == 4)) { require_once $_SERVER['DOCUMENT_ROOT'].'/pages/forum/inc/list_check.php'; exit; }

 if (isset ($_GET['section'])) { require_once $_SERVER['DOCUMENT_ROOT'].'/pages/forum/inc/section.php'; exit; }

 if (isset ($_GET['section']) and isset ($_GET['sub'])) { require_once $_SERVER['DOCUMENT_ROOT'].'/pages/forum/inc/subsection.php'; exit; }

 if (isset ($_GET['new'])) {

 	if ($user['level'] == 1) {
 
         $title = 'Форум / Новый раздел';

         require_once $_SERVER['DOCUMENT_ROOT'].'/template/header.php';

         if (isset ($_POST['add'])) {

             $name = Core::check ($_POST['name']);
             $info = Core::check ($_POST['info']);
             $CK = (int) abs ($_POST['CK']);

             if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/forum/?new");
             if (empty ($name)) Core::redirect ("Введите название раздела!", HTTP."/forum/?new");
             if (empty ($info)) Core::redirect ("Введите описание раздела!", HTTP."/forum/?new");

             $DB -> query ("INSERT INTO `forum_section` SET `name` = ".$DB -> quote ($name).", `info` = ".$DB -> quote ($info)."");

             Core::redirect_ok ("Раздел создан!", HTTP."/forum/?");

         }

         echo '

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">
                 
                 Форум

             </a>

             <span class = "ico next"></span> 

             Новый раздел

         </div>

        ';

         echo '

             <form action = "" method = "POST">

                 <div class = "block">

                     Название раздела: <br />
                     <input type = "text" name = "name"> 

                     <br />

                     Описание: <br />
                     <textarea name = "info"></textarea> 

                     <br />

                     <input type = "submit" name = "add" value = "Создать">

                     <input type="hidden" name="CK" value="'.$user['CK'].'" />

                 </div>

             </form>

         ';

         echo '

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/forum">
                 
                 Форум

             </a>

             <span class = "ico next"></span> 

             Новый раздел

         </div>

        ';

         require_once $_SERVER['DOCUMENT_ROOT'].'/template/footer.php';
         exit;
 	}
 	else header ('Location: '.HTTP.'/forum/');
 }


 $description = 'На нашем форуме Вы найдете только качественные статьи с очень полезной информацией на различные темы.';
 $keywords = 'сайт интересных статей, сайт с интересными статьями, другая полезная информация, очень полезная информация, форум статей, тематические статьи, интернет форум, ответы форум, добро пожаловать на форум, форум';

 $title = 'Форум - добро пожаловать!';

 require_once $_SERVER['DOCUMENT_ROOT'].'/template/header.php';	

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Форум

         </div>

 ';

 Core:: Error ();
 Core:: Ok ();

     $querySections = $DB -> query ("SELECT * FROM `forum_section`");

     if ($querySections -> RowCount () > 0) {

         echo '

         <div class = "background_place">

             <div class = "main_place">

         ';

         while ($forum = $querySections -> fetch ()) {

         	 echo '

                 <a class = "home" href = "'.HTTP.'/forum/?section='.$forum['id'].'">

                     '.$forum['name'].'

                     <br />

                     <small>

                         '.$forum['info'].'

                     </small>

                 </a>

         	 ';

         }

         echo '

             </div>

         </div>

         ';

     }
     else echo '<div class = "block"><font color = "darkred">Разделов нет!</font></div>';  

     if ($user['level'] == 1) {

          echo '

         <a class = "list-link" style = "padding: 13px; border-top: 1px solid #eee;" href = "'.HTTP.'/forum/?new">

             
             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/add.png">

             Добавить раздел

         </a>

         ';

     }

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Форум

         </div>

 ';

 require_once $_SERVER['DOCUMENT_ROOT'].'/template/footer.php';

?>
