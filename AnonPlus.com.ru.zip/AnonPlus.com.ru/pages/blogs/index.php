<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $sect = (int) abs ($_GET['section']);

 ## Сортировка
 $section = ($sect == 1 ? "ORDER BY `time` DESC" :  "AND `time` > '" . (time() - 60 * 60 * 24 * 3) . "' ORDER BY `view` DESC");

 ## Пагинация
 $c_p = $DB -> query ("SELECT * FROM `blogs` WHERE `access` = '0' ".$section."") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 ## Выбираем записи из БД
 $queryBlogs = $DB -> query ("SELECT * FROM `blogs` WHERE `access` = '0' ".$section." LIMIT $start, ".$p_page."");

 $description = 'Блоги на '.DOMAIN;
 $keywords = 'Блоги на '.DOMAIN;
 $title = SITE_NAME.' / Блоги';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/">'.SITE_NAME.'</a>
             
             <span class = "ico next"></span>

             Блоги

         </div>
 ';
 
 Core:: Error ();
 Core:: Ok ();

 $new = (empty ($sect) or $sect != 1) ? '<span id = "t"></span>' : '';
 $all = ($sect == 1) ? '<span id = "t"></span>' : '';

 $link_new = (empty ($sect) or $sect != 1) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/blogs/?" class = "no_act act_l_b act_r_b">';
 $link_all = ($sect == 1) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/blogs/?section=1" class = "no_act act_l_b act_r_b">';

 echo '
         <div class = "block" style = "border: none; padding-bottom: 0;">

             <table style="width: 100%;">

               <tbody>

                     <tr>

                         <td style="width: 100%;">

                             <input type="text" placeholder="Поиск по блогам" class="search" style="width: 100%;">

                         </td>

                         <td>

                             <input type="submit" style = "margin-left: 25px; margin-top: 7px;" class="search_ok">
             
                         </td>

                     </tr> 

                 </tbody>

             </table>

         </div>

         <div class = "block" style = "border: none; padding-bottom: 0px;">

             <div class = "part" style = "width: 50%;">

                 '.$link_new.' Популярные </a>

                 '.$new.'

             </div>

             <div class = "part" style = "width: 50%;">

                  '.$link_all.' Новые </a>

                 '.$all.'

             </div>

         </div>

 ';

 if ($queryBlogs -> RowCount () < 1) echo '<div class = "block" style = "background: #F5F5F5;">Блогов нет!</div>';
 else {

     echo '

         <div class = "background_place">

     ';

    while ($blog = $queryBlogs -> fetch ()) {

         $queryTest = $DB -> query ("SELECT `id` FROM `bookmarks` WHERE `user_id` = '".$user['id']."' AND `type` = '0' AND `object_id` = '".$blog['id']."'") -> RowCount ();
         $bookmarks = ($queryTest < 1) ? '<span id = "right"><a href="'.HTTP.'/bookmarks/add/?type=0&id='.$blog['id'].'" class="adv_user_link" id="bookmark_link" title="Добавить в закладки"><span></span></a></span>' : '<span id = "right"><a href="'.HTTP.'/bookmarks/delete/?type=0&id='.$blog['id'].'" class="adv_user_link" id="bookmark_link" title="Удалить из закладок"><span style="background-position: -32px -16px; !important;"></span></a></span>';
         $share = ($blog['user_id'] != $user['id'] and $blog['access'] == 0) ? Blog::share_link ($blog['id']) : '';

        echo '

         <div class = "main_place">

         <div class = "place" style = "line-height: 1.4;">

             <div id = "avatar">

                 '.Core::avatar ($blog['user_id'], 40).'

             </div>

             <div id = "content">

             '.Core::user ($blog['user_id'], 1, 1, 1).'

             <span id = "right">

                 <small class = "private_info">

                     '.Core::date_time ($blog['time']).'

                 </small>

             </span>

             <br />

             <a href = "'.HTTP.'/uid'.$blog['user_id'].'/blog/?i='.$blog['id'].'">

                 '.Core::CropStr (Core::without_bb($blog['message']), 1000).'
             
             </a>

             </div>

         </div>

         '.($blog['share'] > 0 ? Blog::share($blog['share']) : '').'

         <div class = "block" style = "border-top: 1px solid #eee;">

             <span class="private_info">

                 Канал:

             </span>

             <a class = "info_link" href = "">

                 '.Blog::channel ($blog['id']).'

             </a>

         </div>

         <div class = "nav">

             <a href="'.HTTP.'/uid'.$blog['user_id'].'/blog/?i='.$blog['id'].'" class="adv_user_link adv_user_link_text" id="comment_link" title="Комментировать"><span class="ico"></span> <span></span></a>
             
             '.$share.'

             '.$bookmarks.'

         </div>

         <div class = "block" style = "overflow: hidden;">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/view.png"> <small>'.$blog['view'].'</small>
             ·
             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/comment.png"> <small>'.$blog['comments'].'</small>

         </div>

         </div>

        ';
        
    }

    echo '

         </div>

    ';

 }

 $p_section = ($sect == 1 ? 'section=1' : '');

 if ($k_page > 1) Core::str(''.HTTP.'/blogs/?'.$p_section.'&', $k_page, $page);

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/">'.SITE_NAME.'</a>
             
             <span class = "ico next"></span>

             Блоги

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>