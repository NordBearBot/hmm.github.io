<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $description = 'Поиск на '.DOMAIN;
 $keywords = 'Поиск на '.DOMAIN;
 $title = SITE_NAME.' / Блоги';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/">'.SITE_NAME.'</a>
             
             <span class = "ico next"></span>

             Поиск

         </div>
 ';
 
 Core:: Error ();
 Core:: Ok ();

 echo '
         <div class = "block" style = "border: none; padding-bottom: 0;">

             <table style="width: 100%;">

               <tbody>

                     <tr>
                     <form method=get>

                         <td style="width: 100%;">

                             <input type="text" name="req" placeholder="Введите запрос для поиска..." class="search" style="width: 100%;">

                         </td>

                         <td>

                             <input type="submit" style = "margin-left: 25px; margin-top: 7px;" class="search_ok">
             
                         </td>
                     </form>

                     </tr> 

                 </tbody>

             </table>

         </div>

        

 ';

 if(!isset($_GET['req'])) echo '<div class = "block" >Последние 5 запросов:</div>';
 else{
     //$result = $DB->query("SELECT *, MATCH (message) AGAINST ('тест') AS rel FROM blogs WHERE MATCH (message) AGAINST ('тест')");
     $result = $DB->query("SELECT * FROM blogs WHERE MATCH (message) AGAINST ('тест')");
	 echo 'Блоги: '.$result->num_rows;
 }

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/">'.SITE_NAME.'</a>
             
             <span class = "ico next"></span>

             Блоги

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>