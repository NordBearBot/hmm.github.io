<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $queryUser = $DB -> query ("SELECT `id`, `login`, `blog_info` FROM `users` WHERE `id` = '".intval( abs ($_GET['id']))."'");

 if ($queryUser -> RowCount () < 1) { 

    if ($user) Core::redirect ("Пользователь не существует!", HTTP."/uid".$user['id']."/blog/");
    else Core::redirect ("Пользователь не существует!", HTTP."/people/");

 }

 $ank = $queryUser -> fetch ();

 if ($ank['id'] != $user['id']) $accessBlog = (User::friend ($user['id'], $ank['id']) == true) ? 'AND `access`<2' : 'AND `access`<1';
 else $accessBlog = NULL;

 if (isset ($_GET['i']) and !empty ($_GET['i'])) {  include_once $_SERVER['DOCUMENT_ROOT'].'/pages/blog/inc/view.php'; exit;}

 ## Пагинация
 $c_p = $DB -> query ("SELECT * FROM `blogs` WHERE `user_id` = '".$ank['id']."' ".$accessBlog."") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryBlogs = $DB -> query ("SELECT * FROM `blogs` WHERE `user_id` = '".$ank['id']."' ".$accessBlog." ORDER BY `id` DESC LIMIT $start, ".$p_page);
 //by binore
 $queryBlogs_ = $DB -> query ("SELECT * FROM `blogs` WHERE `user_id` = '".$ank['id']."' ".$accessBlog);
 include_once ROOT.'/pages/mysite/inc/access_blog.php';

 $description = 'Блог '.$ank['login'];
 $keywords = NULL;
 $title = 'Блог '.$ank['login'];

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>

             Блог

         </div>
 ';

 Core:: Ok ();
 Core:: Error ();

 echo '
         <div class = "background_place">

         <div class = "main_place">

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 <small>

                     '.$ank['blog_info'].'
             
                 </small>

             </a>

         </div>

 ';

 if ($user and $user['id'] == $ank['id']) {

 echo '
       '.$err.'

         <div class = "block">

             <form action = "" method = "POST">
     
                 <textarea name="msg"  placeholder = "Напишите в свой блог..."></textarea> <br />

                 <input type = "hidden" name = "access" value = "'.$accessBlog.'" />
                 
                     <a href="'.HTTP.'/access-settings/?blog=2'.($accessBlog > 0 ? '&access='.$accessBlog.'' : '').'" class="adv_user_link" id="'.$accessBlogView.'" title="Доступ к записе"><span></span></a>

                     <a href="http://vizaire.ru/mail/?new&name=mobi" class="adv_user_link" id="file_link" title="Прикрепить файл"><span></span></a>

                 <input id = "right" type="submit" value="Написать" name = "new_diary">

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />
 
             </form>

         </div>

 ';

 }
 else if ($queryBlogs -> RowCount () > 0) {

    echo '

         <div class = "place">

             Записей 

             <span class = "count_web">

                 '.$queryBlogs_ -> RowCount ().'

             </span>

         </div>

    ';

 }
 else if ($queryBlogs -> RowCount () < 1) {
     echo '

         <div class = "place">

             Записи отсуствуют

         </div>

    ';  
 }

 echo '

         </div>

 ';

 if ($queryBlogs -> RowCount () > 0) {

    while ($blog = $queryBlogs -> fetch ()) {

         $queryTest = $DB -> query ("SELECT `id` FROM `bookmarks` WHERE `user_id` = '".$user['id']."' AND `type` = '0' AND `object_id` = '".$blog['id']."'") -> RowCount ();
         $bookmarks = ($queryTest < 1) ? '<span id = "right"><a href="'.HTTP.'/bookmarks/add/?type=0&id='.$blog['id'].'" class="adv_user_link" id="bookmark_link" title="Добавить в закладки"><span></span></a></span>' : '<span id = "right"><a href="'.HTTP.'/bookmarks/delete/?type=0&id='.$blog['id'].'" class="adv_user_link" id="bookmark_link" title="Удалить из закладок"><span style="background-position: -32px -16px; !important;"></span></a></span>';
         $share = ($blog['user_id'] != $user['id'] and $blog['access'] == 0) ? Blog::share_link ($blog['id']) : '';

        echo '

         <div class = "main_place">

         <div class = "block" style = "border: none;">

             <div id = "avatar">

                 '.Core::avatar ($ank['id'], 40).'

             </div>

             <div id = "content">

             '.Core::user ($blog['user_id'], 1, 1, 1).'

             <span id = "right">

                 <small>

                     '.Core::date_time ($blog['time']).'

                     '.($blog['access'] == 0 ? '<img src="'.HTTP.'/files/system.images/status.data/access_all.png" title="Доступен всем">' : '').'
                     '.($blog['access'] == 1 ? '<img src="'.HTTP.'/files/system.images/status.data/access_friends.png" title="Доступен друзьям">' : '').'
                     '.($blog['access'] == 2 ? '<img src="'.HTTP.'/files/system.images/status.data/access_me.png" title="Доступен автору">' : '').'

                 </small>

             </span>

             <br />

             <a href = "'.HTTP.'/uid'.$blog['user_id'].'/blog/?i='.$blog['id'].'">

                 '.Core::without_bb($blog['message']).'
             
             </a>

             </div>

         </div>

         '.($blog['share'] > 0 ? Blog::share($blog['share']) : '').'

         <div class = "nav" style = "border-top: 1px solid #eee;">

             <a href="'.HTTP.'/uid'.$blog['user_id'].'/blog/?i='.$blog['id'].'" class="adv_user_link adv_user_link_text" id="comment_link" title="Комментировать"><span class="ico"></span> <span></span></a>
         
             '.$bookmarks.'

             '.$share.'

         </div>

         <div class = "block" style = "overflow: hidden;">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/view.png"> <small>'.$blog['view'].'</small>
             ·
             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/comment.png"> <small>'.$blog['comments'].'</small>

         </div>

         </div>

        ';
        
    }
    
     if ($k_page > 1) Core::str(''.HTTP.'/uid'.$ank['id'].'/blog/?i='.$blog['id'].$p_section.'&', $k_page, $page);

 }

 echo '

         </div>
         
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>

             Блог

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>