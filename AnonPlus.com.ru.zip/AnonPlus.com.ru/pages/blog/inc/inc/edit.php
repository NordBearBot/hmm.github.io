<?php

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $title = 'Блог '.$ank['login'];

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/blog">Блог</a>

             <span class = "ico next"></span>

             Редактирование

         </div>
 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/blog">Блог</a>

             <span class = "ico next"></span>

             Редактирование

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>