<?php

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $access = (isset ($_POST['access'])) ? intval (abs($_POST['access'])) : $blog['access'];
 $access = ($access < 0 or $access > 2) ? 0 : $access;

 if (isset ($_POST['edit'])) {

     $message = Core::check ($_POST['message']);

     $err = (empty ($message) ? '<div class = "err">Запись не должна быть пустой!</div>' : (Core::utf_strlen ($message) > 20000 ? '<div class = "err">Запись не должна превишать 20000 символов!</div>' : NULL));
     
     if (empty ($err)) {

         $DB -> query ("UPDATE `blogs` SET `message` = ".$DB -> quote ($message).", `access` = '".$access."' WHERE `id` = '".$blog['id']."'");
         Core::redirect_ok ("Запись изменена", HTTP."/uid".$user['id']."/blog/?i=".$blog['id']."");

     }

 }

 $title = 'Блог '.$user['login'];

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/blog">Блог</a>

             <span class = "ico next"></span>

             Редактирование

         </div>
 ';

 echo '
         
         <form action = "" method = "POST">

             '.$err.'

             <div class = "block">

                 Запись:

                 <br />

                 <textarea name = "message">'.$blog['message'].'</textarea>

             </div>

             <div class = "block">

                 <span class="private_info">

                     Канал:

                 </span>

                 <a class = "info_link" href = "">

                     '.Blog::channel ($blog['id']).'

                 </a>

             </div>

             <div class = "block">

                 <span class="private_info">

                     Кто видит запись:

                 </span>

                 <a class = "info_link" href = "'.HTTP.'/access-settings/?i='.$blog['id'].'">

                     '.($access == 0 ? '<img src="'.HTTP.'/files/system.images/status.data/access_all.png" title="Доступен всем"> Все' : '').'
                     '.($access == 1 ? '<img src="'.HTTP.'/files/system.images/status.data/access_friends.png" title="Доступен друзьям"> Только друзья' : '').'
                     '.($access == 2 ? '<img src="'.HTTP.'/files/system.images/status.data/access_me.png" title="Доступен автору"> Только Я' : '').'

                 </a>

             </div>

             <div class = "block">

                 <input type = "hidden" name = "CK" value = "'.$user['CK'].'" />

                 <input type = "submit" name = "edit" value = "Сохранить" />

             </div>

         </form>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/blog">Блог</a>

             <span class = "ico next"></span>

             Редактирование

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>