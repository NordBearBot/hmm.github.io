<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 $queryUser = $DB -> query ("SELECT `id`, `login`, `blog_info` FROM `users` WHERE `id` = '".intval( abs ($_GET['id']))."'");

 if ($queryUser -> RowCount () < 1) { 

    if ($user) Core::redirect ("Пользователь не существует!", HTTP."/uid".$user['id']."/blog/");
    else Core::redirect ("Пользователь не существует!", HTTP."/people/");

 }

 $ank = $queryUser -> fetch ();

 if ($ank['id'] != $user['id']) $accessBlog = (User::friend ($user['id'], $ank['id']) == true) ? 'AND `access`<2' : 'AND `access`<1';
 else $accessBlog = NULL;

 $blog_id = (int) abs ($_GET['i']);

 $queryBlog = $DB -> query ("SELECT * FROM `blogs` WHERE `user_id` = '".$ank['id']."' AND `id` = '".$blog_id."' ".$accessBlog." ORDER BY `id` DESC");

 if ($queryBlog -> RowCount () < 1) Core::redirect ("Запись не найдена!", HTTP."/uid".$ank['id']."/blog");
 $blog = $queryBlog -> fetch ();

 if ($user['id'] == $blog['user_id'] and isset ($_GET['edit'])) {

     include_once $_SERVER['DOCUMENT_ROOT'].'/pages/blog/inc/edit.php';

     exit;

 }

 if (isset ($_GET['reply'])) {

     include_once $_SERVER['DOCUMENT_ROOT'].'/pages/blog/inc/reply.php';

     exit;

 }


 ##  Обрабатываем просмотр

 if ($user) {

     $testView = $DB -> query ("SELECT `id` FROM `count_view` WHERE `type` = 'blog' and `user_id` = '".$user['id']."' and `object_id` = '".$blog['id']."'") -> RowCount ();

     if ($testView == 0) {

         Core::count_view ('blog', $blog['id']);

         $DB -> query ("UPDATE `blogs` SET `view` = `view`+1 WHERE `id` = '".$blog['id']."'");

         header ('Location: '.HTTP.'/uid'.$ank['id'].'/blog/?i='.$blog['id']);

     }

 }

 if ($user and isset ($_GET['journal'])) User::journal_update ($_GET['journal'], $user['id']);

 $queryTest = $DB -> query ("SELECT `id` FROM `bookmarks` WHERE `user_id` = '".$user['id']."' AND `type` = '0' AND `object_id` = '".$blog['id']."'") -> RowCount ();
 $bookmarks = ($queryTest < 1) ? '<a href="'.HTTP.'/bookmarks/add/?type=0&id='.$blog['id'].'" class="adv_user_link" id="bookmark_link" title="Добавить в закладки"><span></span></a>' : '<a href="'.HTTP.'/bookmarks/delete/?type=0&id='.$blog['id'].'" class="adv_user_link" id="bookmark_link" title="Удалить из закладок"><span style="background-position: -32px -16px; !important;"></span></a>';
 $edit = ($blog['user_id'] == $user['id']) ? '<a href="'.HTTP.'/uid'.$user['id'].'/blog/?i='.$blog['id'].'&edit" class="adv_user_link" id="edit_link_b" title="Редактировать"><span></span></a>' : '';
 $complaint = ($blog['user_id'] != $user['id']) ? '<span id = "right"><a href="" class="adv_user_link" id="complaint_link" title="Жалоба"><span></span></a></span>' : '';
 $share = ($blog['user_id'] != $user['id'] and $blog['access'] == 0) ? Blog::share_link ($blog['id']) : '';

 ## Пагинация для комментариев
 $c_p = $DB -> query ("SELECT * FROM `blogs_comments` WHERE `blog_id` = '".$blog['id']."'") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryComments = $DB -> query ("SELECT * FROM `blogs_comments` WHERE `blog_id` = '".$blog['id']."' ORDER BY `id` DESC LIMIT $start, ".$p_page."");

 if (isset ($_POST['comment'])) {

     Core::CheckUser ();

     $message = Core::check ($_POST['message']);
     $CK = (int) abs ($_POST['CK']);

     if ($CK == $user['CK']) {

         if (empty ($message)) $err = '<div class = "err">Введите комментарий!</div>';
         else {

             if (Core::utf_strlen($message) > 20000) $err = '<div class = "err">Комментарий не должен превышать 20000 символов!</div>';
             else {

                 $queryAddComment = $DB -> query ("INSERT INTO `blogs_comments` SET
                                                  `blog_id` = '".$blog['id']."',
                                                  `user_id` = '".$user['id']."',
                                                  `reply_id` = '0',
                                                  `message` = ".$DB -> quote ($message).",
                                                  `time` = '".time ()."'");
                 $DB -> query ("UPDATE `blogs` SET `comments` = `comments` +1 WHERE `id` = '".$blog['id']."'");

                 if ($user['id'] != $ank['id']) User::journal_add ($user['id'], $ank['id'], $message, 1, '/uid'.$ank['id'].'/blog/?i='.$blog['id'].'');

                 header ('Location: '.HTTP.'/uid'.$ank['id'].'/blog/?i='.$blog['id'].'');

             }

         }
     
     }
     else Core::redirect ("Не верный CK!", HTTP."/uid".$ank['id']."/blog/?i=".$blog['id']."");

 }

 $description = 'Блог '.$ank['login'];
 $keywords = NULL;
 $title = 'Блог '.$ank['login'];

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/blog">Блог</a>

         </div>
 ';

 Core:: Ok ();
 Core:: Error ();

 echo '
         <div class = "background_place">

         <div class = "main_place">

         <div class = "place" style = "padding: 8px; line-height: 1.4;">

             <div id = "avatar">

                 '.Core::avatar ($ank['id'], 40).'

             </div>

             <div id = "content">

             '.Core::user ($blog['user_id'], 1, 1, 1).'

             <span id = "right">

                 <small>

                     <span class = "time">

                         '.Core::date_time ($blog['time']).'

                     </span>

                     '.Blog::access ($blog['access']).'

                 </small>

             </span>

             <br />

             <span style = "padding-top: 10px;">

                 '.Core::bb ($blog['message']).'

             </span>

             </div>

         </div>

         '.($blog['share'] > 0 ? Blog::share($blog['share']) : '').'

         <div class = "block" style = "border-top: 1px solid #eee; overflow: inherit;">

             <span class="private_info">

                 Канал:

             </span>

             <a class = "info_link" href = "">

                 '.Blog::channel ($blog['id']).'

             </a>

         </div>

         <div class = "nav">

             '.$edit.' '.$share.' '.$bookmarks.' '.$complaint.'

         </div>

         <div class = "block">

             <div class="bottom_fix" id="bottomToolsBlock"></div>
             <div id="sharing_buttons" class="t_center"></div>
             <script type="text/javascript" async="" src="'.HTTP.'/template/js/socialButtons.js"></script>

         </div>

         <div class = "block" style = "overflow: hidden;">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/view.png"> <small>'.$blog['view'].'</small>

         </div>

         </div>

         <div class = "main_place">

 ';

 if ($queryComments -> RowCount () < 1) {

         echo '

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 Комментарии отсутствуют

             </a>

         </div>

         <div class = "block">

             <i>Будьте первыми</i>

         </div>

         ';

 }
 else {

         echo '

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 Комментариев <span class = "count_web" style = "padding: 0 8px 0 8px;">'.$queryComments -> RowCount ().'</span>

             </a>

         </div>

         ';
 }

 if ($queryComments -> RowCount () > 0) {

     while ($comment = $queryComments -> fetch ()) {

         if ($comment['reply_id'] > 0) {

            $u = $DB -> query ("SELECT `login`, `id`, `sex` FROM `users` WHERE `id` = '".$comment['reply_id']."'") -> fetch ();
            $sex = ($u['sex'] == 0) ? '' : 'а';
            $userName = "<a style='cursor:hand;cursor:pointer;' onclick='document.getElementById('reply').style.display='''>".$u['login']."</a>";

         }

         echo '

         <div class = "place" style = "padding: 8px; padding-bottom: 5px; line-height: 1.4;">

             <div id = "avatar">

                 '.Core::avatar ($comment['user_id'], 40).'

             </div>

             <div id = "content">

                 '.Core::user ($comment['user_id'], 1, 1, 1).'

                 '.($comment['reply_id'] > 0 ? '<span class = "private_info">ответил'.$sex.'</span> '.$userName : '').'
                 '.($comment['reply_id'] > 0 ? '<div id="reply" class = "quote" style="display:none">ни работаит :c</div>' : '').'

                 <small id = "right" class = "private_info">

                     '.Core::date_time ($comment['time']).'

                 </small>

                 <br />

                 '.Core::bb ($comment['message']).'

             </div>

         </div>

         <div id = "content_nav" style = "padding: 0 7px 3px 8px;">

             '.($comment['user_id'] != $user['id'] ? '<a class = "edit_c" href = "'.HTTP.'/uid'.$blog['user_id'].'/blog/?i='.$blog['id'].'&reply='.$comment['id'].'">Ответ</a>' : '').'

         </div>

         ';

     }

 if ($k_page > 1) Core::str(HTTP.'/uid'.$blog['user_id'].'/blog/?i='.$blog['id'].$p_section.'&', $k_page, $page);

 }

 echo '

         '.$err.'

         <div class = "nav">

             <form action = "" method = "POST">

                 <textarea name="message"  placeholder = "Оставить комментарий...">'.(isset ($_POST['comment']) ? Core::check ($_POST['message']) : '').'</textarea>

                 <br />

                 <input type = "submit" name = "comment" value = "Написать"/>

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

             </form>

         </div>

         </div>

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/blog">Блог</a>

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>