<?php

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $reply_id = (int) abs ($_GET['reply']);

 $queryComment = $DB -> query ("SELECT * FROM `blogs_comments` WHERE `id` = '".$reply_id."' AND `blog_id` = '".$blog['id']."'");
 
 if ($queryComment -> RowCount () < 1) Core::redirect ("Комментарий не найден!", HTTP."/uid".$ank['id']."/blog/?i=".$blog['id']);
 $comment = $queryComment -> fetch ();

 if ($comment['user_id'] == $user['id']) header ('Location: '.HTTP.'/uid'.$ank['id'].'/blog/?i='.$blog['id'].'');

 if (isset ($_POST['reply'])) {

     $message = (string) Core::check ($_POST['message']);
     $CK = (int) abs ($_POST['CK']);

     if ($user['CK'] == $CK) {

         $err = (empty ($message) ? '<div class = "err">Сообщение не должно быть пустым!</div>' : (Core::utf_strlen ($message) > 20000 ? '<div class = "err">Сообщение не должно превышать 20000 символов!</div>' : NULL));
         if (empty ($err)) {

             $DB -> query ("INSERT INTO `blogs_comments` SET
                                        `blog_id` = '".$blog['id']."',
                                        `user_id` = '".$user['id']."',
                                        `reply_id` = '".$comment['user_id']."',
                                        `message` = ".$DB -> quote ($message).",
                                        `time` = '".time ()."'");

             $DB -> query ("UPDATE `blogs` SET `comments` = `comments` +1 WHERE `id` = '".$blog['id']."'");

             User::journal_add ($user['id'], $comment['user_id'], $message, 1, '/uid'.$ank['id'].'/blog/?i='.$blog['id'].'');

             header ('Location: '.HTTP.'/uid'.$ank['id'].'/blog/?i='.$blog['id'].'');

         }
     }

 }

 $title = $ank['login'].' / Блог';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/blog">Блог</a>

         </div>
 ';

 echo '
 
         <div class = "background_place">

             <div class = "main_place">

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                         Ответ

                     </a>

                 </div>

                 <div class = "place">

                     <div id = "avatar">

                         '.User::avatar ($comment['user_id'], 40, 'mini', $avatar_mini_style).'

                     </div>

                     <div id = "username_avatar">

                         '.Core::user ($comment['user_id'], 1, 1, 1).'

                         <small id = "right" class = "private_info">

                             '.Core::date_time ($comment['time']).'

                         </small>

                     </div>

                     <span id = "top_v" style = "margin-left: 15px; margin-top: 13px;"></span>

                     <div class = "status">

                         '.Core::bb ($comment['message']).'
                         
                     </div>

                 </div>

                 <div class = "nav">

                     <form action = "" method = "POST">

                         <textarea name="message"  placeholder = "Ответ..."></textarea>

                         <br />

                         <input type = "submit" name = "reply" value = "Написать"/>

                         <input type="hidden" name="CK" value="'.$user['CK'].'" />

                     </form>

                 </div>

                 <a class="home" href="'.HTTP.'/uid'.$ank['id'].'/blog/?i='.$blog['id'].'">

                     &larr; Вернуться в запись

                 </a>
 
             </div>

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/blog">Блог</a>

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>