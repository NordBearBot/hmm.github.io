<?php

 $gift_id = (int) abs ($_GET['gift']);
 $gift_access = ($user['level'] == 1) ? "" : "AND `access` = '0'";
 $queryGift = $DB -> query ("SELECT * FROM `gifts` WHERE `id` = '".$gift_id."' ".$gift_access." ");

 if ($queryGift -> RowCount () < 1) Core::redirect ("Подарок не найден!", HTTP."/uid".$ank['id']."/gifts/new");
 $gift = $queryGift -> fetch ();

 $gift_coins = ($gift['coins'] == 0 ? '5' : ($gift['coins'] == 1 ? '10' : ($gift['coins'] == 2 ? '30' : ($gift['coins'] == 3 ? '50' : '0'))));
 
 if (isset ($_POST['send'])) {

     $message = (string) Core::check ($_POST['msg']);
     $CK = (int) abs ($_POST['CK']);

     if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/uid".$ank['id']."/gifts/new/?gift=".$gift['id']);
     if ($user['coins'] < $gift['coins']) Core::redirect ("У вас не хватает монет!", HTTP."/uid".$ank['id']."/gifts/new/?gift=".$gift['id']);
     
     $err = (Core::utf_strlen($message) > 300) ? '<div class = "err">Сообщение не должно превышать 300 символов!</div>' : NULL;

     if (empty ($err)) {

         $DB -> query ("INSERT INTO `user_gifts` SET `user_id` = '".$user['id']."', `reply_id` = '".$ank['id']."', `message` = ".$DB -> quote ($message).", `time` = '".time ()."', `gift_id` = '".$gift['id']."'");

         $countData = $DB -> query ("SELECT `id` FROM `mail_contacts` WHERE `kto` = '0' AND `kogo` = '".$ank['id']."'") -> RowCount (); 

         if ($countData > 0) {
                     
             $queryContact = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '0' AND `kogo` = '".$ank['id']."'");
             $queryContact2 = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '".$ank['id']."' AND `kogo` = '0'");

         }  
         else {

             $queryContact = $DB -> query ("INSERT INTO `mail_contacts` SET 
                                       `id` = '',
                                       `kto` = '0',
                                       `kogo` = '".$ank['id']."',
                                       `time` = '".time ()."'");


             $queryContact2 = $DB -> query ("INSERT INTO `mail_contacts` SET 
                                          `id` = '',
                                          `kto` = '".$ank['id']."',
                                          `kogo` = '0',
                                          `time` = '".time ()."'");

         }

         $message_friend = 'У вас новый подарок! [url='.HTTP.'/uid'.$ank['id'].'/gifts]Открыть подарки[/url].';

         $queryMessage = $DB -> query ("INSERT INTO `mail_messages` SET
                                   `id` = '',
                                   `kto` = '0',
                                   `komy` = '".$ank['id']."',
                                   `text` = '".$message_friend."',
                                   `time` = '".time ()."'");

         $DB -> query ("UPDATE `users` SET `coins` = `coins`-".$gift_coins." WHERE `id` = '".$user['id']."'");

         Core::redirect_ok ("Подарок отправлен!", HTTP."/uid".$ank['id']);

     }

 }


 $title = $ank['login'].' / Подарки / Отправка';
 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "http://vizaire.letspy.ru/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>
 
             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/gifts">

                 Подарки

             </a>

             <span class = "ico next"></span>

             Отправка

         </div> 

         <div class = "background_place">

         <div class = "main_place">

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 Подарок для '.$ank['login'].'

             </a>

         </div>

         <div class = "place">

             <img src = "'.HTTP.'/files/gifts/'.$gift['key'].'.'.$gift['type'].'">

             <br />

             <span class = "private_info">

                 Стоимость: <b>'.$gift_coins.' монет</b>

                 <br />

                 У вас на счету: <b>'.$user['coins'].' монет</b>

             </span>


         </div>

         <a class = "home-f" style = "border-top: 1px solid #eee;" href = "'.HTTP.'/services">

             <img id = "menu_list" src = "http://vizaire.ru/files/system.images/site.icons/coins.png">

             Пополнить счет

         </a>

         '.$err.'

         <div class = "place">

             <form action = "" method = "POST">
     
                 <textarea name="msg">Лови подарок!</textarea> <br />

                 <input type="submit" value="Отправить" name = "send">

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />
 
             </form>

         </div>

         <a class="home-f" style = "border-top: 1px solid #eee;" href="'.HTTP.'/uid'.$ank['id'].'/gifts/new/">

             &larr; Назад

         </a>

         </div>

         </div>

         <div class = "title">

             <a href = "http://vizaire.letspy.ru/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>
 
             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/gifts">

                 Подарки

             </a>

             <span class = "ico next"></span>

             Новый подарок

         </div> 

 ';

 include_once ROOT.'/template/footer.php';

?>