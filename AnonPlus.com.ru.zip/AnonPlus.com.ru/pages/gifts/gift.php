<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 
 $id = (int) abs ($_GET['id']);
 $gift_id = (int) abs ($_GET['gift']);

 $queryUser = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".$id."'");

 if ($queryUser -> RowCount () < 1) {

    if ($user) Core::redirect ("Пользователь не существует!", HTTP."/uid".$user['id']);
    else Core::redirect ("Пользователь не существует!", HTTP."/people");

 }
 
 $ank = $queryUser -> fetch ();

 $queryGift = $DB -> query ("SELECT * FROM `user_gifts` WHERE `reply_id` = '".$ank['id']."' AND `id` = '".$gift_id."'");

 if ($queryGift -> RowCount () < 1) Core::redirect ("Подарок не найден!", HTTP."/uid".$ank['id']."/gifts");

 $gift = $queryGift -> fetch ();
 $data = $DB -> query ("SELECT * FROM `gifts` WHERE `id` = '".$gift['gift_id']."'") -> fetch ();

 $title = $ank['login'].' / Подарки / Просмотр';
 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/gifts">

                 Подарки

             </a>

             <span class = "ico next"></span>

             Просмотр

         </div> 

         <div class = "background_place">

             <div class = "main_place">
                 
                 <div class = "place">

                     <img src = "'.HTTP.'/files/gifts/'.$data['key'].'.'.$data['type'].'">

                     <small id = "right" class = "private_info">

                             '.Core::date_time ($gift['time']).'

                     </small>

                     <br />

                     <div id = "avatar">

                         '.User::avatar ($gift['user_id'], 40, 'mini', $avatar_mini_style).'

                     </div>

                     <div id = "username_avatar">

                         '.Core::user ($gift['user_id'], 1, 1, 1).'

                     </div>

                     <span id = "top_v" style = "margin-left: 15px; margin-top: 13px;"></span>

                     <div class = "status">

                         '.Core::smiles ($gift['message']).'
                         
                     </div>

                 </div>

             </div>

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/gifts">

                 Подарки

             </a>

             <span class = "ico next"></span>

             Просмотр

         </div> 

 ';

 include_once ROOT.'/template/footer.php';

?>