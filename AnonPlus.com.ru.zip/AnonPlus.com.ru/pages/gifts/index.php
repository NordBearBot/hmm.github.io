<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 
 $id = (int) abs ($_GET['id']);
 $queryUser = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".$id."'");

 if ($queryUser -> RowCount () < 1) {

    if ($user) Core::redirect ("Пользователь не существует!", HTTP."/uid".$user['id']);
    else Core::redirect ("Пользователь не существует!", HTTP."/people");

 }
 
 $ank = $queryUser -> fetch ();

 $c_p = $DB -> query ("SELECT * FROM `user_gifts` WHERE `reply_id` = '".$ank['id']."'") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryGifts = $DB -> query ("SELECT * FROM `user_gifts` WHERE `reply_id` = '".$ank['id']."' ORDER BY `time` DESC LIMIT $start, ".$p_page."");

 $title = $ank['login'].' / Подарки';
 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             Подарки

         </div> 

         <div class = "background_place">

             <div class = "main_place">

                 <a class="home-f" style = "border-top: 1px solid #eee;" href="'.HTTP.'/uid'.$ank['id'].'/gifts/new/">

                     Подарить подарок

                 </a>
                 
                 <div class = "place">

                 ';

         while ($gift = $queryGifts -> fetch ()) {

                 $g = $DB -> query ("SELECT * FROM `gifts` WHERE `id` = '".$gift['gift_id']."'") -> fetch ();

                 echo '

                 <div class = "pic_two">

                 <div class = "picture_solid">

                     <div class = "pic" style = "padding: 5px;">

                         <a href = "'.HTTP.'/uid'.$ank['id'].'/gifts/id'.$gift['id'].'">

                             <img src = "'.HTTP.'/files/gifts/'.$g['key'].'.'.$g['type'].'">

                         </a>

                     </div>

                 </div>

                 </div>
                     

                 ';
         }

         if ($queryGifts -> RowCount () < 1) echo 'Подарки отсуствуют!';

 echo '

                 </div>

             </div>

 ';

 if ($k_page > 1) Core::str(''.HTTP.'/uid'.$ank['id'].'/gifts/?', $k_page, $page);

        echo '

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             Подарки

         </div>

 ';

 include_once ROOT.'/template/footer.php';

?>