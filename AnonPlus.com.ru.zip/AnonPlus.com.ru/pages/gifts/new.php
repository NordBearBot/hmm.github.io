<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $id = (int) abs ($_GET['id']);

 $queryUser = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".$id."'");

 if ($queryUser -> RowCount () < 1) Core::redirect ("Пользователь не существует!", HTTP."/uid".$user['id']);
 $ank = $queryUser -> fetch ();

 if (isset ($_GET['gift'])) { include_once $_SERVER['DOCUMENT_ROOT'].'/pages/gifts/inc/add_gift.php'; exit; }

 $section = (int) abs ($_GET['section']);
 $section = (($section > 4 AND $user['level'] == 1) ? 0 : (($section > 3 AND $user['level'] != 1) ? 0 : $section));

 $coins = ($section == 0) ? '<span id = "t"></span>' : '';
 $coins2 = ($section == 2) ? '<span id = "t"></span>' : '';
 $coins3 = ($section == 3) ? '<span id = "t"></span>' : '';
 $adm = ($user['level'] == 1 and $section == 4) ? '<span id = "t"></span>' : '';
 

 $link_coins = ($section == 0) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/uid'.$ank['id'].'/gifts/new/?section" class = "no_act act_l_b act_r_b">';
 $link_coins2 = ($section == 2) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/uid'.$ank['id'].'/gifts/new/?section=2" class = "no_act act_l_b act_r_b">';
 $link_coins3 = ($section == 3) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/uid'.$ank['id'].'/gifts/new/?section=3" class = "no_act act_l_b act_r_b">';
 $link_adm = ($user['level'] == 1 and $section == 4) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/uid'.$ank['id'].'/gifts/new/?section=4" class = "no_act act_l_b act_r_b">';
 
 $section_where = ($section == 0 ? "`coins`<2 AND `access` = '0'" : ($section == 2 ? "`coins` = '2' AND `access` = '0'" : ($section == 3 ? "`coins` = '3' AND `access` = '0'" : (($section == 4 and $user['level'] == 1) ? "`access` = '1'" : "`coins`<2 AND `access` = '0'"))));

 $queryGifts = $DB -> query ("SELECT * FROM `gifts` WHERE ".$section_where."");

 $title = $ank['login'].' / Подарки / Новый подарок';
 include_once ROOT.'/template/header.php';

 echo ($user['level'] == 1 ? '<style>.part{width: 25%;}</style>' : '');

 echo '
         <div class = "title">

             <a href = "http://vizaire.letspy.ru/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>
 
             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/gifts">

                 Подарки

             </a>

             <span class = "ico next"></span>

             Новый подарок

         </div>

         <div class = "background_place">

         <div class = "main_place">

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 Подарок для '.$ank['login'].'

             </a>

         </div>

         <div class = "block" style = "border: none; padding-bottom: 0px;">

             <div class = "part">

                 '.$link_coins.' Популярные </a>

                 '.$coins.'

             </div>

             <div class = "part">

                 '.$link_coins2.' 30</a>

                 '.$coins2.'

             </div>

             <div class = "part">

                 '.$link_coins3.' 50</a>

                 '.$coins3.'

             </div>';

             if ($user['level'] == 1) { 

             echo '
             <div class = "part">

                 '.$link_adm.' ADMIN</a>

                 '.$adm.'

             </div>
             ';

             }

         echo '

         </div>

         <div class = "place">';

         while ($g = $queryGifts -> fetch ()) {

             echo '

                 <div class = "pic_two">

                 <div class = "picture_solid">

                     <div class = "pic" style = "padding: 5px;">

                         <a href = "'.HTTP.'/uid'.$ank['id'].'/gifts/new/?gift='.$g['id'].'">

                             <img src = "'.HTTP.'/files/gifts/'.$g['key'].'.'.$g['type'].'">

                         </a>

                     </div>

                 </div>

                 </div>

             ';

         }

         echo '

         </div>

         </div>

         </div>

         <div class = "title">

             <a href = "http://vizaire.letspy.ru/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>
 
             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/gifts">

                 Подарки

             </a>

             <span class = "ico next"></span>

             Новый подарок

         </div> 

 ';

 include_once ROOT.'/template/footer.php';

?>