<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 if ($user and ($user['level'] == 5 or $user['level'] == 1)) {

 $c_p = $DB -> query ("SELECT * FROM `chat_moders`") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryChatMod = $DB -> query ("SELECT * FROM `chat_moders` ORDER BY `id` DESC LIMIT $start, ".$p_page."");
 $countMod = $DB -> query ("SELECT * FROM `chat_moders`") -> RowCount ();

 if (isset ($_GET['del'])) {

     $comment_id = (int) abs ($_GET['del']);
     $queryComment = $DB -> query ("SELECT `id` FROM `chat_messages` WHERE `id` = '".$comment_id."'");

     if ($queryComment -> RowCount () < 1) Core::redirect ("Комментарий не найден!", HTTP."/chat/?mod");
     $DB -> query ("DELETE FROM `chat_moders` WHERE `message_id` = '".$comment_id."'");

     Core::redirect_ok ("Жалоба успешно удалена!", HTTP."/chat/?mod");

 }

 $title = 'Чат / Жалобы';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/chat">

                 Чат
             </a>

             <span class = "ico next"></span> 
 
             Жалобы

         </div>
 ';
 
 Core:: Error ();
 Core:: Ok ();

 echo '

         <div class = "background_place">


 ';

 if ($queryChatMod -> RowCount () < 1) {

     echo '

             <div class = "main_place">

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                         Жалобы

                     </a>

                 </div>

                 <div class = "place">

                     Жалобы отсуствуют!

                 </div>

             </div>

     ';

 }
 else {

     echo '

         <div class="main_place b-title b-title_first" style = "margin-bottom: 0;">

             <a class="b-title__link">

                 Жалобы

                 <span class = "count_web">

                     '.$countMod.'

                 </span>

             </a>

         </div>

     ';

     while ($mod = $queryChatMod -> fetch ()) {

         $comment = $DB -> query ("SELECT * FROM `chat_messages` WHERE `id` = '".$mod['message_id']."'") -> fetch ();
         $romm = $DB -> query ("SELECT * FROM `chat_room` WHERE `id` = '".$comment['room_id']."'") -> fetch ();

         echo '

             <div class = "main_place">

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     '.Core::user ($comment['user_id'], 1, 1, 1).'

                     <small id = "right" class = "private_info">

                         '.Core::date_time ($comment['time']).'

                     </small>

                     <br />

                     '.Core::bb ($comment['msg']).'

                 </div>

                 <div class = "place" style = "border-bottom: 1px solid #eee;">

                     <a href = "'.HTTP.'/chat/?ban='.$comment['id'].'">

                         Бан

                     </a>

                     <a href = "'.HTTP.'/chat/?mod&del='.$comment['id'].'&CK='.$user['CK'].'" id = "right">

                         Удалить

                     </a>

                 </div>

                 <div class = "place">

                     Жалоба от '.Core::user ($mod['user_id'], 1, 1, 1).' 

                     <small id = "right" class = "private_info">

                         '.Core::date_time ($mod['time']).'

                     </small>

                 </div>

             </div>

         ';

     }

     if ($k_page > 1) Core::str(''.HTTP.'/chat/?mod&', $k_page, $page);

 }
 
 echo '

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/chat">

                 Чат
             </a>

             <span class = "ico next"></span> 
 
             Жалобы

         </div>
 ';

 include_once ROOT.'/template/footer.php';
 
 }
 else header('Location: '.HTTP.'/chat');

?>