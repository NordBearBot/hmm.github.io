<?php 

 $room_id = (int) abs ($_GET['room']);
 $queryChatRoom = $DB -> query ("SELECT * FROM `chat_room` WHERE `id` = '".$room_id."' LIMIT 1");
 
 if ($queryChatRoom -> RowCount () < 1) Core::redirect ("Комната не существует!", HTTP."/chat");
 $chat = $queryChatRoom -> fetch ();
 
 
 /*if ($user) {

     ## Записываем что пользователь в чате
     $testOnlineChat = $DB -> query ("SELECT `id` FROM `chat_online` WHERE `user_id` = '".$user['id']."' AND `room_id` = '".$chat['id']."'") -> RowCount ();
     if ($testOnlineChat > 0) $DB -> query ("UPDATE `chat_online` SET `time` = '".time ()."' WHERE `room_id` = '".$chat['id']."', `user_id` = '".$user['id']."'");
     else $DB -> query ("INSERT INTO `chat_online` SET `room_id` = '".$chat['id']."', `user_id` = '".$user['id']."', `time` = '".time ()."'");
 
 }*/
 if (isset ($_GET['reply'])) {

     Core::CheckUser ();
     $user_id = (int) abs ($_GET['reply']);

     $testComment = $DB -> query ("SELECT `id` FROM `chat_messages` WHERE `room_id` = '".$chat['id']."' AND `user_id` = '".$user_id."'");

     if ($testComment -> RowCount () < 1) Core::redirect ("Пользователь не найден! Возможно его не существует или он не писал в этой комнате!", HTTP."/chat/?room=".$chat['id']); 
     $ank = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".$user_id."' LIMIT 1") -> fetch ();

 }

 if (isset ($_POST['send'])) {

     $msg = (string) Core::check ($_POST['msg']);
     $CK = (int) abs ($_POST['CK']);

     if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/chat/?room=".$chat['id']);
     $err = (empty ($msg) ? '<div class = "err">Введите сообщение!</div>' : (Core::utf_strlen ($msg) > 3000 ? '<div class = "err">Сообщение не должно превышать 3000 символов!</div>' : NULL));

     if (empty ($err)) {

         $DB -> query ("INSERT INTO `chat_messages` SET
                       `room_id` = '".$chat['id']."',
                       `msg` = ".$DB -> quote ($msg).",
                       `user_id` = '".$user['id']."',
                       ".(!empty ($ank['id']) ? "`reply_id` = '".$ank['id']."'," : "")."
                       `time` = '".time ()."'");

         header('Location: '.HTTP.'/chat/?room='.$chat['id']);

     }
     
 }

 if (isset ($_GET['moder'])) {

     Core::CheckUser ();

     $comment_id = (int) abs ($_GET['moder']);
     $queryTestComment = $DB -> query ("SELECT `id` FROM `chat_messages` WHERE `id` = '".$comment_id."'");

     if ($queryTestComment -> RowCount () > 0) {

         $queryTestModer = $DB -> query ("SELECT `id` FROM `chat_moders` WHERE `message_id` = '".$comment_id."'");
         if ($queryTestModer -> RowCount () > 0) Core::redirect ("Уже была отправлена жалоба на это сообщение ранее!", HTTP."/chat/?room=".$chat['id']);

         $DB -> query ("INSERT INTO `chat_moders` SET `message_id` = '".$comment_id."', `user_id` = '".$user['id']."', `time` = '".time ()."'");

         Core::redirect_ok ("Жалоба успешно отправлена!", HTTP."/chat/?room=".$chat['id']);

     }
     else Core::redirect ("Сообщение не найдено!", HTTP."/chat/?room=".$chat['id']);
 }

 ## Пагинация для комментариев
 $c_p = $DB -> query ("SELECT * FROM `chat_messages` WHERE `room_id` = '".$chat['id']."'") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryComments = $DB -> query ("SELECT * FROM `chat_messages` WHERE `room_id` = '".$chat['id']."' ORDER BY `time` DESC LIMIT $start, ".$p_page."");

 ## Получаем количество пользователей которое сейчас находится в чате
 $chatUserOnline = time()-300;
 $onlineChatUsers = $DB -> query ("SELECT DISTINCT user_id FROM `chat_messages` WHERE `room_id` = '".$chat['id']."' AND `time` > '".$chatUserOnline."'") -> RowCount ();
 ## Получаем данные о банах узера в чате
 $vote = ($user) ? $DB -> query ("SELECT `ban_time`, `time` FROM `user_ban_list` WHERE `user_id` = '".$user['id']."' AND `type` = 'chat' ORDER BY `ban_time` DESC") -> fetch () : 0;

 $title = 'Чат / '.$chat['name'];

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/chat">

                 Чат

             </a>

             <span class = "ico next"></span>

             '.$chat['name'].'

         </div>
 ';
 
 Core:: Error ();
 Core:: Ok ();
     
 echo '

         <div class = "background_place">

             <div class = "main_place">

 ';

 ## Выводим форму только если пользователь авторизирован и у него нету активного бана в чате
 if ($user and (time () > ($vote['time']+$vote['ban_time']))) {

     echo '

                 '.$err.'

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     <form action = "" method = "POST">

                         '.(isset ($_GET['reply']) ? 'Ответ для <b>'.$ank['login'].'</b>:' : 'Сообщение:').'

                         <small class = "private_info" id = "right">

                             3000 символов

                         </small>

                          <br />

                         <textarea name = "msg">'.(isset ($_POST['add']) ? $msg : '').'</textarea>

                         <br />

                         <input type = "submit" name = "send" value = "Написать">

                         <input type = "hidden" name = "CK" value = "'.$user['CK'].'">

                     </form>

                 </div>

     ';

 }
 else if ($user and (time () < time()+$vote['ban_time'])) echo '<div class = "err">Вы забанены в чате!</div>';

 if ($queryComments -> RowCount () < 1) echo '<div class = "place">Комментарии отсуствуют!</div>';
 else {

     echo '

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                         Сейчас общаются

                         <span class = "count_web">

                             '.$onlineChatUsers.'

                         </span>

                     </a>

                 </div>

     ';

     while ($comment = $queryComments -> fetch ()) {

         $data = (!empty ($comment['reply_id']) ? $DB -> query ("SELECT `login` FROM `users` WHERE `id` = '".$comment['reply_id']."'") -> fetch () : NULL);
         $moder = $DB -> query ("SELECT `id` FROM `chat_moders` WHERE `message_id` = '".$comment['id']."'") -> RowCount ();

         echo '

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     <div id = "avatar">

                         '.Core::avatar ($comment['user_id'], 40).'

                     </div>

                     <div id = "content">

                     <font color = "'.($comment['reply_id'] == $user['id'] ? 'darkgreen' : ($user['id'] == $comment['user_id'] ? '#333333' : '#B2B2B2')).'">

                         '.Core::user ($comment['user_id'], 1, 1, 1).'

                         '.(!empty ($comment['reply_id']) ? 'ответ для <b>'.$data['login'].'</b>' : '').'

                         <small class = "private_info" id = "right">

                             '.Core::date_time ($comment['time']).'

                         </small>

                         <br />

                         '.Core::bb ($comment['msg']).'

                         <br />

                         '.($user['id'] != $comment['user_id'] ? '<a href = "'.HTTP.'/chat/?room='.$chat['id'].'&reply='.$comment['user_id'].'">Ответ</a>' : '').'
                         
                         '.((($user['id'] != $comment['user_id'] and $moder == 0) and ($user['level'] != 5)) ? ' <a id = "right" class = "delete_c" href = "'.HTTP.'/chat/?room='.$chat['id'].'&moder='.$comment['id'].'">Жалоба</a>' : '').'
                         
                         '.(($user['level'] == 1 or $user['level'] == 5) ? '<span id = "right"><a class = "delete_c" href = "'.HTTP.'/chat/?ban='.$comment['id'].'">Бан</a> </span>' : '').'        
                     
                     </font>

                     </div>

                 </div>

         ';
     }

     if ($k_page > 1) Core::str(''.HTTP.'/chat/?room='.$chat['id'].'&', $k_page, $page);

 }
 echo '

             </div>

         </div>

 ';
     
 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/chat">

                 Чат

             </a>

             <span class = "ico next"></span>

             '.$chat['name'].'

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>