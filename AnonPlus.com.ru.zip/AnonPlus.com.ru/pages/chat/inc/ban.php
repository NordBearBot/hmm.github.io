<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 if ($user and ($user['level'] == 5 or $user['level'] == 1)) {

 $comment_id = (int) abs ($_GET['ban']);
 $queryMessage = $DB -> query ("SELECT * FROM `chat_messages` WHERE `id` = '".$comment_id."'");
 if ($queryMessage -> RowCount () < 1) Core::redirect ("Сообщение не существует!", HTTP."/chat");

 $chat = $queryMessage -> fetch ();
 $room = $DB -> query ("SELECT * FROM `chat_room` WHERE `id` = '".$chat['room_id']."'") -> fetch ();
 $ank = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".$chat['user_id']."'") -> fetch ();

 $queryTryRemark = $DB -> query ("SELECT `id` FROM `user_ban_list` WHERE `type` = 'chat' AND `object_id` = '".$chat['id']."'");
 if ($queryTryRemark -> RowCount () > 0) Core::redirect ("Уже было выдано нарушение за это сообщение!", HTTP."/chat/?room=".$room['id']);

 if (isset ($_POST['ban'])) {

     $CK = (int) abs ($_POST['CK']);
     if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/chat/?ban=".$chat['id']);

     $msg = (string) Core::check ($_POST['msg']);
     $err = (Core::utf_strlen ($msg) > 1000) ? '<div class = "err">Сообщение не должно превышать 1000 символов!</div>' : NULL;

     if (empty ($err)) {

         $what = (int) abs ($_POST['what']);
         $what = ($what > 3) ? 3 : $what;

         $time = (int) abs ($_POST['time']);
         $time = ($time > 6) ? 0 : $time;
 
         $time_ban = ($time == 0 ? 3600 : ($time == 1 ? 10800 : ($time == 2 ? 43200 : ($time == 3 ? 86400 : ($time == 4 ? 172800 : ($time == 5 ? 432000 : ($time == 6 ? 864000 : 3600)))))));
     
         $DB -> query ("INSERT INTO `user_ban_list` SET
                       `type` = 'chat',
                       `object_id` = '".$chat['id']."',
                       `user_id` = '".$ank['id']."',
                       `moder_id` = '".$user['id']."',
                       `time` = '".time ()."',
                       `ban_time` = '".$time_ban."',
                       `what` = '".$what."',
                       `message` = ".$DB -> quote ($msg)."");

         $DB -> query ("DELETE FROM `chat_moders` WHERE `message_id` = '".$chat['id']."'");

         Core::redirect_ok ("Пользователь забанен!", HTTP."/chat");

     }

 }

 $title = 'Чат / Бан';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/chat">

                 Чат
             </a>

             <span class = "ico next"></span> 
 
             Бан

         </div>
 ';
 
 Core:: Error ();
 Core:: Ok ();

 echo '

         <div class = "background_place">

             <form action = "" method = "POST">

             <div class = "main_place">

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                         Бан

                     </a>

                 </div>

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     '.Core::user ($chat['user_id'], 1, 1, 1).'

                     <small class = "private_info" id = "right">

                         '.Core::date_time ($chat['time']).'

                     </small>

                     <br />

                     '.Core::bb ($chat['msg']).'

                 </div>

                 <div class = "place" style = "border-bottom: 1px solid #eee;">

                     <a class = "private_info" href = "'.HTTP.'/chat/?room='.$room['id'].'">

                         Чат / '.$room['name'].'

                     </a>

                 </div>

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     <b>Причина</b>:

                     <br />

                     <input type="radio" name="what" value="0" checked="checked" /> Грубость и оскорбления

                     <br />

                     <input type="radio" name="what" value="1"/> Нецензурная лексика

                     <br />

                     <input type="radio" name="what" value="2"/> СПАМ, реклама

                     <br />

                     <input type="radio" name="what" value="3"/> Иное

                 </div>

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     <b4>Бан на:</b4>

                     <br />

                     <select name = "time">
                         
                         <option value="0">1 ч.</option>
                        
                         <option value="1">3 ч.</option>

                         <option value="2">12 ч.</option>  

                         <option value="3">24 ч.</option>

                         <option value="4">48 ч.</option>

                         <option value="5">120 ч.</option>

                         <option value="6">240 ч.</option>        

                     </select> 

                 </div>

                 '.$err.'

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     Комментарий:

                     <br />

                     <textarea name = "msg"></textarea>

                     <br />

                     <input type = "submit" name = "ban" value = "Забанить">

                     <input type = "hidden" name = "CK" value = "'.$user['CK'].'">

                 </div>

             </div>

             </form>

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/chat">

                 Чат
             </a>

             <span class = "ico next"></span> 
 
             Бан

         </div>
 ';

 include_once ROOT.'/template/footer.php';
 
 }
 else header('Location: '.HTTP.'/chat');

?>