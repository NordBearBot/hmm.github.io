<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 if (isset ($_GET['mod']) and ($user['level'] == 1 or $user['level'] == 5)) { include_once $_SERVER['DOCUMENT_ROOT'].'/pages/chat/inc/mod.php'; exit;}
 if (isset ($_GET['ban']) and ($user['level'] == 1 or $user['level'] == 5)) { include_once $_SERVER['DOCUMENT_ROOT'].'/pages/chat/inc/ban.php'; exit;}

 if (isset ($_GET['new']) and $user['level'] == 1) {

     if (isset ($_POST['add'])) {

         $name = (string) Core::check ($_POST['name']);
         $CK = (int) abs ($_POST['CK']);

         if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/chat/?new");
         else if (empty ($name)) Core::redirect ("Введите название комнаты!", HTTP."/chat/?new");
         else if (Core::utf_strlen ($name) > 100) Core::redirect ("Название комнаты не должно превышать 100 символов!", HTTP."/chat/?new");

         $DB -> query ("INSERT INTO `chat_room` SET
                       `name` = ".$DB -> quote ($name).",
                       `user_id` = '".$user['id']."',
                       `time` = '".time ()."'");

         Core::redirect_ok ("Комната успешно создана!", HTTP."/chat");

     }

     $title = 'Чат';

     include_once ROOT.'/template/header.php';

     echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/chat">

                 Чат

             </a>

             <span class = "ico next"></span>

             Новая комната

         </div>
     ';

     Core::Error ();
     Core::Ok ();

     echo '

         <div class = "place user_info">

             <form action = "" method = "POST">

                 Название комнаты:

                 <small class = "private_info" id = "right">

                     100 символов

                 </small>

                 <br />

                 <input type = "text" name = "name">

                 <br />

                 <input type = "submit" name = "add" value = "Добавить">

                 <input type = "hidden" name = "CK" value = "'.$user['CK'].'"> 

             </form>

         </div>

     ';

     echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/chat">

                 Чат

             </a>

             <span class = "ico next"></span>

             Новая комната

         </div>
     ';




    include_once ROOT.'/template/footer.php';
    exit;

 }

 if (isset ($_GET['room'])) { include_once ROOT.'/pages/chat/inc/room.php'; exit; }

 $queryChatRoom = $DB -> query ("SELECT * FROM `chat_room` ORDER BY `id` DESC");

 $title = 'Чат';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Чат

         </div>
 ';
 
 Core:: Error ();
 Core:: Ok ();

 if ($queryChatRoom -> RowCount () < 1) echo '<div class = "place">Комнаты отсуствуют!</div>';
 else {
     
     echo '

         <div class = "background_place">

             <div class = "main_place">

     ';

     while ($chat = $queryChatRoom -> fetch ()) {

         echo '

                 <div>

                     <a class = "home" href = "'.HTTP.'/chat/?room='.$chat['id'].'">

                         '.$chat['name'].'

                     </a>

                 </div>

         ';

     }

     echo '

             </div>

         </div>

     ';
 }

 echo '

         <a href = "'.HTTP.'/chat/?moders" class = "home" style = "border-top: 1px solid #eee;">

             <img src = "'.HTTP.'/files/system.images/user.icons/mod_man_on.png">

             Модераторы

         </a>

 ';

 if ($user['level'] == 1) echo '<a href = "'.HTTP.'/chat/?new" class = "home">Создать комнату</a>';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Чат

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>