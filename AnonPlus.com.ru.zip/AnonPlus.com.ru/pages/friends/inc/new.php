<?php 
 
 $id = (int) abs ($_GET['new']);
 $code = (int) abs ($_GET['c']);

 $ank = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".$id."'") -> fetch ();

 $code = (int) abs ($_GET['c']);
 $queyFriedQuery = $DB -> query ("SELECT `id` FROM `query_friends` WHERE `komy` = '".$user['id']."' AND `ot` = '".$id."' AND `code` = '".$code."'") -> RowCount (); 

 if ($queyFriedQuery > 0) {

     $NewFraind = $DB -> query ("INSERT INTO `friends` SET `user_id` = '".$user['id']."', `friend_id` = '".$ank['id']."'");
     $NewFraind = $DB -> query ("INSERT INTO `friends` SET `user_id` = '".$ank['id']."', `friend_id` = '".$user['id']."'");

     $countData = $DB -> query ("SELECT `id` FROM `mail_contacts` WHERE `kto` = '0' AND `kogo` = '".$ank['id']."'") -> RowCount ();            
     if ($countData > 0) {
                     
         $queryContact = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '0' AND `kogo` = '".$ank['id']."'");
         $queryContact2 = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '".$ank['id']."' AND `kogo` = '0'");

     }  
     else {

         $queryContact = $DB -> query ("INSERT INTO `mail_contacts` SET 
                                       `id` = '',
                                       `kto` = '0',
                                       `kogo` = '".$ank['id']."',
                                       `time` = '".time ()."'");


         $queryContact2 = $DB -> query ("INSERT INTO `mail_contacts` SET 
                                          `id` = '',
                                          `kto` = '".$ank['id']."',
                                          `kogo` = '0',
                                          `time` = '".time ()."'");

     }
           
     $message_friend = 'Поздравляем! Пользователь [url='.HTTP.'/uid'.$user['id'].']'.$user['login'].'[/url] принял предложение вашей дружбы.';
           
     $queryMessage = $DB -> query ("INSERT INTO `mail_messages` SET
                                                `id` = '',
                                                `kto` = '0',
                                                `komy` = '".$ank['id']."',
                                                `text` = '".$message_friend."',
                                                `time` = '".time ()."'");  

     $DeleteQueryFraind = $DB -> query ("DELETE FROM `query_friends` WHERE `komy` = '".$user['id']."' AND `ot` = '".$ank['id']."'");

     Core::redirect_ok ("Предложение дружбы принято!", HTTP."/mail/?contact=0");

 }
 else Core::redirect ("Предложение дружбы не найдено!", HTTP."/mail/?contact=0");

?>