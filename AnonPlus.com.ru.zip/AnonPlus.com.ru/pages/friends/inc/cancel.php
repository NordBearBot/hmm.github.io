<?php 
 
 $id = (int) abs ($_GET['cancel']);
 $code = (int) abs ($_GET['c']);

 $queyFriedQuery = $DB -> query ("SELECT `id` FROM `query_friends` WHERE `komy` = '".$user['id']."' AND `ot` = '".$id."' AND `code` = '".$code."'") -> RowCount (); 

 if ($queyFriedQuery > 0) {

     $DeleteQueryFraind = $DB -> query ("DELETE FROM `query_friends` WHERE `komy` = '".$user['id']."' AND `ot` = '".$id."'");

     $countData = $DB -> query ("SELECT `kto`, `kogo` FROM `mail_contacts` WHERE `kto` = '0' AND `kogo` = '".$id."'") -> RowCount ();
                     
     if ($countData > 0) {
                     
         $queryContact = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '0' AND `kogo` = '".$id."'");
         $queryContact2 = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '".$id."' AND `kogo` = '0'");

     }  
     else {
                    
         $queryContact = $DB -> query ("INSERT INTO `mail_contacts` SET 
                                         `kto` = '0',
                                         `kogo` = '".$id."',
                                         `time` = '".time ()."'");  

         $queryContact2 = $DB -> query ("INSERT INTO `mail_contacts` SET 
                                          `kto` = '".$id."',
                                          `kogo` = '0',
                                          `time` = '".time ()."'");   

     }
                   
     $ank = $DB -> query ("SELECT `login`, `id` FROM `users` WHERE `id` = '".$id."'") -> fetch ();

     $message_friend = 'Сожалеем, но обитатель [url='.HTTP.'/uid'.$ank['id'].']'.$user['login'].'[/url] отклонил предложение вашей дружбы.';

                     
     $queryMessage = $DB -> query ("INSERT INTO `mail_messages` SET
                                     `kto` = '0',
                                     `komy` = '".$ank['id']."',
                                     `text` = '".$message_friend."',
                                     `time` = '".time ()."'");


     Core::redirect_ok ("Предложение дружбы отменено!", HTTP."/mail/?contact=0");
 
 }
 else Core::redirect ("Предложение дружбы не найдено!", HTTP."/mail/?contact=0");

?>