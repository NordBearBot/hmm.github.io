<?php 

 $queryUser = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".intval ( abs ($_GET['add']))."'");

 if ($queryUser -> RowCount () < 1) Core::redirect ("Пользователь не существует!", HTTP."/uid".$user['id']."/friends/");
 else $ank = $queryUser -> fetch ();

 $queryTryAddFruends = $DB -> query ("SELECT `id` FROM `query_friends` WHERE `komy` = '".$ank['id']."' AND `ot` = '".$user['id']."'") -> RowCount ();
 if ($queryTryAddFruends > 0) Core::redirect ("Вы уже отправили заявку в друзья этому пользователю, дождитесь его ответа!", HTTP."/uid".$ank['id']."");

 $queryTryAddFruendsTwo = $DB -> query ("SELECT `id` FROM `query_friends` WHERE `komy` = '".$user['id']."' AND `ot` = '".$ank['id']."'") -> RowCount ();
 if ($queryTryAddFruendsTwo > 0) Core::redirect ("Пользователь уже отправил вам заявку в друзья ранее, приймите её!", HTTP."/uid".$ank['id']."");

 if ($ank['id'] == $user['id']) Core::redirect ("Себя нельзя добавлять в друзья!", HTTP."/uid".$user['id']."/friends/");
 
 $queryTest = $DB -> query ("SELECT `id` FROM `friends` WHERE `user_id` = '".$user['id']."' AND `friend_id` = '".$ank['id']."'");  
 if ($queryTest -> RowCount () > 0) Core::redirect ("Пользователь уже находится у вас в друзьях!", HTTP."/uid".$user['id']."/friends/");

 if (isset ($_POST['friend'])) {

     $countData = $DB -> query ("SELECT `id` FROM `mail_contacts` WHERE `kto` = '0' AND `kogo` = '".$ank['id']."'") -> RowCount ();            
     if ($countData > 0) {
                     
         $queryContact = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '0' AND `kogo` = '".$ank['id']."'");
         $queryContact2 = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '".$ank['id']."' AND `kogo` = '0'");

     }  
     else {

         $queryContact = $DB -> query ("INSERT INTO `mail_contacts` SET 
                                       `id` = '',
                                       `kto` = '0',
                                       `kogo` = '".$ank['id']."',
                                       `time` = '".time ()."'");


         $queryContact2 = $DB -> query ("INSERT INTO `mail_contacts` SET 
                                          `id` = '',
                                          `kto` = '".$ank['id']."',
                                          `kogo` = '0',
                                          `time` = '".time ()."'");

     }
     
     $code = mt_rand (1936234, 9364912);
     $queryAddFraind = $DB -> query ("INSERT INTO `query_friends` SET `komy` = '".$ank['id']."', `ot` = '".$user['id']."', `code` = '".$code."'");
                   
     $message_friend = 'Пользователь [url='.HTTP.'/uid'.$user['id'].']'.$user['login'].'[/url] предлагает вам дружбу.
     [url='.HTTP.'/uid'.$ank['id'].'/friends/?new='.$user['id'].'&c='.$code.']Принять[/url] [url='.HTTP.'/uid'.$ank['id'].'/friends/?cancel='.$user['id'].'&c='.$code.']Отклонить[/url]';

                     
     $queryMessage = $DB -> query ("INSERT INTO `mail_messages` SET
                                   `id` = '',
                                   `kto` = '0',
                                   `komy` = '".$ank['id']."',
                                   `text` = '".$message_friend."',
                                   `time` = '".time ()."'");  

     Core::redirect_ok ("Предложение дружбы отправлено!", HTTP."/uid".$ank['id']);

 }

 $description = $ank['login'].' / Предложить дружбу';
 $keywords = NULL;
 $title = $ank['login'].' / Предложить дружбу';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/friends/">

                 Друзья

             </a>

         </div>

         <div class = "nav">

             Предложить дружбу

         </div>

 ';

 echo '

         <div class = "block">

             Вы действительно хотите отправить уведомление о дружбе пользователю <b>'.$ank['login'].'</b>?

             <br />
             
             <form action = "" method = "POST">
             
                 <input type = "submit" name = "friend" value = "Да, отправить"> <a href = "'.HTTP.'/uid'.$ank['id'].'">Нет</a>

             </form>
             
         </div>

 ';

 echo '
 
         <div class = "nav">

             Предложить дружбу

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/friends/">

                 Друзья

             </a>

         </div>

 ';

 include_once ROOT.'/template/footer.php';

?>