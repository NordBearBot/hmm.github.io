<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $id = (int) abs ($_GET['id']);
 $queryUser = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".$id."'");

 if ($queryUser -> RowCount () < 1) Core::redirect ("Пользователь не существует!", HTTP."/uid".$id."");
 else $ank = $queryUser -> fetch ();

 if ($user['id'] == $ank['id']) {

     if ($user and isset ($_GET['add']) and !empty ($_GET['add'])) { include_once ROOT.'/pages/friends/inc/add_friend.php'; exit; }
     if ($user and isset ($_GET['new']) and !empty ($_GET['new']) and isset ($_GET['c'])) { include_once ROOT.'/pages/friends/inc/new.php'; exit; }
     if ($user and isset ($_GET['cancel']) and !empty ($_GET['cancel']) and isset ($_GET['c'])) { include_once ROOT.'/pages/friends/inc/cancel.php'; exit; }

 }

 $queryFriends = $DB -> query ("SELECT * FROM `friends` WHERE `user_id` = '".$id."' ORDER BY `online` DESC");

 $description = $ank['login'].' / Друзья';
 $keywords = NULL;
 $title = $ank['login'].' / Друзья';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             Друзья

         </div>
 ';

 if ($queryFriends -> RowCount () < 1) echo '<div class = "block">Друзья отсуствуют!</div>';
 else {

     while ($friend = $queryFriends -> fetch ()) {

         echo '

         <a class = "home" href = "'.HTTP.'/uid'.$friend['friend_id'].'">

             <div id = "avatar">

                 '.Core::avatar ($friend['friend_id'], '40').'

             </div>

             '.Core::user ($friend['friend_id'], 0, 1, 0).'
             <br />

             <small>

                 '.Core::UserEnd ($friend['friend_id']).'

             </small>
             
        </a>

         ';

     }

 }

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             Друзья

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>