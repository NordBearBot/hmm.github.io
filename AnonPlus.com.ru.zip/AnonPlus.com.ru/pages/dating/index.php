<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $sect = (int) abs ($_GET['section']);

 $dating_q = ($sect == 1) ? "AND `sex` = '1'" : "AND `sex` = '0'";

 $queryUsers = $DB -> query ("SELECT `id`, `login`, `data_registration`, `rating` FROM `users` WHERE `dating` = '1' ".$dating_q." AND `id` != '".$user['id']."' ORDER BY `online` DESC");

 $description = 'Найдите свою вторую половинку на Ruswap. Бесплатный сайт знакомств для Вас.';
 $keywords = 'хорошие бесплатные знакомства, бесплатный сайт знакомств для взрослых, бесплатный сайт знакомств, сайт знакомств вход, знакомства и общение, лучшие сайты знакомств, познакомиться с парнем, познакомиться, познакомиться с девушкой, познакомиться для отношений, познакомиться серьезно, где познакомиться с девушкой, знакомства, знакомства для отношений, сайт знакомств и отношений, где познакомиться';
 $title = 'Знакомства на '.DOMAIN.' - добро пожаловать!';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Знакомства

         </div>
 ';

 $man = (empty ($sect) or $sect != 1) ? '<span id = "t"></span>' : '';
 $woman = ($sect == 1) ? '<span id = "t"></span>' : '';

 $link_man = (empty ($sect) or $sect != 1) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/dating/?" class = "no_act act_l_b act_r_b">';
 $link_woman = ($sect == 1) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/dating/?section=1" class = "no_act act_l_b act_r_b">';

 echo '

         <div class = "block" style = "border: none; padding-bottom: 0px;">

             <div class = "part" style = "width: 50%;">

                 '.$link_man.' Мальчики </a>

                 '.$man.'

             </div>

             <div class = "part" style = "width: 50%;">

                  '.$link_woman.' Девочки </a>

                 '.$woman.'

             </div>

         </div>

 ';

 Core:: Error ();

 if ($queryUsers -> RowCount () < 1) {

         echo '

         <div class = "block">

             Пользователей нету!

         </div>

         ';
 }
 else {
 
     echo '

         <div class = "background_place">

     ';

     while ($ank = $queryUsers -> fetch ()) {

         $info = $DB -> query ("SELECT * FROM `user_anketa` WHERE `user_id` = '".$ank['id']."'") -> fetch ();

         $l = (!empty ($info['name']) and !empty ($info['age'])) ? ', ' : NULL;
         $l2 = (!empty ($info['name']) and !empty ($info['city']) and empty ($info['age'])) ? ', ' : NULL;
         $l3 = (!empty ($info['age']) and !empty ($info['city'])) ? ', ' : NULL;
         $information = $info['name'].''.$l.''.$l2.''.$info['age'] = (!empty ($info['age']) ? $info['age'].' лет' : '').''.$l3.''.$info['city'];

         echo '

         <div class = "main_place">

         <div class = "place">

             <div id = "avatar">

                 '.Core::avatar ($ank['id'], '40').'

             </div>

             <div id = "content" class = "user_info">

                 '.Core::user ($ank['id'], 0, 1, 1).'

                 <span class = "count_web">

                     <small>

                         '.Core::UserRating ($ank['rating']).'

                     </small>

                 </span>

                 <span id = "right">

                    <a href="'.HTTP.'/mail/?new&name='.$ank['login'].'" class="adv_user_link" id="mail_link" title="Отправить сообщение"><span></span></a>
                 
                 </span>

                 <br />

                 <small>

                     '.$info['name'].'

                     '.((!empty ($info['name']) and empty($info['age'])) ? '<br />' : '').'

                     '.((!empty ($info['name']) and !empty($info['age'])) ? '<br />' : '').'

                     <span class = "private_info">

                         '.$info['age'].'

                         '.(!empty ($info['age']) ? '<br />' : '').'

                         '.Core::userSite ($ank['data_registration']).'

                     </span>

                     '.((empty ($info['age']) and empty ($info['name'])) ? '<p>' : '').'              

                 </small>

             </div>

         </div>

         </div>

         ';

     }

     echo '

         </div>

     ';

 }

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Знакомства

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>