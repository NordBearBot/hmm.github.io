<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 
 Core::CheckUser ();

 ## Обновляем время посищения в ленте
 $DB -> query ("UPDATE `users` SET `lenta_time` = '".time ()."' WHERE `id` = '".$user['id']."'");

 ## Сортировка
 $section = ($_GET['section'] == 1 ? "AND `type` = '1'" : ($_GET['section'] == 2 ? "AND `type` = '2'" : ""));

 ## Пагинация
 $c_p = $DB -> query ("SELECT `friends`.*, `lenta`.* FROM `friends`, `lenta` WHERE `friends`.`user_id`='".$user['id']."' AND `lenta`.`user_id`=`friends`.`friend_id` ".$section."") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 ## Выбираем записи из БД
 $queryLenta = $DB -> query ("SELECT `friends`.*, `lenta`.* FROM `friends`, `lenta` WHERE `friends`.`user_id`='".$user['id']."' AND `lenta`.`user_id`=`friends`.`friend_id` ".$section." ORDER BY `time` DESC LIMIT $start, ".$p_page."");

 $title = $user['login'].' / Лента';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>
             
             <span class = "ico next"></span>

             Лента

         </div>
 ';
 
 Core:: Error ();
 Core:: Ok ();

 $all = (empty ($_GET['section'])) ? '<span id = "t"></span>' : '';
 $blogs = ($_GET['section'] == 1) ? '<span id = "t"></span>' : '';
 $files = ($_GET['section'] == 2) ? '<span id = "t"></span>' : '';

 $link_all = (empty ($_GET['section'])) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/lenta/?" class = "no_act act_l_b act_r_b">';
 $link_blogs = ($_GET['section'] == 1) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/lenta/?section=1" class = "no_act act_l_b act_r_b">';
 $link_files = ($_GET['section'] == 2) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/lenta/?section=2" class = "no_act act_l_b act_r_b">';

 echo '
         <div class = "block" style = "border: none; padding-bottom: 0px;">

             <div class = "part">

                 '.$link_all.' Все </a>

                 '.$all.'

             </div>

             <div class = "part">

                  '.$link_blogs.' Записи </a>

                 '.$blogs.'

             </div>

             <div class = "part">

                 '.$link_files.' Файлы </a>

                 '.$files.'

             </div>

         </div>

         <div class = "background_place">

 ';

 while ($lenta = $queryLenta -> fetch ()) {

     $querySex = $DB -> query ("SELECT `sex` FROM `users` WHERE `id` = '".$lenta['user_id']."'") -> fetch ();
     $sex = ($querySex['sex'] == 1) ? 'а' : '';
     $sex_share = ($querySex['sex'] == 1) ? 'ась' : 'ся';

     $data = $DB -> query ("SELECT `id`, `user_id` FROM `".($lenta['type'] == 1 ? 'blogs' : ($lenta['type'] == 2 ? 'pictures' :($lenta['type'] == 3 ? 'files' : 'blogs')))."` WHERE `id` = '".($lenta['share'] > 0 ? $lenta['share'] : $lenta['object_id'])."'") -> fetch ();
     $share = (($lenta['type'] == 1 || $lenta['type'] == 4) and $data['user_id'] != $user['id'] and $lenta['access'] == 0) ? Blog::share_link ($data['id']) : '';
      
     $section_type = ($lenta['type'] == 1 ? '0' :($lenta['type'] == 2 ? '1' : ($lenta['type'] == 3 ? '3' : '0')));
     $queryTest = $DB -> query ("SELECT `id` FROM `bookmarks` WHERE `user_id` = '".$user['id']."' AND `type` = '".$section_type."' AND `object_id` = '".$data['id']."'") -> RowCount ();     
     $bookmark = ($queryTest < 1) ? '<span id = "right"><a href="'.HTTP.'/bookmarks/add/?type='.$section_type.'&id='.$data['id'].'" class="adv_user_link" id="bookmark_link" title="Добавить в закладки"><span></span></a></span>' : '<span id = "right"><a href="'.HTTP.'/bookmarks/delete/?type='.$section_type.'&id='.$data['id'].'" class="adv_user_link" id="bookmark_link" title="Удалить из закладок"><span style="background-position: -32px -16px; !important;"></span></a></span>';
         
     $type = ($lenta['type'] == 1 ? 
        'создал'.$sex.' запись' : ($lenta['type'] == 2 ? 
        'добавил'.$sex.' фото' : ($lenta['type'] == 3 ? 
        'добавил'.$sex.' файл' : ($lenta['type'] == 4 ? 
        'поделил'.$sex_share.' записью' : ''))));

     echo '

         <div class = "main_place">

         <div class = "place">

             <div id = "avatar">

                 '.Core::avatar ($lenta['user_id'], '40').'

             </div>

             <div id = "content">

                 '.Core::user ($lenta['user_id'], 1, 1, 1).'

                 <small id = "right" class = "private_info">

                     '.Core::date_time ($lenta['time']).'

                 </small>

                 '.$type.'

                 <br />

                 <a href = "'.HTTP.$lenta['url'].'">

                     '.($lenta['type'] == 2 ? '<img class = "photo" src = "'.HTTP.Core::without_bb($lenta['message']).'">' : (($lenta['type'] == 1 or $lenta['type'] == 4) ?
                     ''.Core::without_bb ($lenta['message']).'' : ($lenta['type'] == 3 ? $lenta['message'] : 'object none'))).'

                 </a>

             </div>

         </div>

         '.($lenta['type'] == 4 ? Blog::share ($lenta['share']) : '').'

         <div class = "block">
 
             <a href="'.HTTP.$lenta['url'].'" class="adv_user_link adv_user_link_text" id="comment_link" title="Комментировать"><span class="ico"></span> <span class="m block_link_text">Обсудить</span></a>
             
             '.$share.'

             '.$bookmark.'

         </div>

         </div>

         ';

         /*

         if ($lenta['type'] == 1) {

         echo '

         <div class = "block" style = "overflow: hidden;">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/view.png"> <small>'.$blog['view'].'</small>
             ·
             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/comment.png"> <small>'.$blog['comment_num'].'</small>

         </div>

         ';

         }

         */

 $sex = NULL;

 }

 echo '

         </div>

 ';

 $p_section = ($_GET['section'] == 1 ? 'section=1' : ($_GET['section'] == 2 ?
                                       'section=2' : ''));

 if ($k_page > 1) Core::str(''.HTTP.'/lenta/?'.$p_section.'&', $k_page, $page);

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>

             <span class = "ico next"></span>

             Лента

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>