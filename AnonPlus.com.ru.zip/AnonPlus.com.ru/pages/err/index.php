<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 if (!isset ($_SESSION['err'])) header ('Location: '.HTTP.'/');

 $title = 'Ошибка';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Ошибка

         </div>
 ';
 
 Core:: Error ();

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Ошибка

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>