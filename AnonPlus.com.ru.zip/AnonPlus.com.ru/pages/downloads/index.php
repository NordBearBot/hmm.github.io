<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 ## $user['level'] = 3; Модератор файлов

 if (isset ($_GET['ban_file']) and ($user['level'] == 3 or $user['level'] == 1)) {  include_once $_SERVER['DOCUMENT_ROOT'].'/pages/downloads/inc/ban_file.php'; exit;}

 if (isset ($_GET['new_folder']) and $user['level'] == 1) {  include_once $_SERVER['DOCUMENT_ROOT'].'/pages/downloads/inc/add_folder.php'; exit; }

 if (isset ($_GET['add']) && (isset ($_GET['file']) or isset ($_GET['pic'])) && $user) { include_once $_SERVER['DOCUMENT_ROOT'].'/pages/downloads/inc/add_file.php'; exit; }
 
 if (isset ($_GET['check']) and ($user['level'] == 3 or $user['level'] == 1)) { include_once $_SERVER['DOCUMENT_ROOT'].'/pages/downloads/inc/check_moder.php'; exit; }

 if (isset ($_GET['folder'])) { include_once $_SERVER['DOCUMENT_ROOT'].'/pages/downloads/inc/folder.php'; exit; }

 $queryFolder = $DB -> query ("SELECT * FROM `downloads_folder` WHERE `folder_id` = '0'");

 $description = 'Фото, видео, музыка, 18+';
 $title = 'Файлы';
 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Файлы

         </div> 

 ';

 Core::Error ();
 Core::Ok ();

 if ($queryFolder -> RowCount () < 1) echo '<div class = "block">Папки отсуствуют!</div>';
 else {

     while ($f = $queryFolder -> fetch ()) {

         echo '

         <a class = "home" href = "'.HTTP.'/files/?folder='.$f['id'].'">

             <img src = "'.HTTP.'/files/system.images/site.icons/'.($f['type'] == 'picture' ? 'picture.png' :  ($f['type'] == 'video' ? 'video.png' : ($f['type'] == 'music' ? 'file_mp3.png' : ($f['type'] == 'game' ? 'games.png' : ($f['type'] == 'program' ? 'sz.png' : 'folder.png'))))).'"> '.$f['name'].'

             <span class = "count_web">

                 <small>

                     '.$f['count'].'

                 </small>

             </span>

         </a>

         ';

     }

 }

 if ($user['level'] == 1) {

    echo '
         <a class = "home-f" href = "'.HTTP.'/files/?new_folder">

             Создать папку

         </a>
    ';

 }

 echo '
         <a class = "home-f" href = "'.HTTP.'/files/?moders">

             <img src = "'.HTTP.'/files/system.images/user.icons/mod_man_on.png"> Список модераторов

         </a>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Файлы

         </div> 

 ';

 include_once ROOT.'/template/footer.php';

?>