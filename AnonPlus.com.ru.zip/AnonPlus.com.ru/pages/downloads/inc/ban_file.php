<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $file_id = (int) abs ($_GET['ban_file']);
 $type_file = (int) abs ($_GET['type']);

 $sql_table = ($type_file == 0) ? 'pictures' : 'files';

 $queryFile = $DB -> query ("SELECT * FROM `".$sql_table."` WHERE `id` = '".$file_id."'");
 if ($queryFile -> RowCount () < 1) Core::redirect ("Файл не существует!", HTTP."/files");

 $file = $queryFile -> fetch ();
 $ank = $DB -> query ("SELECT `id` FROM `users` WHERE `id` = '".$file['user_id']."'") -> fetch ();

 $queryDown = $DB -> query ("SELECT * FROM `downloads_files` WHERE `file_id` = '".$file['id']."' AND `type` = '".$sql_table."'");
 if ($queryDown -> RowCount () > 0) $down = $queryDown -> fetch ();

 $queryTryRemark = $DB -> query ("SELECT `id` FROM `user_ban_list` WHERE `type` = 'ban_file' AND `object_id` = '".$file['id']."' AND `type_file` = '".$sql_table."'");
 if ($queryTryRemark -> RowCount () > 0) Core::redirect ("Уже было выдано нарушение за этот файл!", HTTP."/files");



 if (isset ($_POST['ban'])) {

     $CK = (int) abs ($_POST['CK']);
     if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/files/?ban_file=".$file['id']."&type=".$type_file);

     $msg = (string) Core::check ($_POST['msg']);
     $err = (Core::utf_strlen ($msg) > 1000) ? '<div class = "err">Сообщение не должно превышать 1000 символов!</div>' : NULL;

     if (empty ($err)) {

         $what = (int) abs ($_POST['what']);
         $what = ($what > 6) ? 6 : $what;
         $what = (empty ($down['id']) and $what == 5) ? 6 : $what;

         $time = (int) abs ($_POST['time']);
         $time = ($time > 6) ? 0 : $time;
 
         $time_ban = ($time == 0 ? 3600 : ($time == 1 ? 10800 : ($time == 2 ? 43200 : ($time == 3 ? 86400 : ($time == 4 ? 172800 : ($time == 5 ? 432000 : ($time == 6 ? 864000 : 3600)))))));
         
         $DB -> query ("INSERT INTO `block_files` SET
                       `user_id` = '".$ank['id']."',
                       `file_id` = '".$file['id']."',
                       `file_type` = '".$sql_table."',
                       `file_name` = '".$file['name']."',
                       `file_description` = '".$file['description']."',
                       `file_type_name` = '".$file['type']."',
                       `add_file` = '".$file['time']."',
                       `ban_file` = '".time ()."',
                       `folder_id` = '".$file['folder_id']."',
                       `file_key` = '".$file['key_name_file']."'");

         $DB -> query ("UPDATE `".$sql_table."_folder` SET `count` = `count` -1 WHERE `id` = '".$file['folder_id']."'");

         $DB -> query ("DELETE FROM `".$sql_table."` WHERE `id` = '".$file['id']."'");

         $f = $DB -> query ("SELECT `id` FROM `block_files` WHERE `user_id` = '".$ank['id']."' ORDER BY `id` DESC LIMIT 1") -> fetch ();

         $DB -> query ("INSERT INTO `user_ban_list` SET
                       `type` = 'ban_file',
                       `object_id` = '".$f['id']."',
                       `user_id` = '".$ank['id']."',
                       `moder_id` = '".$user['id']."',
                       `time` = '".time ()."',
                       `ban_time` = '".$time_ban."',
                       `what` = '".$what."',
                       `message` = ".$DB -> quote ($msg).",
                       `type_file` = '".$sql_table."'");

         $DB -> query ("DELETE FROM `downloads_files` WHERE `id` = '".$down['id']."'");

         if ($sql_table == 'pictures') {

             $queryAva = $DB -> query ("SELECT `id` FROM `users_avatar` WHERE `pic_id` = '".$file['id']."' AND `user_id` = '".$user['id']."'");
             if ($queryAva -> RowCount () > 0) $DB -> query ("UPDATE `users` SET `avatar` = '0' WHERE `id` = '".$user['id']."'");

         }

         Core::redirect_ok ("Файл заблокирован!", HTTP."/files");

     }

 }

 $title = 'Файлы / Бан';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/files">

                 Файлы

             </a>

             <span class = "ico next"></span> 
 
             Бан

         </div>
 ';
 
 Core:: Error ();
 Core:: Ok ();

 echo '

         <div class = "background_place">

             <form action = "" method = "POST">

             <div class = "main_place">

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                         Бан

                     </a>

                 </div>

                 <div class = "place" style = "border-bottom: 1px solid #eee;">

                     '.Core::user ($ank['id'], 1, 1, 1).'

                 </div>

                 <div class = "place" style = "border-bottom: 1px solid #eee;">

                     <a class = "private_info" href = "'.HTTP.'/uid'.$ank['id'].'/'.$sql_table.'/?folder='.$file['folder_id'].'&'.($type_file == 0 ? 'pic' : 'file').'='.$file['id'].'">

                         Файл: '.$file['name'].'.'.$file['type'].'

                     </a>

                     <br />

                     <span class = "private_info">

                         Загружен: '.Core::date_time ($file['time']).'

                         '.(!empty ($down['id']) ? '<br />Добавлен в Файлообменник: '.Core::date_time ($down['time']) : '').'

                     </span>

                 </div>

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     <b>Причина</b>:

                     <br />

                     <input type="radio" name="what" value="0" checked="checked" /> Нет метки (18+)

                     <br />

                     <input type="radio" name="what" value="1"/> Грубость и оскорбления

                     <br />

                     <input type="radio" name="what" value="2"/> Намеки на ДП

                     <br />

                     <input type="radio" name="what" value="3"/> ДП

                     <br />
                     
                     <input type="radio" name="what" value="4"/> Педофилия

                     <br />

                     '.(!empty ($down['id']) ? '<input type="radio" name="what" value="5"/> Не верная карегория <br />' : '').'

                     <input type="radio" name="what" value="6"/> Инное

                 </div>

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     <b4>Бан на:</b4>

                     <br />

                     <select name = "time">
                         
                         <option value="0">1 ч.</option>
                        
                         <option value="1">3 ч.</option>

                         <option value="2">12 ч.</option>  

                         <option value="3">24 ч.</option>

                         <option value="4">48 ч.</option>

                         <option value="5">120 ч.</option>

                         <option value="6">240 ч.</option>        

                     </select> 

                 </div>

                 '.$err.'

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     Комментарий:

                     <br />

                     <textarea name = "msg"></textarea>

                     <br />

                     <input type = "submit" name = "ban" value = "Забанить">

                     <input type = "hidden" name = "CK" value = "'.$user['CK'].'">

                 </div>

             </div>

             </form>

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/chat">

                 Чат
             </a>

             <span class = "ico next"></span> 
 
             Бан

         </div>
 ';

 include_once ROOT.'/template/footer.php';
 
?>