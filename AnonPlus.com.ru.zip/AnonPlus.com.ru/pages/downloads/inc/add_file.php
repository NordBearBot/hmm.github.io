<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 ## $user['level'] = 3; Модератор файлов

 $file = (int) (isset ($_GET['file']) ? abs ($_GET['file']) : (isset ($_GET['pic']) ? abs ($_GET['pic']) : 0));
 $sql_table = (isset($_GET['file'])) ? 'files' : 'pictures';

 $queryFile = $DB -> query ("SELECT `id`, `type`, `folder_id` FROM `".$sql_table."` WHERE `id` = '".$file."' AND `user_id` = '".$user['id']."'");

 if ($queryFile -> RowCount () < 1) Core::redirect ("Файл не найден!", HTTP."/uid".$user['id']."/".$sql_table);
 $file = $queryFile -> fetch ();

 if ($file['folder_id'] != 0) {

     $queryAccessFolder = $DB -> query ("SELECT `id` FROM `".$sql_table."_folder` WHERE `id` = '".$file['folder_id']."' AND `access` = '0'");
     if ($queryAccessFolder -> RowCount () < 1) Core::redirect ("Нельзя добавлять файлы которые в закрытых папках!", HTTP."/uid".$user['id']."/".$sql_table);
 }
 
 $sql_type = (($file['type'] == 'jpg' or $file['type'] == 'jpeg' or $file['type'] == 'png' or $file['type'] == 'gif' or $file['type'] == 'bmp') ? 'picture'
 : (($file['type'] == '3gp' or $file['type'] == 'mp4' or $file['type'] == 'avi' or $file['type'] == 'flw') ? 'video'
 : (($file['type'] == 'exe' or $file['type'] == 'rar' or $file['type'] == 'zip' or $file['type'] == '7z' or $file['type'] == 'apk' or $file['type'] == 'jar' or $file['type'] == 'jad' or $file['type'] == 'sis' or $file['type'] == 'ipa' or $file['type'] == 'xap' or $file['type'] == 'cab') ? 'game'
 : (($file['type'] == 'exe' or $file['type'] == 'rar' or $file['type'] == 'zip' or $file['type'] == '7z' or $file['type'] == 'apk' or $file['type'] == 'jar' or $file['type'] == 'jad' or $file['type'] == 'sis' or $file['type'] == 'ipa' or $file['type'] == 'xap' or $file['type'] == 'cab') ? 'program'
 : (($file['type'] == 'mp3' or $file['type'] == 'midi' or $file['type'] == 'wav' or $file['type'] == 'wma') ? 'mp3' 
 : 'other')))));

 $queryTestFile = $DB -> query ("SELECT `id` FROM `downloads_files` WHERE `type` = '".$sql_table."' AND `file_id` = '".$file['id']."'");
 if ($queryTestFile -> RowCount () > 0) Core::redirect ("Вы уже добавили этот файл в Файлообменник!", HTTP."/uid".$user['id']."/".$sql_table);

 $folder_id = (int) abs ($_GET['folder']);
 $folder_id2 = (int) abs ($_GET['folder']);

 $folder = ($folder_id > 0) ? $DB -> query ("SELECT `id` FROM `downloads_folder` WHERE `folder_id` = '".$folder_id."' AND `type` = '".$sql_type."'") -> RowCount () : 0;
 $folder_id = ($folder > 0) ? $folder_id : 0;

 if ($folder < 1) {

     $queryTestFolder = $DB -> query ("SELECT `id`, `folder_id` FROM `downloads_folder` WHERE `id` = '".$folder_id2."' AND `type` = '".$sql_type."'");
     
     if ($queryTestFolder -> RowCount () > 0) {

         if ($_GET['CK'] != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/uid".$user['id']."/".$sql_table);

         $file_data = $queryTestFolder -> fetch ();

         ## Добавляем файл в ЗО
         $DB -> query ("INSERT INTO `downloads_files` SET `folder_id` = '".$file_data['id']."', `file_id` = '".$file['id']."', `type` = '".$sql_table."', `time` = '".time ()."'");

         $DB -> query ("UPDATE `downloads_folder` SET `count` = `count` +1 WHERE `id` = '".$file_data['id']."'");

         $q2 = $DB -> query ("SELECT * FROM `downloads_folder` WHERE `id` = '".$file_data['folder_id']."'");

         if ($q2 -> RowCount () > 0) {

             $f2 = $q2 -> fetch ();

             $DB -> query ("UPDATE `downloads_folder` SET `count` = `count` +1 WHERE `id` = '".$f2['id']."'");

             $q3 = $DB -> query ("SELECT * FROM `downloads_folder` WHERE `id` = '".$f2['folder_id']."'");

             if ($q3 -> RowCount () > 0) {

                 $f3 = $q3 -> fetch ();

                 $DB -> query ("UPDATE `downloads_folder` SET `count` = `count` +1 WHERE `id` = '".$f3['id']."'");

                 $q4 = $DB -> query ("SELECT * FROM `downloads_folder` WHERE `id` = '".$f3['folder_id']."'");

                 if ($q4 -> RowCount () > 0) {

                     $f4 = $q4 -> fetch ();

                     $DB -> query ("UPDATE `downloads_folder` SET `count` = `count` +1 WHERE `id` = '".$f4['id']."'");

                     $q5 = $DB -> query ("SELECT * FROM `downloads_folder` WHERE `id` = '".$f3['folder_id']."'");
                         
                     if ($q5 -> RowCount () > 0) {

                         $f5 = $q5 -> fetch ();

                         $DB -> query ("UPDATE `downloads_folder` SET `count` = `count` +1 WHERE `id` = '".$f5['id']."'");
            
                     }

                 }

             } 

         }



         Core::redirect_ok ("Файл успешно добавлен в Файлообменник.", HTTP."/uid".$user['id']."/".$sql_table);

     }


 }

 $queryFolders = $DB -> query ("SELECT * FROM `downloads_folder` WHERE `folder_id` = '".$folder_id."' AND `type` = '".$sql_type."'");

 $title = 'Файлы';
 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Файлы

         </div> 

 ';

 while ($folder = $queryFolders -> fetch ()) {

     echo '

         <a class = "home" href = "'.HTTP.'/files/?add&'.($sql_table == 'files' ? 'file=' : 'pic=').$file['id'].'&folder='.$folder['id'].'&CK='.$user['CK'].'">

             <img src = "'.HTTP.'/files/system.images/site.icons/folder.png"> '.$folder['name'].'

             <span class = "count_web">

                 <small>

                     '.$folder['count'].'

                 </small>

             </span>

         </a>

     ';

 }

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Файлы

         </div> 

 ';

 include_once ROOT.'/template/footer.php';

?>