<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 
 ## $user['level'] = 3; Модератор файлов

 $c_p = $DB -> query ("SELECT * FROM `downloads_files` WHERE `status` = '1'") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryFiles = $DB -> query ("SELECT * FROM `downloads_files` WHERE `status` = '1' ORDER BY `id` DESC LIMIT $start, ".$p_page."");
 $countNewFiles = $DB -> query ("SELECT * FROM `downloads_files` WHERE `status` = '1'") -> RowCount ();

 if (isset ($_GET['add'])) {

    $add = (int) abs ($_GET['add']);
    $CK = (int) abs ($_GET['CK']);

    if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/files/?check");

    $queryFile = $DB -> query ("SELECT `id` FROM `downloads_files` WHERE `id` = '".$add."'") -> RowCount ();

    if ($queryFile > 0) {

        $DB -> query ("UPDATE `downloads_files` SET `status` = '0', `moder` = '".$user['id']."' WHERE `id` = '".$add."'");

        Core::redirect_ok ("Файл успешно прошел модерацию.", HTTP."/files/?check");

    }
    else Core::redirect ("Файл не найден!", HTTP."/files/?check");
 }

 if (isset ($_GET['del'])) {

    $del = (int) abs ($_GET['del']);
    $CK = (int) abs ($_GET['CK']);

    if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/files/?check");

    $queryFile = $DB -> query ("SELECT `id`, `folder_id` FROM `downloads_files` WHERE `id` = '".$del."'");

    if ($queryFile -> RowCount () > 0) {
 
         $file_data = $queryFile -> fetch ();

         $q2 = $DB -> query ("SELECT * FROM `downloads_folder` WHERE `id` = '".$file_data['folder_id']."'");

         if ($q2 -> RowCount () > 0) {

             $f2 = $q2 -> fetch ();

             $DB -> query ("UPDATE `downloads_folder` SET `count` = `count` -1 WHERE `id` = '".$f2['id']."'");

             $q3 = $DB -> query ("SELECT * FROM `downloads_folder` WHERE `id` = '".$f2['folder_id']."'");

             if ($q3 -> RowCount () > 0) {

                 $f3 = $q3 -> fetch ();

                 $DB -> query ("UPDATE `downloads_folder` SET `count` = `count` -1 WHERE `id` = '".$f3['id']."'");

                 $q4 = $DB -> query ("SELECT * FROM `downloads_folder` WHERE `id` = '".$f3['folder_id']."'");

                 if ($q4 -> RowCount () > 0) {

                     $f4 = $q4 -> fetch ();

                     $DB -> query ("UPDATE `downloads_folder` SET `count` = `count` -1 WHERE `id` = '".$f4['id']."'");

                     $q5 = $DB -> query ("SELECT * FROM `downloads_folder` WHERE `id` = '".$f3['folder_id']."'");
                         
                     if ($q5 -> RowCount () > 0) {

                         $f5 = $q5 -> fetch ();

                         $DB -> query ("UPDATE `downloads_folder` SET `count` = `count` -1 WHERE `id` = '".$f5['id']."'");
            
                     }

                 }

             } 

         }

         $DB -> query ("DELETE FROM `downloads_files` WHERE `id` = '".$file_data['id']."'");

         Core::redirect_ok ("Файл удален из Файлообменника.", HTTP."/files/?check");

    }
    else Core::redirect ("Файл не найден!", HTTP."/files/?check");
 }

 $title = 'Файлы / Модерирование файлов';
 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/files">

                 Файлы

             </a>

             <span class = "ico next"></span>

             Модерирование файлов

         </div>';

         echo Core::Error ();

         echo Core::Ok ();

         echo '<div class = "background_place">

             <div class = "main_place">

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                              Новых файлов <span class = "count_web">'.$countNewFiles.'</span>

                     </a>

                 </div>

 ';

 if ($countNewFiles < 1) echo '<div class = "place">Новых файлов нету.</div>';
 else {

     while ($file = $queryFiles -> fetch ()) {

         $data = $DB -> query ("SELECT * FROM `".$file['type']."` WHERE `id` = '".$file['file_id']."'") -> fetch ();
         $folder = $DB -> query ("SELECT * FROM `downloads_folder` WHERE `id`= '".$file['folder_id']."'") -> fetch ();
         $folder2 = $DB -> query ("SELECT * FROM `downloads_folder` WHERE `id` = '".$folder['folder_id']."'") -> fetch ();

         echo '

                 <div class = "block user_info">

                     '.(($file['type'] == 'pictures' or ($data['type'] == 'jpg' or $data['type'] == 'jpeg' or $data['type'] == 'png' or $data['type'] == 'gif' or $data['type'] == 'bmp')) ? '<div id = "avatar"><img src = "'.HTTP.'/files/user.files/pictures/128/photo'.$data['id'].'_'.$data['key_name_file'].'.'.$data['type'].'"></div>' : '').'

                     <a class = "edit_c" href="'.HTTP.'/uid'.$data['user_id'].'/'.$file['type'].'/?folder='.$data['folder_id'].'&'.($file['type'] == 'files' ? 'file' : 'pic').'='.$data['id'].'">

                         '.files_methods::typeFile ($data['type']).' <b>'.$data['name'].'</b>.'.$data['type'].'

                         '.($data['consored'] == 1 ? '<img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/adult_ico.png">' : '').'

                     </a>

                     <br />

                     <a class = "private_info" href = "'.HTTP.'/files/?folder='.$folder['id'].'">

                         '.$folder2['name'].' '.(!empty ($folder2['name']) ? '/' : '').' '.$folder['name'].'

                     </a>

                     <br />

                     <a href = "'.HTTP.'/files/?check&add='.$file['id'].'&CK='.$user['CK'].'">Добавить</a> | <a href = "'.HTTP.'/files/?check&del='.$file['id'].'&CK='.$user['CK'].'">Удалить</a>

                     <br />

                 </div>

         ';

     }

     if ($k_page > 1) Core::str(''.HTTP.'/files/?check&', $k_page, $page);

 }
 echo '

             </div>

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/files">

                 Файлы

             </a>

             <span class = "ico next"></span>

             Модерирование файлов

         </div> 

 ';

 include_once ROOT.'/template/footer.php';

?>