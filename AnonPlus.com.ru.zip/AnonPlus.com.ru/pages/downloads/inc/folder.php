<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 
 ## $user['level'] = 3; Модератор файлов

 $folder_id = (int) abs ($_GET['folder']);

 $queryFolder = $DB -> query ("SELECT * FROM `downloads_folder` WHERE `id` = '".$folder_id."'");

 if ($queryFolder -> RowCount () < 1) Core::redirect ("Папка не существует!", HTTP."/files");
 $f = $queryFolder -> fetch ();

 $back = ($f['folder_id'] > 0) ? $DB -> query ("SELECT `id`, `name` FROM `downloads_folder` WHERE `id` = '".$f['folder_id']."'") -> fetch () : NULL;

 $queryFolders = $DB -> query ("SELECT * FROM `downloads_folder` WHERE `folder_id` = '".$f['id']."'");

 $c_p = $DB -> query ("SELECT * FROM `downloads_files` WHERE `folder_id` = '".$f['id']."'") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryFiles = $DB -> query ("SELECT * FROM `downloads_files` WHERE `folder_id` = '".$f['id']."' ORDER BY `time` DESC LIMIT $start, ".$p_page."");

 $description = 'Фото, видео, музыка, 18+';
 $title = 'Файлы';
 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/files">

                 Файлы

             </a>

             '.($f['folder_id'] > 0 ? '<span class = "ico next"></span><a href = "'.HTTP.'/files/?folder='.$back['id'].'">'.$back['name'].'</a>' : '').'

             <span class = "ico next"></span>

             '.$f['name'].'

         </div> 

 ';

 while ($folder = $queryFolders -> fetch ()) {

     echo '

         <a class = "home" href = "'.HTTP.'/files/?folder='.$folder['id'].'">

             <img src = "'.HTTP.'/files/system.images/site.icons/folder.png"> '.$folder['name'].'

             <span class = "count_web">

                 <small>

                     '.$folder['count'].'

                 </small>

             </span>

         </a>

     ';

 }

 while ($file = $queryFiles -> fetch ()) {

     $sql_where = ($file['type'] == 'files') ? 'files' : 'pictures';
     $data = $DB -> query ("SELECT * FROM `".$sql_where."` WHERE `id` = '".$file['file_id']."'") -> fetch ();

     echo '

         <div>

             <a href="'.HTTP.'/uid'.$data['user_id'].'/'.$sql_where.'/?folder='.$data['folder_id'].'&'.($file['type'] == 'files' ? 'file' : 'pic').'='.$data['id'].'" class="list-link">
                
                 <div class="list-link__text">

                     '.(($file['type'] == 'pictures' or ($data['type'] == 'jpg' or $data['type'] == 'jpeg' or $data['type'] == 'png' or $data['type'] == 'gif' or $data['type'] == 'bmp')) ? '<div id = "avatar"><img src = "'.HTTP.'/files/user.files/pictures/128/photo'.$data['id'].'_'.$data['key_name_file'].'.'.$data['type'].'"></div>' : '').'

                     '.files_methods::typeFile ($data['type']).' <b>'.$data['name'].'</b>.'.$data['type'].'

                     '.($data['consored'] == 1 ? '<img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/adult_ico.png">' : '').'

                     <span id = "right" class = "private_info">

                         '.files_methods::filesize_get (ROOT.'/files/user.files/'.files_methods::dir_name ($data['type']).'/'.(files_methods::dir_name ($data['type']) == 'pictures' ? 'photo' : 'file').''.$data['id'].'_'.$data['key_name_file'].'.'.$data['type']).'

                     </span>

                     <br />

                     <span class="private_info">

                         '.Core::CropStr ($data['description'], 100).'

                     </span>

                     '.(empty ($data['description']) ? '' : '<br />').'

                     <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/view.png">

                     <span class = "private_info">

                         '.($file['type'] == 'files' ? $data['download'] : $data['view']).'

                     </span>

                 </div>
 
             </a>

         </div>

     ';


 }

 if ($k_page > 1) Core::str(''.HTTP.'/files/?folder='.$f['id'].'&', $k_page, $page);

 if ($user['level'] == 1) {

    echo '
         <a class = "home-f" href = "'.HTTP.'/files/?new_folder&folder='.$f['id'].'">

             Создать папку

         </a>
    ';

 }

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/files">

                 Файлы

             </a>  
             
             '.($f['folder_id'] > 0 ? '<span class = "ico next"></span><a href = "'.HTTP.'/files/?folder='.$back['id'].'">'.$back['name'].'</a>' : '').'

             <span class = "ico next"></span>

             '.$f['name'].'

         </div> 

 ';

 include_once ROOT.'/template/footer.php';

?>