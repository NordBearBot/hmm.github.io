<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $folder_id = (int) (isset ($_GET['folder']) ? abs ($_GET['folder']) : 0);

 if ($folder_id > 0) {

    $queryFolder = $DB -> query ("SELECT `id`, `name`, `type` FROM `downloads_folder` WHERE `id` = '".$folder_id."'");

    if ($queryFolder -> RowCount () < 1) Core::redirect ("Неизвестная ошибка!", HTTP."/files");
    $folder = $queryFolder -> fetch ();

    $title_url = '<span class = "ico next"></span> <a href = "'.HTTP.'/files/?folder='.$folder['id'].'">'.$folder['name'].'</a>';

 }

 $folder_url = ($folder_id > 0 ? 'folder='.$folder_id : '');

 if (isset ($_POST['add'])) {

     $name_folder = (string) Core::check ($_POST['name_folder']);
     $CK = (int) abs ($_POST['CK']);

     if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/files/?new_folder&".$folder_url);

     $err = (empty ($name_folder) ? '<div class = "err">Введите название папки!</div>' : (Core::utf_strlen ($name_folder) > 30 ? '<div class = "err">Имя папки не должно превышать 30 символов!</div>' : NULL));
 
     if (empty ($err)) {

         $type = (int) abs ($_POST['type']);
         $type = ($type > 5) ? 0 : $type;

         $type_txt = ($type == 0 ? 'picture' : ($type == 1 ? 'video' : ($type == 2 ? 'music' : ($type == 3 ? 'game' : ($type == 4 ? 'program' : ($type == 5 ? 'other' :'other'))))));
         $type_txt = ($folder_id > 0) ? $folder['type'] : $type_txt;

         $DB -> query ("INSERT INTO `downloads_folder` SET `name` = ".$DB -> quote ($name_folder).", `folder_id` = '".$folder_id."', `type` = '".$type_txt."', `time` = '".time ()."', `author` = '".$user['id']."'");

         Core::redirect_ok ("Папка создана!", HTTP."/files/?".$folder_url);

     }

 }

 $title = 'Файлы / Новая папка';
 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/files">

                 Файлы

             </a>

             '.$title_url.'

             <span class = "ico next"></span>

             Новая папка

         </div>

         '.Core::Error ().'

         '.$err.'
         
         <div class = "block">

             <form action = "" method = "POST">

                 Название папки:

                 <br />

                 <input type = "text" name = "name_folder">

                 <br />

                 ';

                 if ($folder_id < 1) {

                 echo '

                 Тип: <br />
         
                 <input type="radio" name="type" value="0" checked="checked" /> Картинки <br />
         
                 <input type="radio" name="type" value="1" /> Видео <br />

                 <input type="radio" name="type" value="2" /> Музыка <br />

                 <input type="radio" name="type" value="3" /> Игры <br />

                 <input type="radio" name="type" value="4" /> Программы <br />

                 <input type="radio" name="type" value="5" /> Разное <br />

                 ';

                 } 

                 echo '

                 <input type = "submit" name = "add" value = "Добавить">

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

             </form>

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/files">

                 Файлы

             </a>

             '.$title_url.'

             <span class = "ico next"></span>

             Новая папка

         </div> 

 ';

 include_once ROOT.'/template/footer.php';

?>