<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 ## Доступ только для авторизированых
 Core::CheckUser ();

 $folder_id = intval (abs ($_GET['folder']));

 ## Если нажали кнопку
 if (isset($_POST['upload'])) { 
     
    ## Подгружаем класс для обработки изображения
    $image = new image(); 

    $queryFolder = $DB -> query ("SELECT `id`, `access` FROM `pictures_folder` WHERE `user_id` = '".$user['id']."' AND `id` = '".$folder_id."'");

    if ($queryFolder -> RowCount () < 1) $folder_id = 0;
    $f = $queryFolder -> fetch ();

    ## Проверяем CK
    if (isset($_POST['CK']) && Core::check ($_POST['CK']) == $user['CK']) {
         
        ## Конфигурация размерор фото
        $max_image_width = 1400; 
        $max_image_height = 900; 
        $min_image_width = 100; 
        $min_image_height = 100; 

        ## Только если файл выбран
        if (!empty($_FILES['file']['name'])) {      
    
            ## Выводим тип файла    
            $type = strtolower(substr(strrchr($_FILES['file']['name'], '.'), 1));
    
            ## Выводим типы которые можно загружать 
            $photo = array('gif', 'jpg', 'jpeg', 'png');

            ## Проверяем тип файла
            if (in_array($type, $photo)) {
            
            ## Получаем информацию о файле
            $info = getimagesize($_FILES['file']['tmp_name']); 
            $width= $info[0]; 
            $height= $info[1]; 

            ## Проверяем размер фото в px
            if ($width > $min_image_width and $height > $min_image_height) {
            if ($width < $max_image_width and $height < $max_image_height) {

            ## Проверяем размер файла
            if ($_FILES['file']['size'] < 5000000) {   
    
            ## Обработка названия
            $name = substr(strstr(Core::check($_FILES['file']['name']), ".", true), 0, 49);  

            ##Обработка описания
            $description = Core::check($_POST['description']);

            ## Обработка содержимого на метку 18+
            $censored = (empty($_POST['censored'])) ? 0 : 1;    

            ## Обработка количества символов названия
            if (Core::utf_strlen($name) > 0 && Core::utf_strlen($name) < 50) {   

                 ## Обработка количества символов описания
                 if (Core::utf_strlen($description) < 10000) {

                     ## Проверяем имя фото
                     $photo = $DB -> query("SELECT `id` FROM `pictures` WHERE `name`= ".$DB -> quote ($name)." AND `user_id`= '".$user['id']."'");

                     ## Только если имя свободно 
                     if ($photo -> RowCount () < 1) {    

                         ## Генерируем ключ
                         $key = rand(1000000000, 10000000000);
    
                         ## Добавляем фото в базу
                         $add = $DB -> query ("INSERT INTO `pictures` SET
                                            `name` = ".$DB -> quote ($name).",
                                            `description` = ".$DB -> quote ($description).",
                                            `consored` = '".$censored."',
                                            `user_id` = '".$user['id']."',
                                            `time` = '".time ()."',
                                            `key_name_file` = '".$key."',
                                            `type` = ".$DB -> quote ($type).",
                                            `folder_id` = '".$folder_id."'");

                         ## Обновляем количество фотографий в папке
                         if ($folder_id > 0) $updateCountPic = $DB -> query ("UPDATE `pictures_folder` SET `count` = `count`+1 WHERE `id` = '".$folder_id."'");

                         ## Получаем id фотографии
                         $idPicture = $DB -> query ("SELECT `id` FROM `pictures` WHERE `user_id` = '".$user['id']."' ORDER BY `id` DESC LIMIT 1") -> fetch ();
                         $id = $idPicture['id'];

                         $full_path = ROOT.'/files/user.files/pictures/photo'.$id.'_'.$key.'.'.$type;

                         $image -> load($_FILES['file']['tmp_name']);  
                         $image -> save($full_path);
                          
                         $image -> img_resize ($full_path, ROOT.'/files/user.files/pictures/40/photo'.$id.'_'.$key.'.'.$type, 40, 40);
                         $image -> img_resize ($full_path, ROOT.'/files/user.files/pictures/64/photo'.$id.'_'.$key.'.'.$type, 64, 64);
                         $image -> img_resize ($full_path, ROOT.'/files/user.files/pictures/128/photo'.$id.'_'.$key.'.'.$type, 128, 128);
                         $image -> img_resize ($full_path, ROOT.'/files/user.files/pictures/256/photo'.$id.'_'.$key.'.'.$type, 256, 256);
 
                         ## Делаем уведомление в ленту
                         if ($f['access'] != 2) Core::lenta ($user['id'], $id, '/files/user.files/pictures/64/photo'.$id.'_'.$key.'.'.$type.'', '/uid'.$user['id'].'/pictures/?folder='.$folder_id.'&pic='.$id.'', '2');

                         Core::redirect_ok ("Файл успешно загружен", HTTP."/uid".$user['id']."/pictures/?folder=".$folder_id."&pic=".$id."");

                    } else  Core::redirect ("У вас уже есть фото под именем ".$name."!", HTTP."/uid".$user['id']."/pictures/?upload&folder=".$folder_id."");
                } else Core::redirect ("Слишком длинное описание!", HTTP."/uid".$user['id']."/pictures/?upload&folder=".$folder_id."");
            } else Core::redirect ("Слишком длинное или короткое название файла!", HTTP."/uid".$user['id']."/pictures/?upload&folder=".$folder_id."");
        
         } else Core::redirect ("Выбранное вами фото имеет размер болие 5мб!", HTTP."/uid".$user['id']."/pictures/?upload&folder=".$folder_id."");
        
        } else Core::redirect ("Изображения должно быть не более ".$max_image_width."x".$max_image_height."px!", HTTP."/uid".$user['id']."/pictures/?upload&folder=".$folder_id."");

      } else Core::redirect ("Изображения должно быть не меньше ".$min_image_width."x".$min_image_height."px!", HTTP."/uid".$user['id']."/pictures/?upload&folder=".$folder_id."");

    } else Core::redirect ("Недопустимый тип файла!", HTTP."/uid".$user['id']."/pictures/?upload&folder=".$folder_id."");
    
} else Core::redirect ("Не выбран файл!", HTTP."/uid".$user['id']."/pictures/?upload&folder=".$folder_id."");

} else Core::redirect ("Не верный CK!", HTTP."/uid".$user['id']."/pictures/?upload&folder=".$folder_id."");

}







 $title = 'Фото пользователя '.$user['login'].' / Загрузка фотографии';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>

             <span class = "ico next"></span>
             <a href = "'.HTTP.'/uid'.$user['id'].'/pictures/">Фото</a>

         </div>

         <div class = "background_place">

             <div class = "main_place">

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                         Загрузка фотографии

                     </a>

                 </div>

 ';

 Core:: Error ();
 Core:: Ok ();

 echo '

                     <FORM ENCTYPE="multipart/form-data" method="POST">

                         <div class = "place">

                             <input type="hidden" name="CK" value="'.$user['CK'].'" />

                             <span class = "private_info">Размером <b>< 5 МБ</b></span>

                         </div>

                         <div class = "place" style = "padding-top: 0;">

                             <input name="file" type="file" accept="image/jpeg, image/png, image/gif"/>

                         </div>

                         <div class = "place" style = "padding-top: 0;">

                             <span class = "private_info">Описание <small><b>(10000 символов)</b></small></span>

                             <br />

                             <textarea name="description" class="textarea" /></textarea>

                         </div>


                         <div class = "place" style = "padding-top: 0;">

                             <input type="checkbox" class="middle" name="censored" value="1"/>

                             <span class = "private_info">

                                 <b>Файл для взрослых</b>

                             </span>

                             <font color = "red">

                                 (18+)

                             </font>

                         </div>

                         <div class = "place" style = "padding-top: 0;">

                             <input type="submit" name="upload" value="Загрузить" />

                         </div>

         </form>

         <div class = "nav">

             Загрузка может длиться 1-5 минут. 

         </div>

         </div>

         </div>
 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>

             <span class = "ico next"></span>
             <a href = "'.HTTP.'/uid'.$user['id'].'/pictures/">Фото</a>

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>