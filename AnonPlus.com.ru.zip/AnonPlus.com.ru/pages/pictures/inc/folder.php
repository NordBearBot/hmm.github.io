<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $queryF = $DB -> query ("SELECT `id`, `user_id`, `name`, `access` FROM `pictures_folder` WHERE `id` = '".intval ( abs ($_GET['folder']))."' AND `user_id` = '".intval (abs ($_GET['id']))."'");

 if ($queryF -> RowCount () < 1) {

    if ($user) Core::redirect ("Папка не существует!", HTTP."/uid".$user['id']."/pictures/");
    else Core::redirect ("Папка не существует!", HTTP."/err/");

 }
 else $f = $queryF -> fetch ();
 $ank = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".$f['user_id']."'") -> fetch ();

 $queryAccessForler = $DB -> query ("SELECT `id` FROM `friends` WHERE `user_id` = '".$ank['id']."' AND `friend_id` = '".$user['id']."'");
 if ($f['access'] == 1 and $ank['id'] != $user['id'] and $queryAccessForler -> RowCount () < 1) Core::redirect ("Доступ к этой папке имеют только друзья пользователя!", HTTP."/uid".$ank['id']."/pictures/");
 if ($f['access'] == 2 and $user['id'] != $ank['id']) Core::redirect ("Доступ к этой папке закрыт автором!", HTTP."/uid".$ank['id']."/pictures/");

 $queryPicture = $DB -> query ("SELECT * FROM `pictures` WHERE `folder_id` = '".$f['id']."' AND `user_id` = '".$ank['id']."'");

 $edit_avatar = (isset ($_GET['edit_avatar'])) ? '&edit_avatar=1' : NULL;

 $edit_access = (isset ($edit_avatar)) ? 'AND `access` = 1' : '';

 $queryFolder = $DB -> query ("SELECT * FROM `pictures_folder` WHERE `folder_id` = '".$f['id']."' ".$edit_access." ");

 $description = 'Фото пользователя '.$ank['login'];
 $keywords = NULL;
 $title = 'Фото пользователя '.$ank['login'];

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>
             <a href = "'.HTTP.'/uid'.$ank['id'].'/pictures/?'.$edit_avatar.'">Фото</a>

         </div>

         <div class = "nav">

             '.$f['name'].'

         </div>

 ';

 Core:: Error ();
 Core:: Ok ();

 while ($folder = $queryFolder -> fetch ()) {

         echo '

             <a class = "home" href = "'.HTTP.'/uid'.$ank['id'].'/pictures/?folder='.$folder['id'].''.$edit_avatar.'">

                 '.($folder['access'] == 0 ? '<img src="'.HTTP.'/files/system.images/folder.type/folder.gif" title="Доступен всем">' : '').'
                 '.($folder['access'] == 1 ? '<img src="'.HTTP.'/files/system.images/folder.type/dir_friends.png" title="Доступен друзьям">' : '').'
                 '.($folder['access'] == 2 ? '<img src="'.HTTP.'/files/system.images/folder.type/dir_locked.png" title="Доступен автору">' : '').'

                 '.$folder['name'].'

                 <span class = "count">

                     '.$folder['count'].'

                 </span>

             </a>

         ';


 }

 if ($queryPicture -> RowCount () > 0) echo '<div class = "pictures_content">';

 while ($picture = $queryPicture -> fetch ()) {

         echo '
             
             <div class = "pic_two">

                 <div class = "picture_solid">

                     <div class = "pic">

                         <a href = "'.HTTP.''.(isset ($_GET['edit_avatar']) ? '/edit/avatar/?pic='.$picture['id'].'&folder='.$picture['folder_id'].'&CK='.$user['CK'].'' : '/uid'.$ank['id'].'/pictures/?folder='.$picture['folder_id'].'&pic='.$picture['id'].'').'">

                             <img src = "'.HTTP.'/files/user.files/pictures/128/photo'.$picture['id'].'_'.$picture['key_name_file'].'.'.$picture['type'].'">

                         </a>

                     </div>

                 </div>

                 <br />

                 <span class = "info_pic">

                     <img src = "'.HTTP.'/files/system.images/site.icons/view.png"> '.$picture['view'].'

                     '.($picture['consored'] == 1 ? '<img src = "'.HTTP.'/files/system.images/site.icons/adult_ico.png">' : '').'

                 </span>

             </div>

         ';


 }

 if ($queryPicture -> RowCount () > 0) echo '</div>';

 if ($queryPicture -> RowCount () == 0 and $queryFolder -> RowCount () == 0) echo '<div class = "block">Фотографий нет</div>';

 if ($user && $user['id'] == $ank['id'] && !isset ($edit_avatar)) {

     $queryMaxFolder = $DB -> query ("SELECT `id` FROM `pictures_folder` WHERE `folder_id` = '".$f['id']."'");

    echo '

         <div class = "block" style = "border: none;"></div>

         <a class="nav_part" href = "'.HTTP.'/uid'.$user['id'].'/pictures/?upload&folder='.$f['id'].'" style = "text-align: left;">

             <img src = "'.HTTP.'/files/system.images/site.icons/download.png">

             Загрузить фото

         </a>

    ';
    
     if ($queryMaxFolder -> RowCount () < 16) {

        echo '
         <a class="nav_part" href = "'.HTTP.'/uid'.$user['id'].'/pictures/?new_folder&folder='.$f['id'].'" style = "text-align: left;">

             <img src = "'.HTTP.'/files/system.images/site.icons/add_folder.png">

             Создать папку

         </a>
         ';
     }

}

 echo '
         <div class = "nav">

             '.$f['name'].'

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>
             <a href = "'.HTTP.'/uid'.$ank['id'].'/pictures/?'.$edit_avatar.'">Фото</a>

         </div>

 ';

 include_once ROOT.'/template/footer.php';

?>