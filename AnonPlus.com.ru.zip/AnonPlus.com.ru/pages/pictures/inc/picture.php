<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $queryPicture = $DB -> query ("SELECT * FROM `pictures` WHERE `folder_id` = '".intval ( abs ($_GET['folder']))."' AND `id` = '".intval ( abs ($_GET['pic']))."' AND `user_id` = '".intval (abs ($_GET['id']))."' LIMIT 1");

 if ($queryPicture -> RowCount () < 1) {

    if ($user) Core::redirect ("Файл не существует!", HTTP."/uid".$user['id']."/pictures/");
    else Core::redirect ("Файл не существует!", HTTP."/err/");

 }
 else $pic = $queryPicture -> fetch ();

 $ank = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".$pic['user_id']."'") -> fetch ();

 $queryTest = $DB -> query ("SELECT `id` FROM `bookmarks` WHERE `user_id` = '".$user['id']."' AND `type` = '1' AND `object_id` = '".$pic['id']."'") -> RowCount ();
 $bookmarks = ($queryTest < 1) ? '<a href="'.HTTP.'/bookmarks/add/?type=1&id='.$pic['id'].'" class="adv_user_link" id="bookmark_link" title="Добавить в закладки"><span></span></a>' : '<a href="'.HTTP.'/bookmarks/delete/?type=1&id='.$pic['id'].'" class="adv_user_link" id="bookmark_link" title="Удалить из закладок"><span style="background-position: -32px -16px; !important;"></span></a>';
 
 $queryDownload = $DB -> query ("SELECT `id`, `folder_id` FROM `downloads_files` WHERE `file_id` = '".$pic['id']."' AND `type` = 'pictures'");
 $toDownload = ($queryDownload -> RowCount () < 1) ? '<a href="'.HTTP.'/files/?add&pic='.$pic['id'].'" class="adv_user_link" id="toZO_link" title="В файлообменник"><span></span></a>' : '';
 
 if ($queryDownload -> RowCount () > 0) {

     $d_file = $queryDownload -> fetch ();
     $d_folder = $DB -> query ("SELECT `id`, `name`, `folder_id` FROM `downloads_folder` WHERE `id` = '".$d_file['folder_id']."'") -> fetch ();
     $d_folder2 = $DB -> query ("SELECT `id`, `name`, `folder_id` FROM `downloads_folder` WHERE `id` = '".$d_folder['folder_id']."'") -> fetch ();
     $d_folder3 = $DB -> query ("SELECT `id`, `name`, `folder_id` FROM `downloads_folder` WHERE `id` = '".$d_folder2['folder_id']."'") -> fetch ();   
     $d_folder4 = $DB -> query ("SELECT `id`, `name`, `folder_id` FROM `downloads_folder` WHERE `id` = '".$d_folder3['folder_id']."'") -> fetch ();

     $down_folder = '<br /> <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/sz.png"> <a href = "'.HTTP.'/files/?folder='.$d_folder['id'].'" class = "private_info">Файлообменник / '.$d_folder4['name'].' '.(!empty ($d_folder4['id']) ? '/' : '').' '.$d_folder3['name'].' '.(!empty ($d_folder3['id']) ? '/' : '').' '.$d_folder2['name'].' / '.$d_folder['name'].'</a>';

 }

 $folder = $DB -> query ("SELECT `name`, `id`, `access` FROM `pictures_folder` WHERE `id` = '".$pic['folder_id']."'") -> fetch ();

 $queryAccessForler = $DB -> query ("SELECT `id` FROM `friends` WHERE `user_id` = '".$ank['id']."' AND `friend_id` = '".$user['id']."'");
 if ($folder['access'] == 1 and $ank['id'] != $user['id'] and $queryAccessForler -> RowCount () < 1) Core::redirect ("Доступ к этой папке имеют только друзья пользователя!", HTTP."/uid".$ank['id']."/pictures/");

 if ($folder['access'] == 2 and $user['id'] != $ank['id']) Core::redirect ("Доступ к этой папке закрыт автором!", HTTP."/uid".$ank['id']."/pictures/");
  
 ##  Обрабатываем просмотр

 if ($user) {

     $testView = $DB -> query ("SELECT `id` FROM `count_view` WHERE `type` = 'picture' and `user_id` = '".$user['id']."' and `object_id` = '".$pic['id']."'") -> RowCount ();

     if ($testView == 0) {

         Core::count_view ('picture', $pic['id']);

         $DB -> query ("UPDATE `pictures` SET `view` = `view`+1 WHERE `id` = '".$pic['id']."'");

         header ('Location: '.HTTP.'/uid'.$ank['id'].'/pictures/?folder='.$folder['id'].'&pic='.$pic['id']);

     }

 }

 if ($user and isset ($_GET['journal'])) User::journal_update ($_GET['journal'], $user['id']);

 ## Полное название файла
 $picName = $pic['name'].$pic['type'];

 ## Пагинация для комментариев
 $c_p = $DB -> query ("SELECT * FROM `pictures_comments` WHERE `pic_id` = '".$pic['id']."'") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryComments = $DB -> query ("SELECT * FROM `pictures_comments` WHERE `pic_id` = '".$pic['id']."' ORDER BY `id` DESC LIMIT $start, ".$p_page."");
 $queryCommentsFix = $DB -> query ("SELECT * FROM `pictures_comments` WHERE `pic_id` = '".$pic['id']."'") -> RowCount ();

 if (isset ($_POST['comment'])) {

     Core::CheckUser ();

     $message = Core::check ($_POST['message']);
     $CK = (int) abs ($_POST['CK']);

     if ($CK == $user['CK']) {

         if (empty ($message)) $err = '<div class = "err">Введите комментарий!</div>';
         else {

             if (strlen($message) > 3000) $err = '<div class = "err">Комментарий не должен превышать 3000 символов!</div>';
             else {

                 $queryAddComment = $DB -> query ("INSERT INTO `pictures_comments` SET
                                                  `pic_id` = '".$pic['id']."',
                                                  `user_id` = '".$user['id']."',
                                                  `reply_id` = '0',
                                                  `message` = ".$DB -> quote ($message).",
                                                  `time` = '".time ()."'");

                 if ($user['id'] != $ank['id']) User::journal_add ($user['id'], $ank['id'], $message, 2, '/uid'.$ank['id'].'/pictures/?folder='.$folder['id'].'&pic='.$pic['id'].'');

                 header ('Location: '.HTTP.'/uid'.$ank['id'].'/pictures/?folder='.$folder['id'].'&pic='.$pic['id'].'');

             }

         }
     
     }
     else Core::redirect ("Не верный CK!", HTTP."/uid".$ank['id']."/pictures/?folder=".$folder['id']."&pic=".$pic['id']."");

 }

 $description = 'Фото пользователя '.$ank['login'].' / '.$picName;
 $keywords = NULL;
 $title = 'Фото пользователя '.$ank['login'].' / '.$picName;

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>
             <a href = "'.HTTP.'/uid'.$ank['id'].'/pictures/">Фото</a>

             '.(!empty ($folder) ? '<span class = "ico next"></span> <a href = "'.HTTP.'/uid'.$ank['id'].'/pictures/?folder='.$folder['id'].'">'.$folder['name'].'</a>' : '').'

         </div>

 ';

 Core:: Error ();
 Core:: Ok ();

 echo '
         <div class = "background_place">

             <div class = "main_place">

             <div class = "place">

             '.files_methods::typeFile ($pic['type']).' 

             <span class = "private_info">

                 <b>'.$pic['name'].'</b>.'.$pic['type'].'

             </span>

             '.($pic['consored'] == 1 ? '<img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/adult_ico.png">' : '').'

             <br />

             <span class = "transform_pic">

                 <img src = "'.HTTP.'/files/user.files/pictures/256/photo'.$pic['id'].'_'.$pic['key_name_file'].'.'.$pic['type'].'">

             </span>

         </div>

         <a class = "home-f" style = "border-top: 1px solid #eee;" href = "'.HTTP.'/files/user.files/pictures/photo'.$pic['id'].'_'.$pic['key_name_file'].'.'.$pic['type'].'">

             <img src = "'.HTTP.'/files/system.images/site.icons/load.gif">

             Скачать

             <small>

                 ('.files_methods::filesize_get (ROOT.'/files/user.files/pictures/photo'.$pic['id'].'_'.$pic['key_name_file'].'.'.$pic['type']).')

             </small>

         </a>

         <div class = "place user_info">

             Просмотров <span class = "count_web">'.$pic['view'].'</span>

             <br />

             Файл добавлен: '.Core::user ($ank['id'], 0, 1, 1).' ('.Core::date_time ($pic['time']).')

             <br />

             '.($folder['id'] == 0 ? '<img id = "menu_list" src = "'.HTTP.'/files/system.images/folder.type/folder.gif"> <a class = "private_info" href = "'.HTTP.'/uid'.$ank['id'].'/pictures/">Фото</a>' : '<img src = "'.HTTP.'/files/system.images/folder.type/folder.gif"> <a class = "private_info" href = "'.HTTP.'/uid'.$ank['id'].'/pictures/?folder='.$folder['id'].'">'.$folder['name'].'</a>').'

             '.$down_folder.'

         </div>

         '.(($user['level'] == 1 or $user['level'] == 3) ? '<a style = "border-top: 1px solid #eee;" class = "home" href = "'.HTTP.'/files/?ban_file='.$pic['id'].'">Бан</a>' : '').'

         <div class = "block" style = "padding: 15px; border-top: 1px solid #eee;">
 
             '.$bookmarks.'

             '.(($user['id'] == $pic['user_id'] and $folder['access'] == 0) ? $toDownload : '').'

         </div>

         </div>


         <div class = "main_place">

 ';

 if ($queryComments -> RowCount () < 1) {

     echo '

         <div class="b-title b-title_first">

             <a class="b-title__link">

                     Комментарии

             </a>

         </div>

         <div class = "place">

             Комментарии отсуствуют

         </div>

     ';

 }
 else {

     echo '

         <div class="b-title b-title_first">

             <a class="b-title__link">

                     Комментариев <span class = "count_web">'.$queryCommentsFix.'</span>

             </a>

         </div>

     ';

     while ($comment = $queryComments -> fetch ()) {

         echo '

         <div class = "place" style = "border-bottom: 1px solid #eee;">

             <div id = "avatar">

                 '.Core::avatar ($comment['user_id'], 40).'

             </div>

             <div id = "content">

                 '.Core::user ($comment['user_id'], 1, 1, 1).'

                 <small id = "right">

                     '.Core::date_time ($comment['time']).'

                 </small>

                 <br />

                 '.Core::bb ($comment['message']).'

             </div>

         </div>

         ';

     }

 if ($k_page > 1) Core::str(''.HTTP.'/uid'.$ank['id'].'/pictures/?folder='.$folder['id'].'&pic='.$pic['id'].'&', $k_page, $page);

 }

 echo '

         '.$err.'

         <div class = "nav">

             <form action = "" method = "POST">

                 <textarea name="message"  placeholder = "Оставить комментарий...">'.(isset ($_POST['comment']) ? $message : '').'</textarea>

                 <br />

                 <input type = "submit" name = "comment" value = "Написать"/>

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

             </form>

         </div>

 ';

 echo '
         </div>

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>
             <a href = "'.HTTP.'/uid'.$ank['id'].'/pictures/">Фото</a>

             '.(!empty ($folder) ? '<span class = "ico next"></span> <a href = "'.HTTP.'/uid'.$ank['id'].'/pictures/?folder='.$folder['id'].'">'.$folder['name'].'</a>' : '').'

         </div>

 ';

 include_once ROOT.'/template/footer.php';

?>