<?php 
 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();
 if ($user['id'] != $_GET['id']) header ('Location:'.HTTP.'/uid'.$user['id'].'/pictures/?blocks');

 $file_id = (int) abs ($_GET['pic']);
 $queryFile = $DB -> query ("SELECT * FROM `block_files` WHERE `user_id` = '".$user['id']."' AND `file_type` = 'pictures' AND `id` = '".$file_id."'");

 if ($queryFile -> RowCount () < 1) Core::redirect ("Файл не существует!", HTTP."/uid".$user['id']."/pictures/?blocks");
 $file = $queryFile -> fetch ();

 $vote = $DB -> query ("SELECT `moder_id` FROM `user_ban_list` WHERE `type` = 'ban_file' AND `object_id` = '".$file['id']."'") -> fetch ();

 $title = $user['login'] .' / Фото / Заблокированные / '.$file['file_name'].'.'.$file['file_type_name'];

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/pictures">

                 Фото

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/pictures/?blocks">

                 Заблокированные

             </a>

         </div>
 ';

 Core:: Error ();
 Core:: Ok ();

 echo '

          <div class = "background_place">

             <div class = "main_place">

                 <div class = "place user_info private_info" style = "border-bottom: 1px solid #eee;">

                     '.files_methods::typeFile ($file['file_type_name']).' <b>'.$file['file_name'].'</b>.'.$file['file_type_name'].'

                     <br />

                     '.(!empty ($file['file_description']) ? $file['file_description'].' </br>' : '').'

                     Загружен: '.Core::date_time ($file['add_file']).'

                 </div>

                 <div class = "place user_info private_info">

                     Заблокирован модератором: '.Core::user ($vote['moder_id'], 1, 1, 1).'

                     <br />

                     Дата: '.Core::date_time ($file['ban_file']).'

                 </div>

             </div>

         </div>
 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/pictures">

                 Фото

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/pictures/?blocks">

                 Заблокированные

             </a>

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>