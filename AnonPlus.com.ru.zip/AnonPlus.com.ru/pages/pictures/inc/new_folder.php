<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 ## Доступ только для авторизированых
 Core::CheckUser (); 

 $folder_id = (int) abs ($_GET['folder']);

 ## Проверяем пренадлежит ли папка юзеру в которой он создаёт папку
 if ($folder_id > 0) {

     $testFolder = $DB -> query ("SELECT `id`, `name`, `access` FROM `pictures_folder` WHERE `id` = '".$folder_id."' and `user_id` = '".$user['id']."'");
             
     ## Если это не автора папки, то грузим папку в корень папки Фото
     if ($testFolder -> RowCount () < 1) Core::redirect ("Нельзя создать папку в чужой папке!", HTTP."/uid".$user['id']."/pictures/");

     $data = $testFolder -> fetch ();

 }

 $queryMaxFolder = $DB -> query ("SELECT `id` FROM `pictures_folder` ".($folder_id > 0 ? "WHERE `folder_id` = '".$data['id']."'" : "WHERE `id` = '0'")."");
 if ($queryMaxFolder -> RowCount () > 15) Core::redirect ("В папке может быть максимум 16 папок!", HTTP."/uid".$user['id']."/pictures/?folder=".($folder_id > 0 ? $data['id'] : $folder_id));

 ## Если нажата кнопка
 if (isset ($_POST['save'])) {

    ## Обрабатываем данные
    $name_folder = Core::check ($_POST['name_folder']);
    $access = intval (abs ($_POST['access']));
    $access = (isset ($data['access']) ? $data['access'] : ($access > 2 ? 0 : $access));
    $CK = (isset ($_POST['CK'])) ? Core::Check ($_POST['CK']) : NULL;

    ## Пооверяем CK
    if (isset ($CK) and $CK == $user['CK']) {

         ## Проверяем на пустоту название папки
         if (empty ($name_folder)) Core::redirect ("Введите название папки!", HTTP."/uid".$user['id']."/pictures/?new_folder&folder=".$folder_id."");

         ## Проверяем количество символов в названии папки
         if (strlen ($name_folder)<1 || strlen ($name_folder)>30) Core::redirect ("Название папки должно содержать не больше 30 символов!", HTTP."/uid".$user['id']."/pictures/?new_folder&folder_id=".$_GET['id']."");

         ## Зановим данные в БД
         $SaveNewFolder = $DB -> query ("INSERT INTO `pictures_folder` SET 
                                        `user_id` = '".$user['id']."',
                                        `folder_id` = '".$folder_id."',
                                        `access` = '".$access."',
                                        `name` = ".$DB -> quote ($name_folder)."");

         ## Редиректим в Фото
         Core::redirect_ok ("Папка создана", HTTP."/uid".$user['id']."/pictures/".($folder_id != 0 ? "?folder=".$folder_id."" : "")."");

    }
    else Core::redirect ("Не верный CK!", HTTP."/uid".$user['id']."/pictures/?new_folder".($folder_id != 0 ? "&folder=".$folder_id."" : "")."");

 } 

 $description = 'Фото пользователя '.$ank['login'];
 $keywords = NULL;
 $title = 'Фото пользователя '.$ank['login'];

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>
             <a href = "'.HTTP.'/uid'.$user['id'].'/pictures/">Фото</a>

         </div>

         <div class = "nav">

             Новая папка

         </div>
 ';

 Core:: Error ();
 Core:: Ok ();

 echo '

         <div class = "block">

             <form action = "" method = "POST">

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

                 Имя папки <small>(30 символов)</small>

                 <br />

                 <input type = "text" name = "name_folder">

         </div>

         <div class = "block" style = "border: none;">

             Кто видит папку:

         </div>

 ';

 if ($folder_id > 0 and $data['access'] > 0) {

     echo '<div class = "block"><b>'.($data['access'] == 1 ? 'Мои друзья' : 'Только Я').'</b></div>';

 }
 else {
     
     echo '

         <div>
             
             <label for="access_link" class="block_touch">

                 <input type="radio" name="access" id="access_link" value="0" checked="checked" />

                 <img src = "http://vizaire.letspy.ru/files/system.images/status.data/access_all.png"> &nbsp;Все

             </label>

         </div>

         <div>
             
             <label for="access_link2" class="block_touch">

                 <input type="radio" name="access" id="access_link2" value="1"  />

                 <img src = "http://vizaire.letspy.ru/files/system.images/status.data/access_friends.png"> &nbsp;Мои друзья

             </label>

         </div>

         <div>
             
             <label for="access_link3" class="block_touch">

                 <input type="radio" name="access" id="access_link3" value="2"  />

                 <img src = "http://vizaire.letspy.ru/files/system.images/status.data/access_me.png"> &nbsp;Только Я

             </label>

         </div>
     ';

}

 echo '
         <div class = "block">

             <input type = "submit" name = "save" value = "Создать">

         </div>

         </form>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>
             Фото

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>