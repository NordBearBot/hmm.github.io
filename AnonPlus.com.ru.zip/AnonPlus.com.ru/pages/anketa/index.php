<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $queryUser = $DB -> query ("SELECT * FROM `users` WHERE `id` = '".intval( abs ($_GET['id']))."'");

 if ($queryUser -> RowCount () < 1) Core::redirect ("Пользователь не существует!", HTTP."/people/");

 $ank = $queryUser -> fetch ();

 $info = $DB -> query ("SELECT * FROM `user_anketa` WHERE `user_id` = '".$ank['id']."'") -> fetch ();
 
 $countRemarks = $DB -> query ("SELECT `id` FROM `user_ban_list` WHERE `user_id` = '".$ank['id']."'") -> RowCount ();

 $l = (!empty ($info['name']) and !empty ($info['age'])) ? ', ' : NULL;
 $l2 = (!empty ($info['name']) and !empty ($info['city']) and empty ($info['age'])) ? ', ' : NULL;
 $l3 = (!empty ($info['age']) and !empty ($info['city'])) ? ', ' : NULL;
 $information = $info['name'].''.$l.''.$l2.''.$info['age'] = (!empty ($info['age']) ? $info['age'].' лет' : '').''.$l3.''.$info['city'];
 
 $editWelcome = ($user['id'] == $ank['id'] and $user) ? '<a id = "right" href = "'.HTTP.'/edit/welcome/"><img src = "'.HTTP.'/files/system.images/site.icons/status.png" alt = "Редактировать приветствие"></a>' : NULL;
 
 include_once ROOT.'/pages/mysite/inc/access_blog.php';

 $description = $ank['login'].' / Анкета';
 $keywords = NULL;
 $title = $ank['login'].' / Анкета';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             Анкета

         </div>
 ';

 Core:: Ok ();
 Core:: Error ();

 if ($user['level'] > 0) echo '<a class = "home box" href = "'.HTTP.'/uid'.$ank['id'].'/remarks">Нарушения <span class = "count_web">'.$countRemarks.'</span></a>';

 echo '
         <div class = "background_place">

             <div class = "main_place">

             <div class = "place">

                 <div id = "avatar">

                     '.Core::avatar ($ank['id'], 64).'

                 </div>

                 <div id = "content">

                     <div class = "user_info">

                         '.Core::user ($ank['id'], 1, 1, 0).'

                         <span class = "count_web">

                             <small>

                                 '.Core::UserRating($ank['rating']).'
 
                             </small>
                             
                         </span>

                         <br />

                         <small>

                             '.$info['name'].'

                             '.((!empty ($info['name']) and empty($info['age'])) ? '<br />' : '').'
                             
                             '.((!empty ($info['name']) and !empty($info['age'])) ? '<br />' : '').'

                             <span class = "private_info">

                                 '.$info['age'].'

                                 '.(!empty ($info['age']) ? '<br />' : '').'

                                 '.Core::userSite ($ank['data_registration']).'

                             </span>

                             '.((empty ($info['age']) and empty ($info['name'])) ? '<p>' : '').'              

                         </small>

                     </div>

                 </div>

                 <div>

                     <span id = "top_v"></span>

                     <div class = "status">

                         '.$ank['welcome'].' 

                         '.$editWelcome.'

                     </div>

                 </div>

             </div>

 ';

 if ($user and $user['id'] == $ank['id']) {

        echo '

         <div class = "block" style = "padding: 0; border: none;">

              <div class = "part">

                 <a class = "nav_part" href = "'.HTTP.'/uid'.$user['id'].'/services/"><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/edit_info.png"><span id = "nav_user_privat"> Редактировать</span></a>

              </div>

              <div class = "part">

                 <a class = "nav_part" href = "'.HTTP.'/settings/"><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/settings.png"><span id = "nav_user_privat"> Настройки</span></a>

              </div>

              <div class = "part">

                 <a class = "nav_part" href = "'.HTTP.'/logout/?CK='.$user['CK'].'"><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/exit.png"><span id = "nav_user_privat"> Выйти</span></a>

              </div>

         </div>
  
         '.$err.'

         <div class = "block" style = "border: none">

             <form action = "" method = "POST">
     
                 <textarea name="msg"  placeholder = "Напишите в свой блог..."></textarea> <br />

                 <input type = "hidden" name = "access" value = "'.$accessBlog.'" />

                     <a href="'.HTTP.'/access-settings/?blog=1'.($accessBlog > 0 ? '&access='.$accessBlog.'' : '').'" class="adv_user_link" id="'.$accessBlogView.'" title="Доступ к записе"><span></span></a>

                     <a href="" class="adv_user_link" id="file_link" title="Прикрепить файл"><span></span></a>

                 <input id = "right" type="submit" value="Написать" name = "new_diary">
 
             </form>

         </div>

';
         
 }
 else {

     echo '

         <div class = "block" style = "padding: 0; border: none; border-top: 1px solid #eee;">

              <div class = "part">

                 <a class = "nav_s" style = "border: none;" href = "'.HTTP.'/mail/?new&name='.$ank['login'].'"><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/new_message.png"> <span class = "private_info">Написать</span></a>

              </div>

              <div class = "part">

                 <'.(User::friend ($user['id'], $ank['id']) == true ? 'div' : 'a').' class = "nav_'.(User::friend ($user['id'], $ank['id']) == true ? 'm' : 's').'" '.(User::friend ($user['id'], $ank['id']) == true ? '' : 'href = "'.HTTP.'/uid'.$user['id'].'/friends/?add='.$ank['id'].'"').'><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/'.(User::friend ($user['id'], $ank['id']) == true ? 'ok.png' : 'add_friend.png').'"> <span class = "private_info">'.(User::friend ($user['id'], $ank['id']) == true ? 'Дружите' : 'Дружить').'</span></'.(User::friend ($user['id'], $ank['id']) == true ? 'div' : 'a').'>

              </div>

              <div class = "part">

                 <a class = "nav_s" style = "border: none;" href = "'.HTTP.'/uid'.$ank['id'].'/gifts/new"><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/message_out.png"> <span class = "private_info">Подарок</span></a>

              </div>

         </div>


     ';

 }

         echo '

         </div>

         ';

 $queryGifts = $DB -> query ("SELECT * FROM `user_gifts` WHERE `reply_id` = '".$ank['id']."' ORDER BY `time` DESC LIMIT 4");
   
 if ($queryGifts -> RowCount () > 0) {

     echo '

         <div class = "main_place">

             <div class="b-title b-title_first">

                 <a href = "'.HTTP.'/uid'.$ank['id'].'/gifts" class="b-title__link">

                     Подарки

                 </a>

             </div>

             <div class = "place">
             ';

     while ($gift = $queryGifts -> fetch ()) {

         $data = $DB -> query ("SELECT * FROM `gifts` WHERE `id` = '".$gift['gift_id']."'") -> fetch ();

         echo '

                 <a href = "'.HTTP.'/uid'.$ank['id'].'/gifts/id'.$gift['id'].'"><img src = "'.HTTP.'/files/gifts/40/'.$data['key'].'.'.$data['type'].'"></a>

         ';


     }

     echo '

             </div>

         </div>

     ';

 }

         echo '        

             <div class = "box">

             <div class = "block" style = "border: none;">


                 <div class = "part">

                     <a href = "'.HTTP.'/uid'.$ank['id'].'" class = "no_act act_l_b act_r_b">Профиль</a>

                 </div>

                 <div class = "part">

                     <a class = "act act_left">Анкета</a>

                     <span id = "t"></span>

                 </div>

                 <div class = "part">

                     <a href = "/" class = "no_act act_right">Новости</a>

                 </div>

             </div>

             <div class = "block" style = "border: none;">

                 <div class = "part" id = "box-text-c">

                     <small class = "private_info">

                         рейтинг

                     </small>

                     <br />

                     <b class = "ank_info">

                         '. Core:: UserRating ($ank['rating']).'

                     </b>

                 </div>

                 <div class = "part" id = "box-text-c">

                     <small class = "private_info">

                         статус

                     </small>

                     <br />

                     <b class = "ank_info">

                 ';
switch($ank['level']){
    case 1:
    echo "Администратор";
    break;
    case 2:
    echo "Модератор";
    break;
    case 3:
    echo "Модератор файлов";
    break;
    case 4:
    echo "Модератор форума";
    break;
    case 5:
    echo "Модератор чата";
    break;
    case -1:
    echo "Искусственный Интеллект";
    break;
    default:
    echo "Пользователь";
    break;
}
echo '
                     </b>

                 </div>

                 <div class = "part" id = "box-text-c">

                     <small class = "private_info">

                         ТОП

                     </small>

                     <br />

                     <b class = "ank_info">
                 ';
$result_b = $DB->query("SELECT DISTINCT(rating) FROM users ORDER BY rating desc");
$top_m = 1;
while( $top_f = $result_b -> fetch ()){
    if($top_f['rating'] != $ank['rating']){
        ++$top_m;
    }
    else{
        break;
    }
}
echo $top_m;
echo '
                     </b>

                 </div>

             </div>

         </div>

         <div class = "box" style = "margin-bottom: 15px;">

         <div class = "place user_info">

             <span class = "ank_text">Регистрация:</span> <span class = "text_b">'.Core::date_time ($ank['data_registration']).'</span>

             <br />

             <span class = "ank_text">Последний визит:</span> <span class = "text_b">'.Core::date_time ($ank['online']).'</span>

             <br />

             <span class = "ank_text">Время онлайн:</span> <span class = "text_b">'.Core::user_online_show($ank['online_time']).'</span>

         </div>

         '.($user['id'] == $ank['id'] ? '<a class = "home box" href = "'.HTTP.'/uid'.$ank['id'].'/remarks">Нарушения <span class = "count_web">'.$countRemarks.'</span></a>' : '').'

         </div>

         <div class = "box">

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 Основное

             </a>

         </div>

         <div class = "place user_info">

             <span class = "ank_text">Пол:</span> <span class = "text_b">'.($ank['sex'] == 0 ? 'Мужской' : 'Женский').'</span>

             '.($info['age'] != 0 ? '<br /> <span class = "ank_text">Дата рождения:</span> <span class = "text_b">'.$info['day'].'.'.$info['month'].'.'.$info['year'].'</span>' : '').'

         </div>

         </div>

         <div class = "box">

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 Знакомства

             </a>

         </div>

         <div class = "place user_info">

             <span class = "ank_text">Показывать в Знакомствах:</span> <span class = "text_b">'.($ank['dating'] == 1 ? 'Да' : 'Нет').'</span>

             '.($ank['userType'] != 3 ? '<br /> <span class = "ank_text">Ориентация:</span> <span class = "text_b">'.($ank['userType'] == 0 ? 'Гетеро' : ($ank['userType'] == 1 ? 'Гей' : ($ank['userType'] == 2 ? 'Лисби' : ''))).'</span>' : '').'
             
             '.(!empty ($info['partner']) ? '<br /> <span class = "ank_text">О желаемом партнере:</span> <span class = "text_b">'.$info['partner'].'</span>' : '').'

         </div>

         </div>

         <div class = "box">

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 Интересы

             </a>

         </div>

         <div class = "place user_info" style = "margin-bottom: 15px;">

             '.(!empty ($info['me']) ? '<span class = "ank_text">О себе:</span> <span class = "text_b">'.$info['me'].'</span>' : '').'

             '.(!empty ($info['interests']) ? '<br /><span class = "ank_text">Интересы:</span> <span class = "text_b">'.$info['interests'].'</span>' : '').'

             '.(!empty ($info['music']) ? '<br /><span class = "ank_text">Любимая музыка:</span> <span class = "text_b">'.$info['music'].'</span>' : '').'

             '.(((empty ($info['me']) and empty ($info['interests']) and empty ($unfo['music']))) ? 'Не заполнено...' : '').'

         </div>

         </div>

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             Анкета
             
         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>