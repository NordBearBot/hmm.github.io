﻿<?php

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/config.php';

 
 Core::CheckUser();

 $queryContact = $DB -> query ("SELECT * FROM `mail_contacts` WHERE `kto` = '".$user['id']."' AND `kogo` = ".Core::Int ($_GET['id'])."") -> RowCount ();
 $queryNew = $DB -> query ("UPDATE `mail_messages` SET `new` = '0' WHERE `kto` = '".intval(abs($user['id']))."' AND `komy` = '".intval(abs($_GET['id'])));
					 
 if ($queryContact < 1) {
 
     header ('Location: '.HTTP.'/my/mail/?err');
	 
 }

 $users = $DB -> query ("SELECT `login`, `id` FROM `users` WHERE `id` = '".Core::Int ($_GET['id'])."'") -> fetch ();

 $UpdateMail = $DB -> query ("UPDATE `mail_messages` SET `new` = '0' WHERE `komy` = '".$user['id']."' AND `kto` = '".$users['id']."'");

 $title = 'Почта';
 require_once $_SERVER['DOCUMENT_ROOT'].'/core/header.php';

  echo '

  <div class="location-bar" id="header_path">
      
      
        <a href="'.HTTP.'/?" class="location-bar__home-link ico"></a> <span class="location-bar__sep ico"></span>
      
        <a href = "'.HTTP.'/my/?name='.$user['login'].'">'.$user['login'].'</a> 

        <span class="location-bar__sep ico"></span>

        <a href = "'.HTTP.'/mail/">Почта</a>
      
 </div>

 ';

 echo '
 
 <div class = "block">'.Core::Icon ($users['id'], 0, 1, 1).'</div>

 ';

 $c_p = $DB -> query ('SELECT * FROM `mail_messages` WHERE (`kto` = "'.$user['id'].'" AND `komy` = "'.abs(intval($_GET['id'])).'") or (`kto` = "'.abs(intval($_GET['id'])).'" AND `komy` = "'.$user['id'].'" ) ORDER by `id` DESC') -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
        else $p_page = '7';
        $k_page = Core::k_page($c_p, $p_page);
        $page = Core::page($k_page);
        $start = $p_page*$page-$p_page;

 $query = $DB -> query('SELECT * FROM `mail_messages` WHERE (`kto` = "'.$user['id'].'" AND `komy` = "'.abs(intval($_GET['id'])).'") or (`kto` = "'.abs(intval($_GET['id'])).'" AND `komy` = "'.$user['id'].'" ) ORDER by `id` DESC LIMIT '.$start.', '.$p_page.'');
 
 if (isset ($_POST['go']) and isset ($_GET['go'])) {
 
     if ($user['wtf'] == $_GET['wtf']) {

     if (empty ($_POST['msg'])) {
	     echo '<div class = "err">Введите сообщение!</div>';
	 }
	 else {
                     $queryContact = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '".intval(abs($user['id']))."' AND `kogo` = '".intval(abs($_GET['id']))."'");
					 $queryContact2 = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '".intval(abs($_GET['id']))."' AND `kogo` = '".intval(abs($user['id']))."'");
					 
					 $queryMessage = $DB -> prepare ("INSERT INTO `mail_messages` SET
					                                 `id` = NULL,
													 `kto` = ?,
													 `komy` = ?,
													 `text` = ?,
													 `time` = '".time ()."'");	
                     $queryMessage -> execute (Array ($user['id'], $_GET['id'], $_POST['msg']));

                     $queryCommentRating = $DB -> query ("UPDATE `active_rating` SET `comments` = `comments` + '1' WHERE `user_id` = '".$user['id']."'");

                     header('Location: '.HTTP.'/mail/mail.php?id='.$users['id'].'');
	 }

	}
 
 }
 
 echo '<div class="comment">
 <form action = "'.HTTP.'/mail/mail.php?id='.$users['id'].'&wtf='.$user['wtf'].'&go" method = "POST">
 <textarea name="msg" placeholder = "Ваше сообщение..."></textarea> <br />
 <input name="js" type="hidden" value="no" id="js">
 <input type="submit" value="Отправить" name = "go" id = "send">
 </form></div>

 <div class = "block"><img src = "'.HTTP.'/images/user/folder.png"> <a href = "'.HTTP.'/smiles/">Смайлы</a></div>';
 
 if ($query -> rowCount() == 0)
 {
 echo '<div class="block">Сообщений нет</div>';
 }
 else {

 while ($res = $query -> fetch (PDO::FETCH_ASSOC))
 {

 $statusMessage = ($res['new'] == 1) ? '<span class = "StatusMessage">' : '';
 $statusMessage2 = ($res['new'] == 1) ? '</span>' : '';

 echo '

 <div class="block">

     <div id="avatar">
       
         '.Core::avatar ($res['kto'], 40).'

     </div>


     <div id="content">

         '.Core::icon ($res['kto'], 0, 1, 1).' '.$view.'

         <span id = "right">'.Core::date_time ($res['time']).'</span>

         <br />

         '.$statusMessage.''.Core::bb ($res['text']).''.$statusMessage2.'

     </div>

 </div>

 ';


 }

 if ($k_page > 1) Core::str(''.HTTP.'/mail/mail.php?id='.$_GET['id'].'&', $k_page, $page);

 }
 
  echo '

  <div class="location-bar" id="header_path">
      
      
        <a href="'.HTTP.'/?" class="location-bar__home-link ico"></a> <span class="location-bar__sep ico"></span>
      
        <a href = "'.HTTP.'/my/?name='.$user['login'].'">'.$user['login'].'</a> 

        <span class="location-bar__sep ico"></span>

        <a href = "'.HTTP.'/mail/">Почта</a>
      
 </div>

 ';

 require_once $_SERVER['DOCUMENT_ROOT'].'/core/footer.php';
  
?>