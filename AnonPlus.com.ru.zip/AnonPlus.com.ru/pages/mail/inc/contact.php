<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $contact = (int) intval (abs ($_GET['contact'])); 

 $queryContact = $DB -> query ("SELECT * FROM `mail_contacts` WHERE `kto` = '".$user['id']."' AND `kogo` = ".$contact."") -> RowCount ();
                     
 if ($queryContact < 1) {
 
     Core::redirect ("Контакст не существует!", HTTP."/mail/");
     
 }

 $ank = $DB -> query ("SELECT `login`, `id`, `mail_access` FROM `users` WHERE `id` = '".$contact."'") -> fetch ();

 if ($ank['id'] != 0) {

 if ($ank['mail_access'] == 3 and $user['id'] != $ank['id']) Core::redirect ("Пользователь закрыл свою почту для всех!", HTTP."/mail/");
 else if ($ank['mail_access'] == 2 and User::friend ($user['id'], $ank['id']) == false and $user['id'] != $ank['id']) Core::redirect ("Почта открыта только для друзей!", HTTP."/mail/");
 else if ($ank['mail_access'] == 1 and $user['id'] != $ank['id']) {

     $queryContact = $DB -> query ("SELECT `id` FROM `mail_contacts` WHERE `kto` = '".$user['id']."' AND `kogo` = '".$ank['id']."'");
     if ($queryContact -> RowCount () < 1) Core::redirect ("Почта открыта только контактов которые знакомые пользователю!", HTTP."/mail/");

 }

 if ($user['mail_access'] == 3) Core::redirect ("Вы закрыли свою почту для всех!", HTTP."/mail/");
 else if ($user['mail_access'] == 2 and User::friend ($user['id'], $ank['id']) == false) Core::redirect ("Вы открыли почту только для друзей!", HTTP."/mail/");
 else if ($user['mail_access'] == 1) {

     $queryContact = $DB -> query ("SELECT `id` FROM `mail_contacts` WHERE `kto` = '".$user['id']."' AND `kogo` = '".$ank['id']."'");
     if ($queryContact -> RowCount () < 1) Core::redirect ("Почта открыта только контактов которые знакомые пользователю!", HTTP."/mail/");

 }

 }
 
 $UpdateMail = $DB -> query ("UPDATE `mail_messages` SET `new` = '0' WHERE `komy` = '".$user['id']."' AND `kto` = '".$ank['id']."'");
 
 $c_p = $DB -> query ('SELECT * FROM `mail_messages` WHERE (`kto` = "'.$user['id'].'" AND `komy` = "'.$ank['id'].'") or (`kto` = "'.$ank['id'].'" AND `komy` = "'.$user['id'].'" ) ORDER by `time` DESC') -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
        else $p_page = '7';
        $k_page = Core::k_page($c_p, $p_page);
        $page = Core::page($k_page);
        $start = $p_page*$page-$p_page;

 $query = $DB -> query('SELECT * FROM `mail_messages` WHERE (`kto` = "'.$user['id'].'" AND `komy` = "'.$ank['id'].'") or (`kto` = "'.$ank['id'].'" AND `komy` = "'.$user['id'].'" ) ORDER by `time` DESC LIMIT '.$start.', '.$p_page.'');

 if (isset ($_POST['send'])) include_once ROOT.'/pages/mail/inc/send.php';

 $description = NULL;
 $keywords = NULL;
 $title = $user['login'].' / Почта / '.(empty ($ank['login']) ? 'Система' : $ank['login']);

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/mail/">

                 Почта

             </a>

         </div>

 ';
 
 Core::Error ();
 Core::Ok ();

 echo '
         <div class = "background_place">

         <div class = "main_place">

         <div class = "place">

             <div id = "avatar">

                 '.Core::avatar ($ank['id'], 40).'

             </div>

             '.Core::user ($ank['id'], 0, 1, 1).'

             <br />

             <small>

                 <span class = "private_info">'.Core::UserEnd ($ank['id']).'</span>

             </small>

         </div>

 ';

 echo '
         '.$err.'
         
         <div class = "nav">

             <form action = "" method = "POST">

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

                 <textarea name="msg" placeholder = "Ваше сообщение..."></textarea>

                 <br />

                 <input type="submit" value="Написать" name = "send">

             </form>

         </div>

         </div>

 ';

 if ($query -> RowCount() < 1) echo '<div class="block">Сообщений нет</div>';
 else {

     echo '

         <div class = "main_place">

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 ПЕРЕПИСКА С '.(empty ($ank['login']) ? 'СИСТЕМА' : $ank['login']).'

             </a>

         </div>
     ';

     while ($res = $query -> fetch ()) {

         $statusMessage = ($res['new'] == 1) ? '<span class = "StatusMessage">' : '';
         $statusMessage2 = ($res['new'] == 1) ? '</span>' : '';

         echo '

         <div class="place">

             <div id="avatar">
       
                 '.Core::avatar ($res['kto'], 40).'

             </div>


             <div id="content">

                 '.Core::user ($res['kto'], 0, 1, 1).' '.$view.'

                 <span id = "right"><small>'.Core::date_time ($res['time']).'</small></span>

                 <br />

                 '.$statusMessage.''.Core::bb ($res['text']).''.$statusMessage2.'

             </div>

         </div>
 
 ';

 }

 if ($k_page > 1) Core::str(''.HTTP.'/mail/?contact='.$ank['id'].'&', $k_page, $page);

     echo '

         </div>

     ';

 }

 echo '
         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/mail/">

                 Почта
                 
             </a>

         </div>

 ';

 include_once ROOT.'/template/footer.php';

?>