<?php

 ## Если отправлен пост запрос
 if (isset ($_POST['send'])) {
     
     ## Обрабатываем данные
     $message = Core::check ($_POST['msg']);
     $CK = intval (abs ($_POST['CK']));

     ## Проверяем CK
     if (isset ($CK) and $user['CK'] == $CK) {

         ## Проверяем на пустоту
         if (empty ($message)) $err = '<div class = "err">Введите сообщение!</div>';
         else {

                 ## Проверяем максимальну длину сообщения
                 if (strlen($message) > 10000) $err = '<div class = "err">Сообщение не должно превышать 10000 символов!</div>';
                 else {

                     ## Заносим данные в БД
                     $queryContact = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '".$user['id']."' AND `kogo` = '".$ank['id']."'");
					 $queryContact2 = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '".$ank['id']."' AND `kogo` = '".$user['id']."'");
					 
					 $queryMessage = $DB -> query ("INSERT INTO `mail_messages` SET
													 `kto` = '".$user['id']."',
													 `komy` = '".$ank['id']."',
													 `text` = ".$DB -> quote ($message).",
													 `time` = '".time ()."'");
                     ## Обновляем страницу
                     header('Location: '.HTTP.'/mail/?contact='.$ank['id'].'');

                }
	     }

	 }
     else Core::redirect ("Не верный CK!", HTTP."/mail/?contact=".$ank['id']."");
 
 }

?>