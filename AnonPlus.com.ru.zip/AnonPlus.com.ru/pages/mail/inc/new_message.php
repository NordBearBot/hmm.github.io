<?php 

 $description = NULL;
 $keywords = NULL;
 $title = $user['login'].' / Почта / Новое сообщение';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/mail/">

                 Почта

             </a>

         </div>

         <div class = "background_place">

         <div class = "main_place">

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 Новое сообщение

             </a>

         </div>

 ';

 Core::Error ();
 Core::Ok ();

 if (isset ($_GET['name'])) {

     $name = Core::check ($_GET['name']);

     $queryUser = $DB -> query ("SELECT `id`, `login`, `mail_access` FROM `users` WHERE `login` = ".$DB -> quote ($name)." LIMIT 1");
     if ($queryUser -> RowCount () < 1) Core::redirect ("Пользователь не существует!", HTTP."/mail/?new");

     $users = $queryUser -> fetch ();

     if ($users['login'] == $user['login']) Core::redirect ("Себе писать нельзя!", HTTP."/mail/?new");

     if ($users['mail_access'] == 3) Core::redirect ("Пользователь закрыл свою почту для всех!", HTTP."/mail/?new");
     else if ($users['mail_access'] == 2 and User::friend ($user['id'], $users['id']) == false) Core::redirect ("Почта открыта только для друзей!", HTTP."/mail/?new");
     else if ($users['mail_access'] == 1) {

        $queryContact = $DB -> query ("SELECT `id` FROM `mail_contacts` WHERE `kto` = '".$user['id']."' AND `kogo` = '".$users['id']."'");
        if ($queryContact -> RowCount () < 1) Core::redirect ("Почта открыта только контактов которые знакомые пользователю!", HTTP."/mail/?new");

     }

     if (isset ($_POST['send'])) {

         $message = Core::check ($_POST['message']);

         if (empty ($message)) $err = '<div class = "err">Введите сообщение!</div>';
         else if (strlen($message) > 3000) $err = '<div class = "err">Сообщение не должно превышать 3000 символов!</div>';
         else if (empty ($err)) {

                     $queryData = $DB -> query ("SELECT `kto`, `kogo` FROM `mail_contacts` WHERE `kto` = '".$user['id']."' AND `kogo` = '".$users['id']."'");
                     $countData = $queryData -> RowCount ();
                     
                     if ($countData > 0) {
                     
                     $queryContact = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '".$user['id']."' AND `kogo` = '".$users['id']."'");
                     $queryContact2 = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '".$users['id']."' AND `kogo` = '".$user['id']."'");

                     }  
                     else {

                     $DB -> query ("INSERT INTO `mail_contacts` SET 
                                                `kto` = '".$user['id']."',
                                                `kogo` = '".$users['id']."',
                                                `time` = '".time ()."'");

                     $DB -> query ("INSERT INTO `mail_contacts` SET 
                                                `kto` = '".$users['id']."',
                                                `kogo` = '".$user['id']."',
                                                `time` = '".time ()."'");
                   
                     }   

                     $DB -> query ("INSERT INTO `mail_messages` SET
                                                     `kto` = '".$user['id']."',
                                                     `komy` = '".$users['id']."',
                                                     `text` = ".$DB -> quote ($message).",
                                                     `time` = '".time ()."'");                                                 
                 
                     header ('Location: '.HTTP.'/mail/?contact='.$users['id'].''); 

         }


     }

     echo '

     <form action = "" method = "POST">

         '.$err_login.'

         <div class = "block">

             Кому: <b style = "color: darkgreen;">'.$users['login'].'</b>

         </div>

         '.$err.'

         <div class = "block">

             Сообщение:

             <br />

             <textarea name = "message" placeholder = "Введите сообщение...">'.(isset ($_POST['message']) ? $message : '').'</textarea>
      
         </div>

         <div class = "block">

             <input type = "submit" name = "send" value = "Отправить">

         </div>

     </form>

     </div>

     </div>

     ';





 }
 else {

 if (isset ($_POST['send'])) {

     $name = Core::check ($_POST['name']);
     $message = Core::check ($_POST['message']);

     if (empty ($name)) $err_login = '<div class = "err">Введите ник пользователя!</div>';

     if (empty ($err_login)) {

         $queryUser = $DB -> query ("SELECT `id`, `login`, `mail_access` FROM `users` WHERE `login` = ".$DB -> quote ($name)." LIMIT 1");

         if ($queryUser -> RowCount () < 1) Core::redirect ("Пользователь не существует!", HTTP."/mail/?new");
         $users = $queryUser -> fetch ();

         if ($users['login'] == $user['login']) Core::redirect ("Себе писать нельзя!", HTTP."/mail/?new");

         if ($users['mail_access'] == 3) Core::redirect ("Пользователь закрыл свою почту для всех!", HTTP."/mail/?new");
         else if ($users['mail_access'] == 2 and User::friend ($user['id'], $users['id']) == false) Core::redirect ("Почта открыта только для друзей!", HTTP."/mail/?new");
         else if ($users['mail_access'] == 1) {

             $queryContact = $DB -> query ("SELECT `id` FROM `mail_contacts` WHERE `kto` = '".$user['id']."' AND `kogo` = '".$users['id']."'");
             if ($queryContact -> RowCount () < 1) Core::redirect ("Почта открыта только контактов которые знакомые пользователю!", HTTP."/mail/?new");

         }

         if (empty ($message)) $err = '<div class = "err">Введите сообщение!</div>';
         else if (strlen($message) > 3000) $err = '<div class = "err">Сообщение не должно превышать 3000 символов!</div>';
         else if (empty ($err)) {

                     $queryData = $DB -> query ("SELECT `kto`, `kogo` FROM `mail_contacts` WHERE `kto` = '".$user['id']."' AND `kogo` = '".$users['id']."'");
                     $countData = $queryData -> RowCount ();
                     
                     if ($countData > 0) {
                     
                     $queryContact = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '".$user['id']."' AND `kogo` = '".$users['id']."'");
                     $queryContact2 = $DB -> query ("UPDATE `mail_contacts` SET `time` = '".time ()."' WHERE `kto` = '".$users['id']."' AND `kogo` = '".$user['id']."'");

                     }  
                     else {

                     $DB -> query ("INSERT INTO `mail_contacts` SET 
                                                `kto` = '".$user['id']."',
                                                `kogo` = '".$users['id']."',
                                                `time` = '".time ()."'");

                     $DB -> query ("INSERT INTO `mail_contacts` SET 
                                                `kto` = '".$users['id']."',
                                                `kogo` = '".$user['id']."',
                                                `time` = '".time ()."'");
                   
                     }   

                     $DB -> query ("INSERT INTO `mail_messages` SET
                                                     `kto` = '".$user['id']."',
                                                     `komy` = '".$users['id']."',
                                                     `text` = ".$DB -> quote ($message).",
                                                     `time` = '".time ()."'");                                                 
                 
                     header ('Location: '.HTTP.'/mail/?contact='.$users['id'].'');   
 
         }

     }

 }

 echo '

     <form action = "" method = "POST">

         '.$err_login.'

         <div class = "block">

             Кому:

             <br />

             <input type = "text" name = "name" '.(isset ($_POST['name']) ? 'value = "'.$name.'"' : 'placeholder = "Ник пользователя..."').' >

         </div>

         '.$err.'

         <div class = "block">

             Сообщение:

             <br />

             <textarea name = "message" placeholder = "Введите сообщение...">'.(isset ($_POST['message']) ? $message : '').'</textarea>
      
         </div>

         <div class = "block">

             <input type = "submit" name = "send" value = "Отправить">

         </div>

     </form>

     </div>

     </div>

 ';



 }

 echo '       

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/mail/">

                 Почта

             </a>

         </div>
         
 ';

 include_once ROOT.'/template/footer.php';

?>