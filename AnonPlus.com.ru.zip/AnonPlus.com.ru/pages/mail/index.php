<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 if (isset ($_GET['new'])) { include_once ROOT.'/pages/mail/inc/new_message.php'; exit; }

 if (isset ($_GET['contact'])) { include_once ROOT.'/pages/mail/inc/contact.php'; exit; }



 $description = NULL;
 $keywords = NULL;
 $title = $user['login'].' / Почта';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             Почта

         </div>

 ';

 Core::Error ();
 Core::Ok();

 echo '
         <div class = "background_place">

             <div class = "main_place">

             <div class="b-title b-title_first">

                 <a class="b-title__link">

                 Поиск

                 </a>

             </div>

             <div class = "block" style = "padding-bottom: 0; border: none;">
             <form method=GET>
             <table style="width: 100%;">

               <tbody>

                     <tr>

                         <td style="width: 100%;">

                             <input type="text" placeholder="Введите ник контакта" name="whois" class="search" style="width: 100%;">

                         </td>

                         <td>

                             <input type="submit" style = "margin-left: 25px; margin-top: 7px;" class="search_ok">
             
                         </td>

                     </tr> 

                 </tbody>

             </table>
         </form>
         </div>

         <a class = "home-f" style = "text-align: center; border-top: 1px solid #eee;" href = "'.HTTP.'/mail/?new">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/mail_ico.gif">

             Новое сообщение

         </a>

         </div>

         <div class = "main_place">

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 Контакты

             </a>

         </div>

 ';
 
 //by binore
 // Поиск собеседников
 if(!isset($_GET['whois'])){
 $c_p = $DB -> query ("SELECT * FROM `mail_contacts` WHERE `kto` = '".$user['id']."' ORDER BY `time` DESC") -> RowCount ();

        if (isset($user)) $p_page = $user['count_page'];
        else $p_page = '7';
        $k_page = Core::k_page($c_p, $p_page);
        $page = Core::page($k_page);
        $start = $p_page*$page-$p_page;

 $query = $DB -> query ("SELECT * FROM `mail_contacts` WHERE `kto` = '".$user['id']."' ORDER BY `time` DESC LIMIT $start, ".$p_page."");
 }
 else{
 $query_find = $DB->query("SELECT * FROM users WHERE login LIKE '".Core::check($_GET['whois'])."'");
 $ch = 0;
 if($query_find->RowCount() == 0){
     $c_p = 0;
 }
 else{
     $f_login = $query_find ->fetch()['id'];
     $ch++;
     $c_p = $DB -> query ("SELECT * FROM `mail_contacts` WHERE `kto` = '".$user['id']."' AND kogo = ".(int)$f_login." ORDER BY `time` DESC") -> RowCount ();
 }
        if (isset($user)) $p_page = $user['count_page'];
        else $p_page = '7';
        $k_page = Core::k_page($c_p, $p_page);
        $page = Core::page($k_page);
        $start = $p_page*$page-$p_page;
  if($ch == 0)
  $query = $DB -> query ("SELECT * FROM `mail_contacts` WHERE `kto` = '".$user['id']."' ORDER BY `time` DESC LIMIT $start, ".$p_page."");
  else $query = $DB -> query ("SELECT * FROM `mail_contacts` WHERE `kto` = '".$user['id']."' AND kogo=".$f_login." ORDER BY `time` DESC LIMIT $start, ".$p_page."");
 }
 
 if ($query -> RowCount() == 0) echo '<div class="block">У вас нет переписок</div>';
 else {
 
 while ($res=$query->fetch()) {
 
 $mess = $DB -> query ('SELECT * FROM `mail_messages` WHERE (`kto` = "'.$user['id'].'" AND `komy` = "'.$res['kogo'].'") or (`kto` = "'.$res['kogo'].'" AND `komy` = "'.$user['id'].'" ) ORDER by `time` DESC') -> fetch();
 
 $YouCountMessage = $DB -> query ("SELECT `id` FROM `mail_messages` WHERE `kto` = '".$user['id']."' AND `komy` = '".$res['kogo']."'") -> RowCount ();
 $ContactCountMessage = $DB -> query ("SELECT `id` FROM `mail_messages` WHERE `kto` = '".$res['kogo']."' AND `komy` = '".$user['id']."'") -> RowCount ();

 $countNew = $DB -> query ("SELECT `id` FROM `mail_messages` WHERE `kto` = '".$res['kogo']."' AND `komy` = '".$user['id']."' AND `new` = '1'") -> RowCount ();

 $styleCount = '<small>';
 $styleCount2 = '</small>'; 


 if ($mess['kto'] == $user['id']) {

     $statusMessage = ($mess['new'] == 1) ? '<span class = "StatusMessage" style = "display: inline-block;"><font color = "#727272">' : '<font color = "#727272">';
     $statusMessage2 = ($mess['new'] == 1) ? '</font></span>' : '</font>';

 }
 else {

     $statusMessage = ($mess['new'] == 1) ? '<b class = "ank_info">' : '<font color = "#727272">';
     $statusMessage2 = ($mess['new'] == 1) ? '</b>' : '</font>';

 }

 $NavOutSend = ($mess['kto'] == $user['id']) ? '<img src = "'.HTTP.'/files/system.images/site.icons/message_out.png"> ' : '<img src = "'.HTTP.'/files/system.images/site.icons/message_in.png"> ';

 $countNewMsg = ($countNew > 0 ? '<span class = "new_msg_count"><small>+ '.$countNew.'</small></span>' : '');

 echo '

         <a class = "home" href = "'.HTTP.'/mail/?contact='.$res['kogo'].'">

             <div id = "avatar">

                 '.Core::avatar ($res['kogo'], 40).'

             </div>

             '.Core::user ($res['kogo'], 0, 1, 0).'

             '.$countNewMsg.'

                 <span id = "right">

                     <span class = "left_count">'.$styleCount.''.$YouCountMessage.''.$styleCount2.'</span><span class = "right_count">'.$styleCount.''.$ContactCountMessage.''.$styleCount2.'</span>
                 
                 </span>

             <br />

             <div id = "content">

                 <small>

                     '.$NavOutSend.' '.$statusMessage.''.Core::CropStr (Core::without_bb($mess['text']), 100).''.$statusMessage2.'

                 </small>
             
             </div>

        </a>

 ';

 $NavOutSend = NULL;


 }

 if ($k_page > 1) Core::str(''.HTTP.'/mail/?', $k_page, $page);

 }

 echo '

         </div>

         </div>

 ';

 echo '

         <a href = "'.HTTP.'/settings/mail/" class = "nav_part" style = "text-align: left;"><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/settings.png"> Настройки почты</a>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             Почта

         </div>

 ';

 include_once ROOT.'/template/footer.php';

?>