<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $id = (int) abs ($_GET['id']);

 $queryBlog = $DB -> query ("SELECT * FROM `blogs` WHERE `id` = '".$id."'");

 if ($queryBlog -> RowCount () < 1) Core::redirect ("Запись не существует!", HTTP."/uid".$user['id']."/blog");
 $blog = $queryBlog -> fetch ();

 if ($blog['share'] > 0) $share = $DB -> query ("SELECT * FROM `blogs` WHERE `id` = '".$blog['share']."'") -> fetch ();
 else $share = $blog;

 if ($share['user_id'] == $user['id'] or $share['access'] > 0) Core::redirect ("Этой записью нелья делится!", HTTP."/uid".$share['user_id']."/blog/?i=".$share['id']);

 $queryTryBlog = $DB -> query ("SELECT `id` FROM `blogs` WHERE `user_id` = '".$user['id']."' AND `share` = '".$share['id']."'") -> RowCount ();

 if ($queryTryBlog > 0) Core::redirect ("Вы уже делились этой записью!", HTTP."/uid".$share['user_id']."/blog/?i=".$share['id']);

 if (isset ($_POST['share'])) {

     $message = Core::check ($_POST['message']);
     $CK = (int) abs ($_POST['CK']);

     if ($CK != $user['CK']) Core::redirect ("Не верный CK!", HTTP."/share/id".$share['id']);

     $err = (Core::utf_strlen ($message) > 3000) ? '<div class = "err">Комментарий не должен превышать 3000 символов!</div>' : NULL;

     if (empty ($err)) {

         $DB -> query ("INSERT INTO `blogs` SET
                        `user_id` = '".$user['id']."',
                        `message` = ".$DB -> quote ($message).",
                        `channel` = '".$share['channel']."',
                        `access` = '0',
                        `time` = '".time ()."',
                        `share` = '".$share['id']."'");

         $data = $DB -> query ("SELECT `id` FROM `blogs` WHERE `user_id` = '".$user['id']."' ORDER BY `id` DESC LIMIT 1") -> fetch ();

         Core::lenta ($user['id'], $data['id'], $message, '/uid'.$user['id'].'/blog/?i='.$data['id'].'', '4', $share['id']);

         Core::redirect_ok ("Запись создана!", HTTP."/uid".$user['id']."/blog/?i=".$data['id']);

     }


 }

 $title = $user['login'].' / Блог / Поделиться записью';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/blog">Блог</a>

             <span class = "ico next"></span>

             Поделиться записью

         </div>
 
         <div class = "background_place">

             <div class = "main_place">

                 <div class = "place" style = "line-height: 1.4;">

                     <div id = "avatar">

                         '.Core::avatar ($share['user_id'], 40).'

                     </div>

                     <div id = "content">

                         '.Core::user ($share['user_id'], 1, 1, 1).'

                         <span class = "private_info" id = "right">

                             <small>

                                 '.Core::date_time ($share['time']).'

                             </small>

                         </span>

                         <br />

                         <a href = "'.HTTP.'/uid'.$share['user_id'].'/blog/?i='.$share['id'].'">

                             '.Core::CropStr (Core::without_bb ($share['message']), 300).'

                         </a>

                     </div>

                 </div>

                 <div class = "block">

                     <span class="private_info">

                         Канал:

                     </span>

                     <a class = "info_link" href = "">

                         '.Blog::channel ($share['id']).'

                     </a>

                 </div>

                 '.$err.'

                 <div class = "nav">

                     <form action = "" method = "POST">

                         <textarea name="message"  placeholder = "Комментировать...">'.(isset ($_POST['message']) ? $message : '').'</textarea>

                         <br />

                         <input type = "submit" name = "share" value = "Поделиться"/>

                         <input type="hidden" name="CK" value="'.$user['CK'].'" />

                     </form>

                 </div>

             </div>

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/blog">Блог</a>

             <span class = "ico next"></span>

             Поделиться записью

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>