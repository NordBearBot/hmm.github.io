<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 if (isset ($_GET['CK']) and $user['CK'] == $_GET['CK']) {

           setcookie('UID', '', -1, '/');
           setcookie('USID', '', -1, '/');
 
           session_destroy();

           header('location: '.HTTP.'/');

 }
 else Core::redirect ("Не верный CK!", HTTP."/uid".$user['id']."");

?>