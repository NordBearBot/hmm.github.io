<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $id = (int) abs ($_GET['id']);
 if ($id != $user['id'] and $user['level'] < 1) header('Location: '.HTTP.'/uid'.$user['id'].'/remarks');

 $queryUser = $DB -> query ("SELECT * FROM `users` WHERE `id` = '".$id."'");
 if ($queryUser -> RowCount () < 1) Core::redirect ("Пользователь не существует!", HTTP."/uid".$user['id']);
 $ank = $queryUser -> fetch ();

 if (isset ($_GET['ban'])) { include_once $_SERVER['DOCUMENT_ROOT'].'/pages/remarks/inc/view.php'; exit; }

 $queryVote = $DB -> query ("SELECT `id`, `ban_time`, `type`, `time` FROM `user_ban_list` WHERE `user_id` = '".$ank['id']."' ORDER BY `time` DESC");
 $countRemarks = $DB -> query ("SELECT `id` FROM `user_ban_list` WHERE `user_id` = '".$ank['id']."'") -> RowCount ();

 $title = $ank['login'] .' / Нарушения';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             Нарушения

         </div>
 ';

 Core:: Ok ();
 Core:: Error ();

 echo '

         <div class = "background_place">

             <div class = "main_place">

 ';

 if ($queryVote -> RowCount () < 1) {

     echo '

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                         Нарушения

                     </a>

                 </div>

                 <div class = "place">

                     Нарушений нету!

                 </div>

     ';
 
 }
 else {

     echo '

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                         Нарушения

                         <span class = "count_web">

                             '.$countRemarks.'

                         </span>

                     </a>

                 </div>

     ';

     while ($vote = $queryVote -> fetch ()) {

         $ban_time = ($vote['ban_time'] == 3600 ? 1 : ($vote['ban_time'] == 10800 ? 3 : ($vote['ban_time'] == 43200 ? 12 : ($vote['ban_time'] == 86400 ? 24 : ($vote['ban_time'] == 172800 ? 48 : ($vote['ban_time'] == 432000 ? 120 : ($vote['ban_time'] == 86400 ? 240 : 0)))))));
         $ban_where = ($vote['type'] == 'chat' ? 'Чат' : (($vote['type'] == 'forum_theme' or $vote['type'] == 'forum_comment') ? 'Форум' : ($vote['type'] == 'ban_file' ? 'Файлы' : 'Сайт')));
         echo '

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     <b>'.$ban_where.'</b>, бан на <b>'.$ban_time.' ч.</b>

                     <small class = "private_info" id = "right">

                         '.Core::date_time ($vote['time']).'

                     </small>

                     <br />

                     <a class = "private_info" href = "'.HTTP.'/uid'.$ank['id'].'/remarks/?ban='.$vote['id'].'">

                         Подробнее...

                     </a>

                 </div>

         ';

     }

 }

 echo '

             </div>

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             Нарушения

         </div>
 ';

 include_once ROOT.'/template/footer.php';

 ?>