<?php 

 $ban_id = (int) abs ($_GET['ban']);

 $queryVote = $DB -> query ("SELECT * FROM `user_ban_list` WHERE `id` = '".$ban_id."' and `user_id` = '".$ank['id']."'");
 if ($queryVote -> RowCount () < 1) Core::redirect ("Нарушение не найдено!", HTTP."/uid".$ank['id']."/remarks");

 $vote = $queryVote -> fetch ();
 $mod = $DB -> query ("SELECT `id`, `login`, `level` FROM `users` WHERE `id` = '".$vote['moder_id']."'") -> fetch ();

 if (isset ($_GET['null']) and $user['level'] == 1) {

     $CK = (int) abs ($_GET['CK']);
     if ($user['CK'] != $CK) Core::redirect ('Не верный CK!', HTTP.'/uid'.$ank['id'].'/remarks/?ban='.$vote['id']);

     $DB -> query ("UPDATE `user_ban_list` SET `ban_time` = '0' WHERE `id` = '".$vote['id']."'");
     Core::redirect_ok ('Бан успешно снят!', HTTP.'/uid'.$ank['id'].'/remarks/?ban='.$vote['id']);

 }

 if (isset ($_GET['delete']) and $user['level'] == 1) {

     $CK = (int) abs ($_GET['CK']);
     if ($user['CK'] != $CK) Core::redirect ('Не верный CK!', HTTP.'/uid'.$ank['id'].'/remarks/?ban='.$vote['id']);

     $DB -> query ("DELETE FROM `user_ban_list` WHERE `id` = '".$vote['id']."'");
     Core::redirect_ok ('Бан успешно удален!', HTTP.'/uid'.$ank['id'].'/remarks/');

 }

 $ban_where = ($vote['type'] == 'chat' ? 'Чат' : (($vote['type'] == 'forum_theme' or $vote['type'] == 'forum_comment') ? 'Форум' : ($vote['type'] == 'ban_file' ? 'Файлы' : 'Сайт')));
 $ban_time = ($vote['ban_time'] == 3600 ? 1 : ($vote['ban_time'] == 10800 ? 3 : ($vote['ban_time'] == 43200 ? 12 : ($vote['ban_time'] == 86400 ? 24 : ($vote['ban_time'] == 172800 ? 48 : ($vote['ban_time'] == 432000 ? 120 : ($vote['ban_time'] == 86400 ? 240 : 0)))))));

 $data = $DB -> query ("SELECT * FROM `".($vote['type'] == 'chat' ? 'chat_messages' : ($vote['type'] == 'forum_theme' ? 'forum_themes' : ($vote['type'] == 'forum_comment' ? 'forum_comments' : ($vote['type'] == 'ban_file' ? 'block_files' : ''))))."` WHERE `id` = '".$vote['object_id']."'") -> fetch ();
   
 if ($vote['type'] == 'forum_theme') {

     $sub = $DB -> query ("SELECT `id`, `name`, `section_id` FROM `forum_subsection` WHERE `id` = '".$data['subsection']."'") -> fetch ();
     $section = $DB -> query ("SELECT `id`, `name` FROM `forum_section` WHERE `id` = '".$sub['section_id']."'") -> fetch ();

     $msg_remark = '<a href = "'.HTTP.'/forum/?section='.$section['id'].'&sub='.$sub['id'].'&theme='.$data['id'].'">Ссылка на тему</a>';

 }

 if ($vote['type'] == 'ban_file') {

     $file = $DB -> query ("SELECT * FROM `block_files` WHERE `file_id` = '".$data['id']."' AND `file_type` = '".$vote['type_file']."'") -> fetch ();

     $msg_remark = '<a href = "'.HTTP.'/uid'.$ank['id'].'/'.$vote['type_file'].'/?blocks&'.($vote['type_file'] == 'pictures' ? 'pic' : 'file').'='.$data['id'].'">Ссылка на файл</a>';
 
 }

 $title = $ank['login'] .' / Нарушения / Просмотр';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/remarks">

                 Нарушения

             </a>

             <span class = "ico next"></span>

             Просмотр

         </div>
 ';

 Core:: Ok ();
 Core:: Error ();

 echo '

         <div class = "background_place">

             <div class = "main_place">

                 <div class="b-title b-title_first">

                     <a class="b-title__link">

                         Нарушение

                     </a>

                 </div>

                 <div class = "place" style = "border-bottom: 1px solid #eee;">
                     
                     '.(time () > $vote['time']+$vote['ban_time'] ? '<span class = "private_info">Бан не активен</span>' : '<font color = "darkred">Бан активен</font>').'

                     <small class = "private_info" id = "right">

                         '.Core::date_time ($vote['time']).'

                     </small>

                 </div>

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     Пользователь: '.Core::user ($ank['id'], 1, 1, 1).'

                     <br />

                     Нарушение: <span class = "private_info">'.(($vote['type'] == 'forum_theme' or $vote['type'] == 'ban_file')? $msg_remark : $data['msg']).'</span>
                  
                 </div>

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     '.($mod['level'] == 1 ? 'Администратор' : 'Модератор').': '.Core::user ($mod['id'], 1, 1, 1).'

                     <br />

                     Комментарий: <b class = "private_info">'.$vote['message'].'</b>
                  
                 </div>

                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     Раздел: <span class = "private_info">'.$ban_where.'</span>

                     <br />

                     Причина: <span class = "private_info">'.Core::remark_reason ($vote['type'], $vote['what']).'</span>

                     <br />

                     Время: <span class = "private_info">'.$ban_time.' ч.</span>

                 </div>

                 '.($user['level'] == 1 ? '<div class = "place" style = "border-bottom: 1px solid #eee;"><a class = "private_info" href = "'.HTTP.'/uid'.$ank['id'].'/remarks/?ban='.$vote['id'].'&null=0&CK='.$user['CK'].'">Снять бан</a></div>' : '').'
                 '.($user['level'] == 1 ? '<div class = "place"><a class = "private_info" href = "'.HTTP.'/uid'.$ank['id'].'/remarks/?ban='.$vote['id'].'&delete=0&CK='.$user['CK'].'">Удалить бан</a></div>' : '').'
             </div>

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/remarks">

                 Нарушения

             </a>

             <span class = "ico next"></span>

             Просмотр

         </div>
 ';

 include_once ROOT.'/template/footer.php';

 ?>