<?php 

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Подтверждение

         </div>
 ';
 
 if (isset ($_POST['okay']) or isset ($_GET['code'])) {
 
     $auth = $DB -> query ("SELECT `hash` FROM `history_auth` WHERE `user_id` = '".$user['id']."' ORDER BY `id` DESC LIMIT 1") -> fetch ();

     $code = (isset ($_POST['code']) ? $_POST['code'] : (isset ($_GET['code']) ? $_GET['code'] : ''));

     if ($code != $auth['hash']) Core::redirect ("Не верный код!", HTTP."/uid".$user['id']."");
     else {

         $DB -> query ("UPDATE `history_auth` SET `status` = '0' WHERE `user_id` = '".$user['id']."'");
         Core::redirect_ok ("Приятного пользования сайтом", HTTP."/uid".$user['id']."");

     }


 }

 Core:: Error ();

 echo '

         <div class = "block">

             На вашем аккаунте были замечены подозрительные действия, на ваш Email-адрес был отправлен код, введите его здесь или перейдите по ссылке в письме. 

         </div>

         <div class = "block">

             <form action = "" method = "POST">

                 Код:

                 <br />

                 <input type = "text" name = "code">

                 <br />

                 <input type = "submit" name = "okay" value = "Ввести">

             </form>

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Подтверждение

         </div>
 ';

?>