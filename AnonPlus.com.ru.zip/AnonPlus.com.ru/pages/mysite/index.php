<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $id = (int) abs ($_GET['id']);

 if (isset ($_GET['auth'])) include_once $_SERVER['DOCUMENT_ROOT'].'/pages/mysite/inc/tm.php';

 $queryUser = $DB -> query ("SELECT * FROM `users` WHERE `id` = '".$id."'");

 if ($queryUser -> RowCount () < 1) Core::redirect ("Пользователь не существует!", HTTP."/people/");

 $ank = $queryUser -> fetch ();

 $info = $DB -> query ("SELECT * FROM `user_anketa` WHERE `user_id` = '".$ank['id']."'") -> fetch ();

 $l = (!empty ($info['name']) and !empty ($info['age'])) ? ', ' : NULL;
 $l2 = (!empty ($info['name']) and !empty ($info['city']) and empty ($info['age'])) ? ', ' : NULL;
 $l3 = (!empty ($info['age']) and !empty ($info['city'])) ? ', ' : NULL;
 $information = $info['name'].''.$l.''.$l2.''.$info['age'] = (!empty ($info['age']) ? $info['age'].' лет' : '').''.$l3.''.$info['city'];
 
 $countBook = $DB -> query ("SELECT `id` FROM `user_book` WHERE `book_id` = '".$ank['id']."'") -> RowCount ();
 $countPictures = $DB -> query ("SELECT `id` FROM `pictures` WHERE `user_id` = '".$ank['id']."'") -> RowCount ();
 $countFiles = $DB -> query ("SELECT `id` FROM `files` WHERE `user_id` = '".$ank['id']."'") -> RowCount ();
 $countBlog = $DB -> query ("SELECT `id` FROM `blogs` WHERE `user_id` = '".$ank['id']."' ".(User::friend ($user['id'], $ank['id']) == true ? 'AND `access`<2' : 'AND `access`<1')."") -> RowCount ();
 $countFriends = $DB -> query ("SELECT `id` FROM `friends` WHERE `user_id`= '".$ank['id']."'") -> RowCount ();
 $countBookmarks = $DB -> query ("SELECT `id` FROM `bookmarks` WHERE `user_id` = '".$user['id']."'") -> RowCount ();
 $countRemarks = $DB -> query ("SELECT `id` FROM `user_ban_list` WHERE `user_id` = '".$ank['id']."'") -> RowCount ();

 $queryTest = $DB -> query ("SELECT `id` FROM `bookmarks` WHERE `user_id` = '".$user['id']."' AND `type` = '2' AND `object_id` = '".$ank['id']."'") -> RowCount ();
 $bookmarks = ($queryTest < 1) ? '<a href="'.HTTP.'/bookmarks/add/?type=2&id='.$ank['id'].'" class="adv_user_link" id="bookmark_link" title="Добавить в закладки"><span></span></a>' : '<a href="'.HTTP.'/bookmarks/delete/?type=2&id='.$ank['id'].'" class="adv_user_link" id="bookmark_link" title="Удалить из закладок"><span style="background-position: -32px -16px; !important;"></span></a>';

 $editWelcome = ($user['id'] == $ank['id'] and $user) ? '<a id = "right" href = "'.HTTP.'/edit/welcome/"><img src = "'.HTTP.'/files/system.images/site.icons/status.png" alt = "Редактировать приветствие"></a>' : NULL;
 
 include_once ROOT.'/pages/mysite/inc/access_blog.php';

 $description = $ank['login'];
 $keywords = NULL;
 $title = $ank['login'];

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>
 
             '.$ank['login'].'

         </div>
 ';

 Core:: Ok ();
 Core:: Error ();

 if ($user['level'] > 0) echo '<a class = "home box" href = "'.HTTP.'/uid'.$ank['id'].'/remarks">Нарушения <span class = "count_web">'.$countRemarks.'</span></a>';

 echo '
         <div class = "background_place">

 ';

 if ($_GET['auth'] == $user['tm'] and $user['id'] == $ank['id']) {

     echo '

         <div class = "main_place">

             <div class = "place">
              
                 <small>

                     Привет, <b>'.$user['login'].'</b>!

                     <br />

                     <a href = "'.HTTP.'/authlog">История входов</a>: последний раз вы заходили <font color = "darkgreen">'.Core::date_time ($user['online']).'</font>

                 </small>

             </div>

         </div>

     ';
 
 }

 echo '

             <div class = "main_place">

             <div class = "place">

                 <div id = "avatar">

                     '.Core::avatar ($ank['id'], 64).'

                 </div>

                 <div id = "content">

                     <div class = "user_info">

                         '.Core::user ($ank['id'], 1, 1, 0).'

                         <span class = "count_web">

                             <small>

                                 '.Core::UserRating($ank['rating']).'
 
                             </small>
                             
                         </span>

                         <br />

                         <small>

                             '.$info['name'].'

                             '.((!empty ($info['name']) and empty($info['age'])) ? '<br />' : '').'

                             '.((!empty ($info['name']) and !empty($info['age'])) ? '<br />' : '').'

                             <span class = "private_info">

                                 '.$info['age'].'

                                 '.(!empty ($info['age']) ? '<br />' : '').'

                                 '.Core::userSite ($ank['data_registration']).'

                             </span>

                             '.((empty ($info['age']) and empty ($info['name'])) ? '<p>' : '').'              

                         </small>

                     </div>

                 </div>

                 <div>

                     <span id = "top_v"></span>

                     <div class = "status">

                         '.$ank['welcome'].' 

                         '.$editWelcome.'

                     </div>

                 </div>

             </div>

 ';

 if ($user and $user['id'] == $ank['id']) {

        echo '

         <div class = "block" style = "padding: 0; border: none;">

              <div class = "part">

                 <a class = "nav_part" href = "'.HTTP.'/edit"><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/edit_info.png"><span id = "nav_user_privat"> Редактировать</span></a>

              </div>

              <div class = "part">

                 <a class = "nav_part" href = "'.HTTP.'/settings/"><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/settings.png"><span id = "nav_user_privat"> Настройки</span></a>

              </div>

              <div class = "part">

                 <a class = "nav_part" href = "'.HTTP.'/logout/?CK='.$user['CK'].'"><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/exit.png"><span id = "nav_user_privat"> Выйти</span></a>

              </div>

         </div>
  
         '.$err.'

         <div class = "block" style = "border: none">

             <form action = "" method = "POST">
     
                 <textarea name="msg"  placeholder = "Напишите в свой блог..."></textarea> <br />

                 <input type = "hidden" name = "access" value = "'.$accessBlog.'" />

                     <a href="'.HTTP.'/access-settings/?blog=1'.($accessBlog > 0 ? '&access='.$accessBlog.'' : '').'" class="adv_user_link" id="'.$accessBlogView.'" title="Доступ к записе"><span></span></a>

                     <a href="" class="adv_user_link" id="file_link" title="Прикрепить файл"><span></span></a>

                 <input id = "right" type="submit" value="Написать" name = "new_diary">

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />
 
             </form>

         </div>

';
         
 }
 else {

     echo '

         <div class = "block" style = "padding: 0; border: none; border-top: 1px solid #eee;">

              <div class = "part">

                 <a class = "nav_s" style = "border: none;" href = "'.HTTP.'/mail/?new&name='.$ank['login'].'"><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/i/new_mail.png"> <span class = "private_info">Написать</span></a>

              </div>

              <div class = "part">

                 <'.(User::friend ($user['id'], $ank['id']) == true ? 'div' : 'a').' class = "nav_'.(User::friend ($user['id'], $ank['id']) == true ? 'm' : 's').'" '.(User::friend ($user['id'], $ank['id']) == true ? '' : 'href = "'.HTTP.'/uid'.$user['id'].'/friends/?add='.$ank['id'].'"').'><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/'.(User::friend ($user['id'], $ank['id']) == true ? 'ok.png' : 'i/add_friend.png').'"> <span class = "private_info">'.(User::friend ($user['id'], $ank['id']) == true ? 'Дружите' : 'Дружить').'</span></'.(User::friend ($user['id'], $ank['id']) == true ? 'div' : 'a').'>

              </div>

              <div class = "part">

                 <a class = "nav_s" style = "border: none;" href = "'.HTTP.'/uid'.$ank['id'].'/gifts/new"><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/i/new_gift.png"> <span class = "private_info">Подарок</span></a>

              </div>

         </div>


     ';

 }

         echo '

         </div>

         ';

 $queryGifts = $DB -> query ("SELECT * FROM `user_gifts` WHERE `reply_id` = '".$ank['id']."' ORDER BY `time` DESC LIMIT 4");
   
 if ($queryGifts -> RowCount () > 0) {

     echo '

         <div class = "main_place">

             <div class="b-title b-title_first">

                 <a href = "'.HTTP.'/uid'.$ank['id'].'/gifts" class="b-title__link">

                     Подарки

                 </a>

             </div>

             <div class = "place">
             ';

     while ($gift = $queryGifts -> fetch ()) {

         $data = $DB -> query ("SELECT * FROM `gifts` WHERE `id` = '".$gift['gift_id']."'") -> fetch ();

         echo '

                 <a href = "'.HTTP.'/uid'.$ank['id'].'/gifts/id'.$gift['id'].'"><img src = "'.HTTP.'/files/gifts/40/'.$data['key'].'.'.$data['type'].'"></a>

         ';


     }

     echo '

             </div>

         </div>

     ';

 }


         echo '        

             <div class = "box">

             <div class = "block" style = "border: none;">


                 <div class = "part">

                     <a class = "act act_left">Профиль</a>

                     <span id = "t"></span>

                 </div>

                 <div class = "part">

                     <a href = "'.HTTP.'/uid'.$ank['id'].'/anketa" class = "no_act act_right">Анкета</a>

                 </div>

                 <div class = "part">

                     <a href = "/" class = "no_act act_right">Новости</a>

                 </div>

             </div>

             <a class = "home" href = "'.HTTP.'/uid'.$ank['id'].'/book">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/book.png">

                 Гостевая

                 <span class = "count_web">

                     <small>'.$countBook.'</small>

                 </span>

             </a>

             <a class = "home" href = "'.HTTP.'/uid'.$ank['id'].'/blog">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/blog.png">

                 Блог

                 <span class = "count_web">

                     <small>'.$countBlog.'</small>

                 </span>

             </a>

             <a class = "home" href = "'.HTTP.'/uid'.$ank['id'].'/friends">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/friends.png">

                 Друзья

                 <span class = "count_web">

                     <small>'.$countFriends.'</small>

                 </span>

             </a>

             <a class = "home-f" href = "'.HTTP.'/uid'.$ank['id'].'/pictures">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/pictures.png">

                 Фото

                 <span class = "count_web">

                     <small>'.$countPictures.'</small>

                 </span>

             </a>

             <a class = "home-f" href = "'.HTTP.'/uid'.$ank['id'].'/files">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/files.png">

                 Файлы

                 <span class = "count_web">

                     <small>'.$countFiles.'</small>

                 </span>

             </a>

             ';

             if ($user['id'] == $ank['id']) {

             echo '

             <a class = "home" href = "'.HTTP.'/bookmarks">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/fav.png">

                 Закладки

                 <span class = "count_web">

                     <small>'.$countBookmarks.'</small>

                 </span>

             </a>

             <a class = "home" href = "'.HTTP.'/authlog">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/auth_history.png">

                 История входов

             </a>

             ';

             }

         echo '

         </div>

             ';

     if ($user['id'] != $ank['id']) {

         echo '

         <div class = "main_place" style = "margin-top: 0px;">

             <div class = "block">

                 '.$bookmarks.'

                 <a href="" class="adv_user_link" id="complaint_link" title="Жалоба"><span></span></a></span>

             </div>

         </div>

         ';

     }

 echo '

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>
 
             '.$ank['login'].'

         </div>
 ';

 include_once ROOT.'/template/footer.php';

 ?>