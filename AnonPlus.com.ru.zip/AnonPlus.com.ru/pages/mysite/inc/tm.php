<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 $tm = Core::check ($_GET['auth']);

 $queryUser = $DB -> query ("SELECT `id`, `usid`, `tm`, `tc` FROM `users` WHERE `tm` = ".$DB -> quote ($tm)."");

 if ($queryUser -> RowCount () > 0) {

     if (isset ($_COOKIE['UID']) or isset ($_COOKIE['USID'])) {

         setcookie('UID', '', -1, '/');
         setcookie('USID', '', -1, '/');

     }

     $data = $queryUser -> fetch ();

     $DB -> query ("UPDATE `users` SET `online` = '".time()."' WHERE `id` = '".$data['id']."'");

     ## Ставим куки
     setcookie('UID', $data['id'], time()+86400*24, '/');
     setcookie('USID', $data['usid'], time()+86400*24, '/');

     $query = $DB -> prepare ("SELECT * FROM `users` WHERE `id` = ? and `usid` = ? LIMIT 1");
     $query -> execute (array($data['id'], $data['usid']));
     $query -> RowCount();
    
     if ($query > 0) $user = $query -> fetch();

     $id = $user['id'];

 }
 else Core::redirect ("Не верная автозакладка!", HTTP."/auth");

?>