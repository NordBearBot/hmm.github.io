<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $accessBlog = (int) (abs ($_POST['access']));
 $accessBlog = ($accessBlog < 0 or $accessBlog > 2) ? 0 : $accessBlog;

 if ($accessBlog == 1) $accessBlogView = 'friend_blog';
 else if ($accessBlog == 2) $accessBlogView = 'me_blog';
 else if ($accessBlog == 0) $accessBlogView = 'all_blog';

 if (isset ($_POST['new_diary'])) {

    $msg = Core::check ($_POST['msg']);
    $CK = (int) abs ($_POST['CK']);
    $blogSpam = $DB -> query ("SELECT `id` FROM `blogs` WHERE `user_id` = '".$user['id']."' AND `time` > '".$conf['spam_blog']."'") -> RowCount ();

    if (empty ($msg)) $err = '<div class = "err">Запись не должна быть пустой!</div>';
    else if (Core::utf_strlen ($mds) > 20000) $err = '<div class = "err">Блог должен содержать не больше 20000 символов!</div>';
    else if (!empty ($blogSpam)) $err = '<div class = "err">Не так быстро, подождите немного!</div>';
    else if ($CK != $user['CK']) $err = '<div class = "err">Не верый CK!</div>';

    if (empty ($err)) {

         $newBlog = $DB -> query ("INSERT INTO `blogs` SET
                                  `user_id` = '".$user['id']."',
                                  `message` = ".$DB -> quote ($msg).",
                                  `access` = '".$accessBlog."',
                                  `time` = '".time ()."'");

         $blog = $DB -> query ("SELECT `id` FROM `blogs` WHERE `user_id` = '".$user['id']."' ORDER BY `id` DESC LIMIT 1") -> fetch ();

         if ($accessBlog != 2) Core::lenta ($user['id'], $blog['id'], $msg, '/uid'.$user['id'].'/blog/?i='.$blog['id'].'', '1');

         Core::redirect_ok ("Запись создана!", HTTP."/uid".$user['id']."/blog/?i=".$blog['id']."");

    }
 }

?>