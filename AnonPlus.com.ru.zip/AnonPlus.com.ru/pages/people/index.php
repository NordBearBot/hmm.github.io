<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $c_p = $DB -> query ("SELECT `id`, `rating`, `data_registration` FROM `users` ORDER BY `online` DESC") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryUsers = $DB -> query ("SELECT `id`, `rating`, `data_registration` FROM `users` ORDER BY `online` DESC LIMIT $start, ".$p_page."");
 $countOnline = $DB -> query ("SELECT `id` FROM `users` WHERE `online` > '".$conf['user_online']."'") -> RowCount ();

 $description = 'Пользователи на '.DOMAIN;
 $keywords = NULL;
 $title = 'Пользователи';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Пользователи

         </div>
         
         <div class = "background_place">

         <div class = "main_place">

 ';

 Core:: Error ();

 if ($queryUsers -> RowCount () < 1) {

         echo '

         <div class = "block">

             Пользователей нету!

         </div>

         ';
 }
 else {
 
     echo '

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 Сейчас онлайн

                 <span class = "count_web">

                     '.$countOnline.'

                 </span>

             </a>

         </div>

     ';

     while ($ank = $queryUsers -> fetch ()) {

         echo '

         <a class = "home" href = "'.HTTP.'/uid'.$ank['id'].'">

             <div id = "avatar">

                 '.Core::avatar ($ank['id'], '40').'

             </div>

             <div id = "content">

             '.Core::user ($ank['id'], 1, 1, 0).' <span class = "count_web"><small>'.Core :: UserRating($ank['rating']).'</small></span>

             <br />

             <small>

                 '.Core::UserEnd ($ank['id']).'

                 <br />

                 <span class = "private_info">

                     '.Core::userSite ($ank['data_registration']).'

                 </span>  

             </small>

             </div>

        </a>

         ';

     }

      if ($k_page > 1) Core::str(''.HTTP.'/people/?', $k_page, $page);

 }

 echo '
         
         </div>

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Пользователи

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>