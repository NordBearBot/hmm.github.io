<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();
 if ($user['id'] != $_GET['id']) header ('Location:'.HTTP.'/uid'.$user['id'].'/files/?blocks');
 if (isset ($_GET['file'])) { include_once ROOT.'/pages/files/inc/block_file.php'; exit; }

 $c_p = $DB -> query ("SELECT * FROM `block_files` WHERE `user_id` = '".$user['id']."' AND `file_type` = 'files'") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryFiles = $DB -> query ("SELECT * FROM `block_files` WHERE `user_id` = '".$user['id']."' AND `file_type` = 'files' ORDER BY `id` DESC LIMIT $start, ".$p_page."");

 $title = $user['login'] .' / Файлы / Заблокированные';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/files">

                 Файлы

             </a>

             <span class = "ico next"></span>

             Заблокированные

         </div>
 ';

 Core:: Error ();
 Core:: Ok ();

 if ($queryFiles -> RowCount () < 1) echo '<div class = "place">Заблокированныех файлов нету</div>';
 else {

     while ($file = $queryFiles -> fetch ()) {

         echo '

             <div>

                 <a href="'.HTTP.'/uid'.$user['id'].'/files/?blocks&file='.$file['id'].'" class="list-link">
                
                     <div class="list-link__text">

                         '.files_methods::typeFile ($file['file_type_name']).' <b>'.$file['file_name'].'</b>.'.$file['file_type_name'].'

                     </div>
 
                 </a>

             </div>

         ';


     }

     if ($k_page > 1) Core::str(''.HTTP.'/uid'.$ank['id'].'/files/?blocks&', $k_page, $page); 

 }

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">

                 '.$ank['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'/files">

                 Файлы

             </a>

             <span class = "ico next"></span>

             Заблокированные

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>