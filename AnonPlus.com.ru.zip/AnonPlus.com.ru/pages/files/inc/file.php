<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
$queryFile = $DB -> query ("SELECT * FROM `files` WHERE `folder_id` = '".intval ( abs ($_GET['folder']))."' AND `id` = '".intval ( abs ($_GET['file']))."' AND `user_id` = '".intval (abs ($_GET['id']))."' LIMIT 1");

 if ($queryFile -> RowCount () < 1) {

    if ($user) Core::redirect ("Файл не существует!", HTTP."/uid".$user['id']."/files/");
    else Core::redirect ("Файл не существует!", HTTP."/err/");

 }
 else $file = $queryFile -> fetch ();

 $ank = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".$file['user_id']."'") -> fetch ();

 $queryTest = $DB -> query ("SELECT `id` FROM `bookmarks` WHERE `user_id` = '".$user['id']."' AND `type` = '3' AND `object_id` = '".$file['id']."'") -> RowCount ();
 $bookmarks = ($queryTest < 1) ? '<a href="'.HTTP.'/bookmarks/add/?type=3&id='.$file['id'].'" class="adv_user_link" id="bookmark_link" title="Добавить в закладки"><span></span></a>' : '<a href="'.HTTP.'/bookmarks/delete/?type=3&id='.$file['id'].'" class="adv_user_link" id="bookmark_link" title="Удалить из закладок"><span style="background-position: -32px -16px; !important;"></span></a>';

 $queryDownload = $DB -> query ("SELECT `id`, `folder_id` FROM `downloads_files` WHERE `file_id` = '".$file['id']."' AND `type` = 'files'");
 $toDownload = ($queryDownload -> RowCount () < 1) ? '<a href="'.HTTP.'/files/?add&file='.$file['id'].'" class="adv_user_link" id="toZO_link" title="В файлообменник"><span></span></a>' : '';

 if ($queryDownload -> RowCount () > 0) {

     $d_file = $queryDownload -> fetch ();
     $d_folder = $DB -> query ("SELECT `id`, `name`, `folder_id` FROM `downloads_folder` WHERE `id` = '".$d_file['folder_id']."'") -> fetch ();
     $d_folder2 = $DB -> query ("SELECT `id`, `name`, `folder_id` FROM `downloads_folder` WHERE `id` = '".$d_folder['folder_id']."'") -> fetch ();
     $d_folder3 = $DB -> query ("SELECT `id`, `name`, `folder_id` FROM `downloads_folder` WHERE `id` = '".$d_folder2['folder_id']."'") -> fetch ();   
     $d_folder4 = $DB -> query ("SELECT `id`, `name`, `folder_id` FROM `downloads_folder` WHERE `id` = '".$d_folder3['folder_id']."'") -> fetch ();

     $down_folder = '<br /> <a href = "'.HTTP.'/files/?folder='.$d_folder['id'].'" class = "private_info">Файлообменник / '.$d_folder4['name'].' '.(!empty ($d_folder4['id']) ? '/' : '').' '.$d_folder3['name'].' '.(!empty ($d_folder3['id']) ? '/' : '').' '.$d_folder2['name'].' / '.$d_folder['name'].'</a>';

 }

 $folder = $DB -> query ("SELECT `name`, `id`, `access` FROM `files_folder` WHERE `id` = '".$file['folder_id']."'") -> fetch ();
    
 if (isset($_GET['download']) and files_methods::dir_name ($file['type']) != 'pictures') {
    
     $DB -> query ("UPDATE `files` SET `download` = `download`+1 WHERE `id` = '".$file['id']."'");

     files_methods::download(ROOT.'/files/user.files/'.files_methods::dir_name ($file['type']).'/file'.$file['id'].'_'.$file['key_name_file'].'.'.$file['type']);
     exit();
 
 }

 if (files_methods::dir_name ($file['type']) == 'pictures') {

     ##  Обрабатываем просмотр

     if ($user) {

         $testView = $DB -> query ("SELECT `id` FROM `count_view` WHERE `type` = 'file' and `user_id` = '".$user['id']."' and `object_id` = '".$file['id']."'") -> RowCount ();

         if ($testView == 0) {

             Core::count_view ('file', $file['id']);

             $DB -> query ("UPDATE `files` SET `download` = `download`+1 WHERE `id` = '".$file['id']."'");

             header ('Location: '.HTTP.'/uid'.$ank['id'].'/files/?folder='.$folder['id'].'&file='.$file['id']);

         }

     }

 }

 $queryAccessForler = $DB -> query ("SELECT `id` FROM `friends` WHERE `user_id` = '".$ank['id']."' AND `friend_id` = '".$user['id']."'");
 if ($folder['access'] == 1 and $ank['id'] != $user['id'] and $queryAccessForler -> RowCount () < 1) Core::redirect ("Доступ к этой папке имеют только друзья пользователя!", HTTP."/uid".$ank['id']."/pictures/");

 if ($folder['access'] == 2 and $user['id'] != $ank['id']) Core::redirect ("Доступ к этой папке закрыт автором!", HTTP."/uid".$ank['id']."/pictures/");
 
 if ($user and isset ($_GET['journal'])) User::journal_update ($_GET['journal'], $user['id']);

 ## Полное название файла
 $fileName = $file['name'].'.'.$file['type'];

 ## Пагинация для комментариев
 $c_p = $DB -> query ("SELECT * FROM `files_comments` WHERE `file_id` = '".$file['id']."'") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryComments = $DB -> query ("SELECT * FROM `files_comments` WHERE `file_id` = '".$file['id']."' ORDER BY `id` DESC LIMIT $start, ".$p_page."");
 $queryCommentsFix = $DB -> query ("SELECT * FROM `files_comments` WHERE `file_id` = '".$file['id']."'") -> RowCount ();

 if (isset ($_POST['comment'])) {

     Core::CheckUser ();

     $message = Core::check ($_POST['message']);
     $CK = (int) abs ($_POST['CK']);

     if ($CK == $user['CK']) {

         if (empty ($message)) $err = '<div class = "err">Введите комментарий!</div>';
         else {

             if (strlen($message) > 3000) $err = '<div class = "err">Комментарий не должен превышать 3000 символов!</div>';
             else {

                 $queryAddComment = $DB -> query ("INSERT INTO `files_comments` SET
                                                  `file_id` = '".$file['id']."',
                                                  `user_id` = '".$user['id']."',
                                                  `reply_id` = '0',
                                                  `message` = ".$DB -> quote ($message).",
                                                  `time` = '".time ()."'");

                 if ($user['id'] != $ank['id']) User::journal_add ($user['id'], $ank['id'], $message, 4, '/uid'.$ank['id'].'/files/?folder='.$file['folder_id'].'&file='.$file['id'].'');

                 header ('Location: '.HTTP.'/uid'.$ank['id'].'/files/?folder='.$folder['id'].'&file='.$file['id'].'');

             }

         }
     
     }
     else Core::redirect ("Не верный CK!", HTTP."/uid".$ank['id']."/files/?folder=".$folder['id']."&file=".$pic['id']."");

 }

 $description = $ank['login'].' / Файлы / '.$fileName;
 $keywords = NULL;
 $title = $ank['login'].' / Файлы / '.$fileName;

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>
             <a href = "'.HTTP.'/uid'.$ank['id'].'/files/">Файлы</a>

         </div>

 ';

 if (!empty ($folder)) { 

 echo '        

         <div class = "nav">

             ← <a href = "'.HTTP.'/uid'.$ank['id'].'/files/?folder='.$folder['id'].'">'.$folder['name'].'</a>

         </div>

 ';

}

 Core:: Error ();
 Core:: Ok ();

 echo '

         <div class = "block">

             '.files_methods::typeFile ($file['type']).' <b>'.$file['name'].'</b>.'.$file['type'].'

             '.($file['consored'] == 1 ? '<img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/adult_ico.png">' : '').'

             <br />

             '.(files_methods::dir_name ($file['type']) == 'pictures' ? '<span class = "transform_pic"><img style = "max-width: 200px; max-height: 200px;" src = "'.HTTP.'/files/user.files/pictures/256/photo'.$file['id'].'_'.$file['key_name_file'].'.'.$file['type'].'"></span><br />' : '').'

             '.$file['description'].'

         </div>

         <div class = "nav">

             <img src = "'.HTTP.'/files/system.images/site.icons/load.gif">

             <a href = "'.(files_methods::dir_name ($file['type']) == 'pictures' ? HTTP.'/files/user.files/pictures/photo'.$file['id'].'_'.$file['key_name_file'].'.'.$file['type'] : HTTP.'/uid'.$file['user_id'].'/files/?folder='.$file['folder_id'].'&file='.$file['id'].'&download').'">

                 Скачать
             
             </a>

             <small>

                 ('.files_methods::filesize_get (ROOT.'/files/user.files/'.files_methods::dir_name ($file['type']).'/'.(files_methods::dir_name ($file['type']) == 'pictures' ? 'photo' : 'file').''.$file['id'].'_'.$file['key_name_file'].'.'.$file['type']).')

             </small>

         </div>

         <div class = "block">

             '.(files_methods::dir_name ($file['type']) == 'pictures' ? 'Просмотров' : 'Закачек').' <span class = "count_web">'.$file['download'].'</span>

             <br />

             Файл добавлен: '.Core::user ($ank['id'], 0, 1, 1).' ('.Core::date_time ($file['time']).')

             <br />

             В папку: '.($folder['id'] == 0 ? '<img src = "'.HTTP.'/files/system.images/folder.type/folder.gif"> <a href = "'.HTTP.'/uid'.$ank['id'].'/files/">Файлы</a>' : '<img src = "'.HTTP.'/files/system.images/folder.type/folder.gif"> <a href = "'.HTTP.'/uid'.$ank['id'].'/files/?folder='.$folder['id'].'">'.$folder['name'].'</a>').'

             '.$down_folder.'

         </div>

         '.(($user['level'] == 1 or $user['level'] == 3) ? '<a class = "home" href = "'.HTTP.'/files/?ban_file='.$file['id'].'&type=1">Бан</a>' : '').'

         <div class = "block">

             '.$bookmarks.'

             '.(($user['id'] == $file['user_id'] and $folder['access'] == 0) ? $toDownload : '').'

         </div>
 ';

 if ($queryComments -> RowCount () < 1) {

     echo '

         <div class = "block">

             Комментарии отсуствуют

         </div>

     ';

 }
 else {

     echo '

         <div class = "nav">

             Комментариев <span class = "count">'.$queryCommentsFix.'</span>

         </div>

     ';

     while ($comment = $queryComments -> fetch ()) {

         echo '

         <div class = "block">

             <div id = "avatar">

                 '.Core::avatar ($comment['user_id'], 40).'

             </div>

             <div id = "content">

                 '.Core::user ($comment['user_id'], 1, 1, 1).'

                 <small id = "right">

                     '.Core::date_time ($comment['time']).'

                 </small>

                 <br />

                 '.Core::bb ($comment['message']).'

             </div>

         </div>

         ';

     }

 if ($k_page > 1) Core::str(''.HTTP.'/uid'.$ank['id'].'/files/?folder='.$folder['id'].'&file='.$file['id'].'&', $k_page, $page);

 }

 echo '

         '.$err.'

         <div class = "nav">

             <form action = "" method = "POST">

                 <textarea name="message"  placeholder = "Оставить комментарий...">'.(isset ($_POST['comment']) ? $message : '').'</textarea>

                 <br />

                 <input type = "submit" name = "comment" value = "Написать"/>

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

             </form>

         </div>

 ';

 if (!empty ($folder)) { 

 echo '        
         <div class = "block"></div>

         <div class = "nav">

             ← <a href = "'.HTTP.'/uid'.$ank['id'].'/files/?folder='.$folder['id'].'">'.$folder['name'].'</a>

         </div>

 ';

}

echo '
       <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>
             <a href = "'.HTTP.'/uid'.$ank['id'].'/files/">Файлы</a>

         </div>

 ';

 include_once ROOT.'/template/footer.php';

?>