<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $queryUser = $DB -> query ("SELECT `id`, `login` FROM `users` WHERE `id` = '".intval( abs ($_GET['id']))."'");
 
 if ($queryUser -> RowCount () < 1) {

    if ($user) Core::redirect ("Пользователь не существует!", HTTP."/uid".$user['id']."/files/");
    else Core::redirect ("Пользователь не существует!", HTTP."/people/");

 }
 else $ank = $queryUser -> fetch ();
 
 if (isset ($_GET['blocks'])) { include_once ROOT.'/pages/files/inc/blocks.php'; exit; }

 $queryFolder = $DB -> query ("SELECT * FROM `files_folder` WHERE `user_id` = '".$ank['id']."' AND `folder_id` = '0'");
 $queryFiles = $DB -> query ("SELECT * FROM `files` WHERE `folder_id` = '0' AND `user_id` = '".$ank['id']."'");

 if ($user and $user['id'] == $ank['id']) if (isset ($_GET['upload'])) { include_once ROOT.'/pages/files/inc/upload_file.php'; exit; }
 if ($user and $user['id'] == $ank['id']) if (isset ($_GET['new_folder'])) { include_once ROOT.'/pages/files/inc/new_folder.php'; exit; }
 if (isset ($_GET['folder']) and !isset ($_GET['file'])) { include_once ROOT.'/pages/files/inc/folder.php'; exit; }
 if (isset ($_GET['folder']) and isset ($_GET['file'])) { include_once ROOT.'/pages/files/inc/file.php'; exit; }

 $description = $ank['login'].' / Файлы';
 $keywords = NULL;
 $title = $ank['login'].' / Файлы';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>
             Файлы

         </div>
 ';

 Core:: Error ();
 Core:: Ok ();

 while ($folder = $queryFolder -> fetch ()) {

         echo '

             <a class = "home" href = "'.HTTP.'/uid'.$ank['id'].'/files/?folder='.$folder['id'].'">

                 '.($folder['access'] == 0 ? '<img src="'.HTTP.'/files/system.images/folder.type/folder.gif" title="Доступен всем">' : '').'
                 '.($folder['access'] == 1 ? '<img src="'.HTTP.'/files/system.images/folder.type/dir_friends.png" title="Доступен друзьям">' : '').'
                 '.($folder['access'] == 2 ? '<img src="'.HTTP.'/files/system.images/folder.type/dir_locked.png" title="Доступен автору">' : '').'

                 '.$folder['name'].'

                 <span class = "count_web">

                     '.$folder['count'].'

                 </span>

             </a>

         ';


 }

 while ($file = $queryFiles -> fetch ()) {

         echo '
             
             <div>

                 <a href="'.HTTP.'/uid'.$file['user_id'].'/files/?folder='.$file['folder_id'].'&file='.$file['id'].'" class="list-link">
                
                     <div class="list-link__text">

                         '.files_methods::typeFile ($file['type']).' <b>'.$file['name'].'</b>.'.$file['type'].'

                         '.($file['consored'] == 1 ? '<img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/adult_ico.png">' : '').'

                         <br>

                         <span class="private_info">

                             '.Core::CropStr ($file['description'], 100).'

                         </span>

                     </div>
 
                 </a>

             </div>

         ';


 }
 
 if ($queryFiles -> RowCount () == 0 and $queryFolder -> RowCount () == 0) echo '<div class = "block">Файлов нет</div>';

 if ($user && $user['id'] == $ank['id']) {

     $queryMaxFolder = $DB -> query ("SELECT `id` FROM `pictures_folder` WHERE `id` = '0'");

    echo '

         <div class = "block" style = "border: none;"></div>

         <a class="nav_part" href = "'.HTTP.'/uid'.$user['id'].'/files/?upload" style = "text-align: left;">

             <img src = "'.HTTP.'/files/system.images/site.icons/download.png">

             Загрузить файл

         </a>

    ';
    
     if ($queryMaxFolder -> RowCount () < 16) {

        echo '
         <a class="nav_part" href = "'.HTTP.'/uid'.$user['id'].'/files/?new_folder" style = "text-align: left;">

             <img src = "'.HTTP.'/files/system.images/site.icons/add_folder.png">

             Создать папку

         </a>
         ';
     }

}

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$ank['id'].'">'.$ank['login'].'</a>

             <span class = "ico next"></span>
             Файлы

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>