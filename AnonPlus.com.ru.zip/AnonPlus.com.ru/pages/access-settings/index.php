<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 
 Core::CheckUser ();

 if (isset ($_GET['i'])) {

     $id = (int) abs ($_GET['i']);
     $queryBlog = $DB -> query ("SELECT `id`, `access` FROM `blogs` WHERE `id` = '".$id."' AND `user_id` = '".$user['id']."'");
     
     if ($queryBlog -> RowCount () < 1) Core::redirect ("Вы не имеете доступ к этой записе!", HTTP."/uid".$user['id']."/blog");
     $blog = $queryBlog -> fetch ();

     $access = $blog['access'];

     $act = 'blog/?i='.$blog['id'].'&edit';

 }
 else {

     $access = intval (abs ($_GET['access']));
     $access = ($access < 0 or $access > 2) ? 0 : $access;

     $act = ($_GET['blog'] != 1 ? 'blog/?' : '?').'new_blog';

 }



 $all_check = ($access == 0) ? 'checked="checked"' : '';
 $friend_check = ($access == 1) ? 'checked="checked"' : '';
 $me_check = ($access == 2) ? 'checked="checked"' : '';

 $description = NULL;
 $keywords = NULL;
 $title = 'Блог / Доступ к записе';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/blog/">Блог</a>

             <span class = "ico next"></span>

             Доступ к записе

         </div>
 ';

 echo '

         <div class = "block" style = "border: none;">

             Кто видит запись:

         </div>

         <form action = "'.HTTP.'/uid'.$user['id'].'/'.$act.'" method = "POST">

             <input type="hidden" name="CK" value="'.$user['CK'].'" />

             <div>
             
                <label for="access_link" class="block_touch">

                     <input type="radio" name="access" id="access_link" value="0" '.$all_check.' />

                     <img src = "'.HTTP.'/files/system.images/status.data/access_all.png"> &nbsp;Все

                </label>

             </div>

             <div>
             
                <label for="access_link2" class="block_touch">

                     <input type="radio" name="access" id="access_link2" value="1" '.$friend_check.' />

                     <img src = "'.HTTP.'/files/system.images/status.data/access_friends.png"> &nbsp;Мои друзья

                </label>

             </div>

             <div>
             
                <label for="access_link3" class="block_touch">

                     <input type="radio" name="access" id="access_link3" value="2" '.$me_check.' />

                     <img src = "'.HTTP.'/files/system.images/status.data/access_me.png"> &nbsp;Только Я

                </label>

             </div>

             <div class = "block">

                 <input type = "submit" name = "save" value = "ОК">

             </div>

         </form>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/blog/">Блог</a>
             
             <span class = "ico next"></span>

             Доступ к записе

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>