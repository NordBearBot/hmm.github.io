<?php

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $type = (int) abs ($_GET['type']);
 $type = ($type > 4) ? 2 : $type;
 $id = (int) abs ($_GET['id']);

 $section_table = ($type == 0 ? 'blogs' : ($type == 1 ? 'pictures' : ($type == 2 ? 'users' : ($type == 3 ? 'files' : ($type == 4 ? 'forum_themes' : 'users')))));
 $queryObject = $DB -> query ("SELECT * FROM `".$section_table."` WHERE `id` = '".$id."' LIMIT 1");

 if ($queryObject -> RowCount () < 1) Core::redirect ("Обьект не существует!", HTTP."/bookmarks");
 $object = $queryObject -> fetch ();

 $queryTest = $DB -> query ("SELECT `id` FROM `bookmarks` WHERE `user_id` = '".$user['id']."' AND `type` = '".$type."' AND `object_id` = '".$id."'") -> RowCount ();
 if ($queryTest > 0) Core::redirect ("Вы уже добавили этот обьект ранее!", HTTP."/bookmarks");

 if (isset ($_POST['add'])) {

     $CK = (int) $_POST['CK'];
     if ($CK == $user['CK']) {

        $DB -> query ("INSERT INTO `bookmarks` SET `user_id` = '".$user['id']."', `type` = '".$type."', `object_id` = '".$object['id']."', `time` = '".time ()."'");
        Core::redirect_ok ("Обьект добавлен в ваши закладки", HTTP."/bookmarks");

     }
     else Core::redirect ("Не верный CK!", HTTP."/bookmarks/add/?type=".$type."&id=".$id);

 }

 $description = NULL;
 $keywords = NULL;
 $title = $user['login'].' / Закладки / Добавить в Закладки';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/bookmarks/">Закладки</a>

             <span class = "ico next"></span>

             Добавить в Закладки

         </div>
 ';

 Core:: Ok ();
 Core:: Error ();

 if ($type == 2) {

     echo '
         
         <div class = "block">

             <div id = "avatar">

                 '.Core::avatar ($object['id'], 40).'

             </div>

             <div id = "content">

                 '.Core::user ($object['id'], 1, 1, 1).'

                 <span class = "count_web">'.$object['rating'].'</span>

                 <br />

                 <small class = "private_info">

                     Регистрация: '.Core::date_time ($object['data_registration']).'

                 </small>

             </div>

         </div>

     ';

 }
 else if ($type == 0) {

     echo '
         
         <div class = "block">

             '.Core::user ($object['user_id'], 1, 1, 1).'

             <br /> 

             <span class = "private_info">

                 '.Core::CropStr ($object['message'], 200).'

             </span>

         </div>

     ';

 }
 else if ($type == 1) {

     echo '

         <div class = "block">

             '.Core::user ($object['user_id'], 1, 1, 1).'

             <br />

             '.files_methods::typeFile ($object['type']).' <b>'.$object['name'].'</b>.'.$object['type'].'

         </div>

     ';

 }
 else if ($type == 3) {

     echo '

         <div class = "block">

             '.Core::user ($object['user_id'], 1, 1, 1).'

             <br />

             '.files_methods::typeFile ($object['type']).' <b>'.$object['name'].'</b>.'.$object['type'].'

         </div>

     ';

 }
 else if ($type == 4) {

     echo '
         
         <div class = "block">

             '.Core::user ($object['user_id'], 1, 1, 1).'

             <br />

             Форум:  

             <span class = "private_info">

                 '.$object['name'].'

             </span>

         </div>

     ';

 }

 echo '

         <div class = "block">

             <form action = "" method = "POST">

                 <input type = "submit" name = "add" value = "Добавить" />

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

             </form>

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/bookmarks/">Закладки</a>

             <span class = "ico next"></span>

             Добавить в Закладки

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>