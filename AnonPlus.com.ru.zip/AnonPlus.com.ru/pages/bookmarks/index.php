<?php

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $queryBookmarks = $DB -> query ("SELECT * FROM `bookmarks` WHERE `user_id` = '".$user['id']."' ORDER BY `id` DESC");

 $description = NULL;
 $keywords = NULL;
 $title = $user['login'].' / Закладки';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>

             <span class = "ico next"></span>

             Закладки

         </div>
 ';

 Core:: Ok ();
 Core:: Error ();

 if ($queryBookmarks -> RowCount () < 1) echo '<div class = "block">Закладок нет</div>';
 else {

     while ($object = $queryBookmarks -> fetch ()) {

         $section_table = ($object['type'] == 0 ? 'blogs' : ($object['type'] == 1 ? 'pictures' : ($object['type'] == 2 ? 'users' : ($object['type'] == 3 ? 'files' : ($object['type'] == 4 ? 'forum_themes' : 'users')))));
         $data = $DB -> query ("SELECT * FROM `".$section_table."` WHERE `id` = '".$object['object_id']."'") -> fetch ();

         if ($object['type'] == 0) {

         echo '
         
         <div class = "block">

             '.Core::user ($data['user_id'], 1, 1, 1).'

             <span id = "right" class = "private_info">

                 <small>'.Core::date_time ($object['time']).'</small>

             </span>

             <br /> 

             <span class = "private_info">

                 <a class = "text_link_bm" href = "'.HTTP.'/uid'.$data['user_id'].'/blog/?i='.$data['id'].'">'.Core::CropStr (Core::without_bb($data['message']), 200).'</a>

             </span>

         </div>

         ';

         }
         else if ($object['type'] == 1) {

         echo '
         
         <div class = "block">

             '.Core::user ($data['user_id'], 1, 1, 1).'

             <span id = "right" class = "private_info">

                 <small>'.Core::date_time ($object['time']).'</small>

             </span>

             <br /> 

             <span class = "private_info">

                 '.files_methods::typeFile ($data['type']).' <a class = "text_link_bm" href = "'.HTTP.'/uid'.$data['user_id'].'/pictures/?folder='.$data['folder_id'].'&pic='.$data['id'].'">'.$data['name'].'.'.$data['type'].'</a>

             </span>

         </div>

         ';

         }
         else if ($object['type'] == 2) {

         echo '
         
         <div class = "block">

             '.Core::user ($data['id'], 1, 1, 1).'

             <span class = "count_web">'.Core::UserRating ($data['rating']).'</span>

             <span id = "right" class = "private_info">

                 <small>'.Core::date_time ($object['time']).'</small>

             </span>

             <br />

             <small class = "private_info">

                 Регистрация: '.Core::date_time ($data['data_registration']).'

             </small>

         </div>

         ';

         }
         else if ($object['type'] == 3) {

         echo '
         
         <div class = "block">

             '.Core::user ($data['user_id'], 1, 1, 1).'

             <span id = "right" class = "private_info">

                 <small>'.Core::date_time ($object['time']).'</small>

             </span>

             <br /> 

             <span class = "private_info">

                 '.files_methods::typeFile ($data['type']).' <a class = "text_link_bm" href = "'.HTTP.'/uid'.$data['user_id'].'/files/?folder='.$data['folder_id'].'&file='.$data['id'].'">'.$data['name'].'.'.$data['type'].'</a>

             </span>

         </div>

         ';

         }
         else if ($object['type'] == 4) {

         $sub = $DB -> query ("SELECT `section_id`, `id` FROM `forum_subsection` WHERE `id` = '".$data['subsection']."'") -> fetch ();
         $sect = $DB -> query ("SELECT `id` FROM `forum_section` WHERE `id` = '".$sub['section_id']."'") -> fetch ();

         echo '
         
         <div class = "block">

             '.Core::user ($data['user_id'], 1, 1, 1).'

             <span id = "right" class = "private_info">

                 <small>'.Core::date_time ($object['time']).'</small>

             </span>

             <br /> 

             <span class = "private_info">

                 <a class = "text_link_bm" href = "'.HTTP.'/forum/?section='.$sect['id'].'&sub='.$sub['id'].'&theme='.$data['id'].'">Форум: '.Core::without_bb($data['name']).'</a>

             </span>

         </div>

         ';

         }

     }




 }
 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>

             <span class = "ico next"></span>

             Закладки

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>