﻿<?php

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $c_p = $DB -> query ("SELECT * FROM `history_auth` WHERE `user_id` = '".$user['id']."'") -> RowCount ();

        if (isset($user)) $p_page = $user['count_page'];
        else $p_page = '7';
        $k_page = Core::k_page($c_p, $p_page);
        $page = Core::page($k_page);
        $start = $p_page*$page-$p_page;

 $queryAuthLog = $DB -> query ("SELECT * FROM `history_auth` WHERE `user_id` = '".$user['id']."' ORDER BY `time` DESC LIMIT $start, ".$p_page."");

 $title = $user['login'].' / История входов';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>

             <span class = "ico next"></span>

             История входов

         </div>

         <div class = "background_place">

         <div class="b-title b-title_first">

             <a class="b-title__link">

                 ВХОДЫ

             </a>

         </div>

         <div class = "main_place">

             <div class = "place">

                 Здесь вы сможете проверить, не заходил ли кто-то чужой под вашим ником!

             </div>

         </div>
 ';

 while ($auth = $queryAuthLog -> fetch ()) {

     echo '

         <div class = "main_place">

             <div class = "place">

                 <span class = "private_info">

                     <small>

                         Дата: <b>'.Core::date_time ($auth['time']).'</b>

                         <br />

                         IP-адрес: <b>'.$auth['ip'].'</b>

                         <br />

                         Browser: <b>'.$auth['ua'].'</b>

                     </small>

                 </span>

             </div>

         </div>

     ';

 }

 echo '
         </div>

 ';

 if ($k_page > 1) Core::str(''.HTTP.'/authlog/?', $k_page, $page);

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">'.$user['login'].'</a>

             <span class = "ico next"></span>

             История входов

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>