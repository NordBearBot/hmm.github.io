<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $queryUserAnketa = $DB -> query ("SELECT * FROM `user_anketa` WHERE `user_id` = '".$user['id']."'");

 if ($queryUserAnketa -> RowCount () < 1) $DB -> query ("INSERT INTO `user_anketa` SET `user_id` = '".$user['id']."'");
 $ank = $queryUserAnketa -> fetch ();

 $section = (int) abs ($_GET['section']);

 $all = (empty ($section)) ? '<span id = "t"></span>' : '';
 $dating = ($section == 1) ? '<span id = "t"></span>' : '';
 $interests = ($section == 2) ? '<span id = "t"></span>' : '';

 $link_all = (empty ($section)) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/edit/?" class = "no_act act_l_b act_r_b">';
 $link_dating = ($section == 1) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/edit/?section=1" class = "no_act act_l_b act_r_b">';
 $link_interests = ($section == 2) ? '<a class = "act act_left">' : '<a href = "'.HTTP.'/edit/?section=2" class = "no_act act_l_b act_r_b">';

 $description = NULL;
 $keywords = NULL;
 $title = $user['login'].' / Анкета / Редактирование';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/anketa/">

                 Анкета

             </a>

         </div>

         <div class = "nav">

             Редактирование

         </div>
 ';

 Core::Error ();
 Core::Ok ();
 echo '

             <div class = "block">

                 '.User::avatar ($user['id'], 128).'

                 <br />

                 <a href = "'.HTTP.'/edit/avatar/">

                     Изменить фотографию

                 </a>

             </div>

         <div class = "block" style = "border: none; padding-bottom: 0px;">

             <div class = "part">

                 '.$link_all.' Основное </a>

                 '.$all.'

             </div>

             <div class = "part">

                  '.$link_dating.' Знакомства </a>

                 '.$dating.'

             </div>

             <div class = "part">

                 '.$link_interests.' Интересы </a>

                 '.$interests.'

             </div>

         </div>

         ';

 if (empty ($section)) {

 if (isset ($_POST['save'])) {
  
  if ($_POST['CK'] == $user['CK']) {

    $userName = Core::check ($_POST['user_name']);
    $userSex = intval(abs ($_POST['user_sex']));
    $userDating = intval(abs ($_POST['user_dating']));

    $day = Core::check ($_POST['user_day']);
    $month = Core::check ($_POST['user_month']);
    $year = Core::check ($_POST['user_year']);

    if (strlen($userName) > 30) $err_name = '<br /> <small style = "color: darkred;">Имя не должно превышать 30 символов!</small>';
    else {

        $userSex = ($userSex < 0 or $userSex > 1) ? $user['sex'] : $userSex;


        if (empty ($err_name) && Core::utf_strlen($day) > 1 && Core::utf_strlen($month) > 1 && $day > 0 && $day < 32 && $month > 0 && $month < 13 && $year > 1949 && $year < 2010 || $day.$month.$year == NULL) {
        
             $age = (!empty ($year)) ? date ('Y') - $year -1 : NULL;
    
             $DB -> query ("UPDATE `user_anketa` SET 
                           `name` = ".$DB -> quote ($userName).",
                           `day` = ".$DB -> quote ($day).",
                           `month` = ".$DB -> quote ($month).",
                           `year` = ".$DB -> quote ($year).",
                           `age` = '".intval (abs ($age))."'
                           WHERE `user_id` = '".$user['id']."'");  

             $DB -> query ("UPDATE `users` SET `sex` = '".$userSex."' WHERE `id` = '".$user['id']."'");

             Core::redirect_ok ("Изменения сохранены", HTTP."/edit");

        }
        else $err_date = '<br /> <small style = "color: darkred;">Не правильно введена дата рождения!</small>';
    }

  } else Core::redirect ("Не верный CK!", HTTP."/edit");

 }

 $check = ($user['sex'] == 0) ? 'checked = "checked"' : NULL;
 $check2 = ($user['sex'] == 1) ? 'checked = "checked"' : NULL;

 echo '
             <form action = "" method = "POST">

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

                 <div class = "block">

                     Имя:

                     <br />

                     <input type = "text" name = "user_name" value = "'.$ank['name'].'">

                     '.$err_name.'

                 </div>

                 <div class = "block">

                     Пол:

                     <br />

                     <input type="radio" name="user_sex" value="0" '.$check.' /> <font color = "#066">Мужской</font>

                     <br />

                     <input type="radio" name="user_sex" value="1" '.$check2.' /> <font color = "#79358C">Женский</font>

                 </div>

                 <div class = "block">

                     Дата рождения:

                     <br />

                     День: <input type = "text" size = "2" value = "'.$ank['day'].'" name = "user_day">
                     Месяц: <input type = "text" size = "2" value = "'.$ank['month'].'" name = "user_month">
                     Год: <input type = "text" size = "2" value = "'.$ank['year'].'" name = "user_year">
                     
                     '.$err_date.'

                 </div>

                 <div class = "block">

                     Город, регион, страна:

                     <a href = "'.HTTP.'/edit/selection/">

                         '.(empty ($ank['country']) ? 'Выбрать' : $ank['country'].', '.$ank['city'].', '.$ank['region']).'

                     </a>

                 </div>

                 <div class = "block">

                     <input type = "submit" name = "save" value = "Сохранить">

                 </div>

             </form>

 ';

 }
 else if ($section == 1) {

     $checkDating = ($user['dating'] == 1) ? 'checked = "checked"' : NULL;
     $checkDating2 = ($user['dating'] == 0) ? 'checked = "checked"' : NULL;

     $checkType = ($user['userType'] == 0) ? 'checked = "checked"' : NULL;  
     $checkType2 = ($user['userType'] == 1) ? 'checked = "checked"' : NULL;  
     $checkType3 = ($user['userType'] == 2) ? 'checked = "checked"' : NULL;  
     $checkType4 = ($user['userType'] == 3) ? 'checked = "checked"' : NULL;  

     if (isset ($_POST['save'])) {

         $partner = Core::check ($_POST['partner']);
         $CK = (int) abs ($_POST['CK']);
         $dating = (int) abs ($_POST['user_dating']);
         $type = (int) abs ($_POST['user_type']);

         $dating = ($dating < 0 or $dating > 1) ? $user['dating'] : $dating;
         $type = ($type < 0 or $type > 3) ? $user['userType'] : $type;

         if ($CK == $user['CK']) {

         if (strlen ($partner) > 500) $err = '<br /> <small style = "color: darkred;">Текст не должен превышать 500 символов!</small>';
         else {

             $DB -> query ("UPDATE `users` SET `dating` = '".$dating."', `userType` = '".$type."' WHERE `id` = '".$user['id']."'");
             $DB -> query ("UPDATE `user_anketa` SET `partner` = ".$DB -> quote ($partner)." WHERE `user_id` = '".$user['id']."'");

             Core::redirect_ok ("Изменения сохранены", HTTP."/edit/?section=1");

         }

         }
         else Core::redirect ("Не верный CK!", HTTP."/edit/?section=1");

     }

     echo '
             <form action = "" method = "POST">

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

                 <div class = "block">

                     Показывать анкету в знакомствах:

                     <br />

                     <input type="radio" name="user_dating" value="1" '.$checkDating.' /> Да

                     <br />

                     <input type="radio" name="user_dating" value="0" '.$checkDating2.' /> Нет

                 </div>

                 <div class = "block">

                     Ориентация:

                     <br />

                     <input type="radio" name="user_type" value="0" '.$checkType.' /> Гетеро

                     <br />

                     <input type="radio" name="user_type" value="1" '.$checkType2.' /> Гей

                     <br />

                     <input type="radio" name="user_type" value="2" '.$checkType3.' /> Би

                     <br />

                     <input type="radio" name="user_type" value="3" '.$checkType4.' /> Не отображать

                 </div>

                 <div class = "block">

                     О желаемом партнере:

                     <br />

                     <textarea name="partner"  placeholder = "Писать тут!...">'.(isset ($partner) ? $partner : $ank['partner']).'</textarea>

                     '.$err.'

                 </div>

                 <div class = "block">

                     <input type = "submit" name = "save" value = "Сохранить">

                 </div>

             </form>
             ';
 }
 else if ($section == 2) {

     if (isset ($_POST['save'])) {

         $me = Core::check ($_POST['me']);
         $interests2 = Core::check ($_POST['interests']);
         $music = Core::check ($_POST['music']);

         $CK = (int) abs ($_POST['CK']);

         if ($CK == $user['CK']) {

         $err = (strlen ($me) > 500) ? '<br /> <small style = "color: darkred;">Текст не должен превышать 500 символов!</small>' : NULL;
         $err2 = (strlen ($interests2) > 500) ? '<br /> <small style = "color: darkred;">Текст не должен превышать 500 символов!</small>' : NULL;   
         $err3 = (strlen ($music) > 500) ? '<br /> <small style = "color: darkred;">Текст не должен превышать 500 символов!</small>' : NULL;  

         if (empty ($err) and empty ($err2) and empty ($err3)) {

             $DB -> query ("UPDATE `user_anketa` SET `me` = ".$DB -> quote ($me).", `interests` = ".$DB -> quote ($interests2).", `music` = ".$DB -> quote ($music)." WHERE `user_id` = '".$user['id']."'");

             Core::redirect_ok ("Изменения сохранены", HTTP."/edit/?section=2");

         }

         }
         else Core::redirect ("Не верный CK!", HTTP."/edit/?section=2");

     }

     echo '
             <form action = "" method = "POST">

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

                 <div class = "block">

                     О себе:

                     <br />

                     <textarea name="me"  placeholder = "Расскажите о себе...">'.(isset ($me) ? $me : $ank['me']).'</textarea>

                     '.$err.'

                 </div>

                 <div class = "block">

                     Интересы:

                     <br />

                     <textarea name="interests"  placeholder = "Что вам интересно?">'.(isset ($interests2) ? $interests2 : $ank['interests']).'</textarea>

                     '.$err2.'

                 </div>

                 <div class = "block">

                     Любимая музыка:

                     <br />

                     <textarea name="music"  placeholder = "Что вам интересно?">'.(isset ($music) ? $music : $ank['music']).'</textarea>

                     '.$err3.'

                 </div>

                 <div class = "block">

                     <input type = "submit" name = "save" value = "Сохранить">

                 </div>

             </form>
     ';

 }

 echo '
         <div class = "nav">

             Редактирование

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/anketa/">

                 Анкета

             </a>

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>