<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 ## Фильтрируем данные
 $pic = intval( abs ($_GET['pic']));
 $folder = intval( abs ($_GET['folder']));
 $CK = intval( abs ($_GET['CK']));

 ## Только если верный CK
 if ($CK == $user['CK']) {
     
     ## Проверяем пренадлежит ли файл юзеру и существует ли он вообще
     $queryTestPic = $DB -> query ("SELECT `id`, `key_name_file`, `folder_id`, `type` FROM `pictures` WHERE `id` = '".$pic."' AND `folder_id` = '".$folder."' AND `user_id` = '".$user['id']."' LIMIT 1");
     
     ## Если есть совпадение
     if ($queryTestPic -> RowCount () > 0) {

         ## Если фото в папке
         if ($folder != 0) {

             ## Проверяем открыт ли доступ к папке в котом находится фото
             $queryAccessPicture = $DB -> query ("SELECT `id` FROM `pictures_folder` WHERE `id` = '".$folder."' AND `access` = '0' AND `user_id` = '".$user['id']."'");

             ## Если доступ открыт
             if ($queryAccessPicture -> RowCount () > 0) {

                 ## Получаем информацию о картинке
                 $picture = $queryTestPic -> fetch ();

                 ## Обновляем статус аватара (0 - стандартный, 1 - выбраный с котографий)
                 $updateAvaUser = $DB -> query ("UPDATE `users` SET `avatar` = '1' WHERE `id` = '".$user['id']."'");

                 ## сохраняем данные о аватаре
                 $addAvatar = $DB -> query ("INSERT INTO `users_avatar` SET 
                                            `user_id` = '".$user['id']."',
                                            `pic_id` = '".$picture['id']."',
                                            `pic_key` = '".$picture['key_name_file']."',
                                            `pic_folder` = '".$picture['folder_id']."',
                                            `pic_type` = '".$picture['type']."',
                                            `time` = '".time ()."'");

                 ## Выводим успешну смену аватара
                 Core::redirect_ok ("Фото изменено", HTTP."/edit/avatar/");

             }
             else Core::redirect ("Фото должно находится в папке которая доступна для всех!", HTTP."/edit/avatar/");

         }
         else {

             ## Получаем информацию о картинке
             $picture = $queryTestPic -> fetch ();

             ## Обновляем статус аватара (0 - стандартный, 1 - выбраный с котографий)
             $updateAvaUser = $DB -> query ("UPDATE `users` SET `avatar` = '1' WHERE `id` = '".$user['id']."'");

             ## сохраняем данные о аватаре
             $addAvatar = $DB -> query ("INSERT INTO `users_avatar` SET 
                                        `user_id` = '".$user['id']."',
                                        `pic_id` = '".$picture['id']."',
                                        `pic_key` = '".$picture['key_name_file']."',
                                        `pic_folder` = '".$picture['folder_id']."',
                                        `pic_type` = '".$picture['type']."',
                                        `time` = '".time ()."'");

             ## Выводим успешну смену аватара
             Core::redirect_ok ("Фото изменено", HTTP."/edit/avatar/");

         }

     }
     else Core::redirect ("Фото не существует!", HTTP."/edit/avatar/");

 }
 else Core::redirect ("Не верный CK!", HTTP."/edit/avatar/");


 

?>