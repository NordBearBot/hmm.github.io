<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $id = (int) abs ($_GET['id']);

 


 $queryRegion = $DB -> query ("SELECT * FROM `geo_regions` WHERE `region_id` = '".$id."' LIMIT 1");
 if ($queryRegion -> RowCount () < 1) Core::redirect ("Выбранный вами регион не существует!", HTTP."/edit/selection/");
 else $region = $queryRegion -> fetch ();

 ## Пагинация
 $c_p = $DB -> query ("SELECT * FROM `geo_cities` WHERE `rid`= '".$id."'") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryCity = $DB -> query ("SELECT * FROM `geo_cities` WHERE `rid`= '".$id."' ORDER BY `city_name` ASC LIMIT $start, ".$p_page."");

 $description = NULL;
 $keywords = NULL;
 $title = $user['login'].' / Анкета / Выберите ваш Регион';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/anketa/">

                 Анкета

             </a>

         </div>

         <div class = "nav">

             Выберите ваш Регион

         </div>
 ';

 Core::Error ();

 while ($act = $queryCity -> fetch()) {
    
     echo '

         <a class = "home" href="'.HTTP.'/edit/selection/city/'.$act['city_id'].'/?CK='.$user['CK'].'">

             '.$act['city_name'].'

         </a>

     ';
    
 }

 if ($k_page > 1) Core::str(''.HTTP.'/edit/selection/region/'.$region['region_id'].'/?', $k_page, $page);

 echo '
         <div class = "nav">

             Выберите вашу страну

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/anketa/">

                 Анкета

             </a>

         </div>

 ';

 include_once ROOT.'/template/footer.php';

?>