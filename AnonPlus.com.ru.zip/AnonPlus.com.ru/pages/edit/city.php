<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $id = (int) abs ($_GET['id']);
 $CK = (int) abs ($_GET['CK']);

 $queryCity = $DB -> query ("SELECT * FROM `geo_cities` WHERE `city_id` = '".$id."' LIMIT 1");
 if ($queryCity -> RowCount () < 1) Core::redirect ("Выбранный вами город не существует!", HTTP."/edit/selection/");
 else $city = $queryCity -> fetch ();

 if ($CK == $user['CK']) {

 $region = $DB -> query("SELECT `region_name` FROM `geo_regions` WHERE `region_id`= '".$city['rid']."' LIMIT 1") -> fetch ();
 
 $country = $DB -> query("SELECT `country_name` FROM `geo_countries` WHERE `country_id`= '".$city['cid']."' LIMIT 1") -> fetch (); 

 $DB -> query("UPDATE `user_anketa` SET `city`= '".$city['city_name']."',`region`= '".$region['region_name']."',`country`='".$country['country_name']."' WHERE `user_id`= '".$user['id']."' LIMIT 1");

 Core::redirect_ok("Изменения успешно сохранены", HTTP."/edit/"); 

 }
 Core::redirect("Не верный CK!", HTTP."/edit/");

?>