<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 $id = (int) abs ($_GET['id']);

 $queryCountry = $DB -> query ("SELECT * FROM `geo_countries` WHERE `country_id`= '".$id."' LIMIT 1");
 if ($queryCountry -> RowCount () < 1) Core::redirect ("Страна не существует!", HTTP."/edit/selection/");
 else $country = $queryCountry -> fetch ();

 ## Пагинация
 $c_p = $DB -> query ("SELECT * FROM `geo_regions` WHERE `cid`= '".$id."'") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryRegion = $DB -> query ("SELECT * FROM `geo_regions` WHERE `cid`= '".$id."' ORDER BY `region_name` ASC LIMIT $start, ".$p_page."");

 $description = NULL;
 $keywords = NULL;
 $title = $user['login'].' / Анкета / Выберите ваш Регион';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/anketa/">

                 Анкета

             </a>

         </div>

         <div class = "nav">

             Выберите ваш Регион

         </div>
 ';

 Core::Error ();

 while ($act = $queryRegion -> fetch()) {
    
     echo '

         <a class = "home" href="'.HTTP.'/edit/selection/region/'.$act['region_id'].'">

             '.$act['region_name'].'

         </a>

     ';
    
 }
 
 if ($k_page > 1) Core::str(''.HTTP.'/edit/selection/country/'.$country['country_id'].'/?', $k_page, $page);


 echo '
         <div class = "nav">

             Выберите вашу страну

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/anketa/">

                 Анкета

             </a>

         </div>

 ';

 include_once ROOT.'/template/footer.php';

?>