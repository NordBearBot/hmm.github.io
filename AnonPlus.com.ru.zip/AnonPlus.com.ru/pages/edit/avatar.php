<?php 

  include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();

 ## Обработка изменения
 if (isset ($_GET['pic']) && isset ($_GET['folder']) && isset ($_GET['CK'])) {

     include_once ROOT.'/pages/edit/inc/processing_avatar.php';

 }

 $description = NULL;
 $keywords = NULL;
 $title = $user['login'].' / Анкета / Редактирование фотографии';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/anketa/">

                 Анкета

             </a>

         </div>

         <div class = "nav">

             Редактирование фотографии

         </div>

 ';

 Core::Error ();
 Core::Ok ();
 echo '
         <div class = "block">

             '.Core::avatar ($user['id'], '128').'

         </div>

         <div class = "block">

             <a href = "'.HTTP.'/uid'.$user['id'].'/pictures/?edit_avatar">Изменить</a>

         </div>

 ';

 echo '    
         <div class = "nav">

             Редактирование фотографии

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/anketa/">

                 Анкета

             </a>

         </div>

 ';

 include_once ROOT.'/template/footer.php';

?>