<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 Core::CheckUser ();
 
 ## Пагинация
 $c_p = $DB -> query ("SELECT * FROM `geo_countries`") -> RowCount ();

 if (isset($user)) $p_page = $user['count_page'];
 else $p_page = '7';
 $k_page = Core::k_page($c_p, $p_page);
 $page = Core::page($k_page);
 $start = $p_page*$page-$p_page;

 $queryGeo = $DB -> query ("SELECT * FROM `geo_countries` ORDER BY `country_name` ASC LIMIT $start, ".$p_page."");

 $description = NULL;
 $keywords = NULL;
 $title = $user['login'].' / Анкета / Выберите вашу страну';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/anketa/">

                 Анкета

             </a>

         </div>

         <div class = "nav">

             Выберите вашу страну

         </div>
 ';

 Core::Error ();
 
 if ($queryGeo -> RowCount () > 0) {

 echo '

         <div class="block">

             Популярные страны:

         </div>


         <a class="home" href="'.HTTP.'/edit/selection/country/9908">

             <img id = "menu_list" src="'.HTTP.'/files/system.images/country.icons/ua.png"> Украина

         </a>
    
         <a class="home" href="'.HTTP.'/edit/selection/country/3159">

             <img id = "menu_list" src="'.HTTP.'/files/system.images/country.icons/ru.png"> Россия

         </a>
    
         <a class="home" href="'.HTTP.'/edit/selection/country/248">

             <img id = "menu_list" src="'.HTTP.'/files/system.images/country.icons/by.png"> Беларусь
    
         </a>
    
         <a class="home" href="'.HTTP.'/edit/selection/country/1894">

             <img id = "menu_list" src="'.HTTP.'/files/system.images/country.icons/kz.png"> Казахстан

         </a>
    
         <a class="home" href="'.HTTP.'/edit/selection/country/9787">

             <img id = "menu_list" src="'.HTTP.'/files/system.images/country.icons/uz.png"> Узбекистан

         </a>
    
    ';

     while ($act = $queryGeo -> fetch()) {
    
     echo '

         <a class = "home" href="'.HTTP.'/edit/selection/country/'.$act['country_id'].'">

             '.$act['country_name'].'

         </a>

     ';
    
     }

     if ($k_page > 1) Core::str(''.HTTP.'/edit/selection/?', $k_page, $page);

 }

 echo '
         <div class = "nav">

             Выберите вашу страну

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             <a href = "'.HTTP.'/uid'.$user['id'].'/anketa/">

                 Анкета

             </a>

         </div>

 ';

 include_once ROOT.'/template/footer.php';

?>