<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 Core::CheckUser ();

 ## Обработка приветствия
 if (isset ($_POST['save'])) {

    if (isset ($_POST['CK']) and $_POST['CK'] == $user['CK']) {

    ## Обрабатываем данные которые ввёл пользователь
    $welcome = Core::Check ($_POST['welcome']);

    ## Проверяем на пустоту
    if (empty ($welcome)) Core::redirect ("Введите приветствие!", HTTP."/anketa/welcome/");
    else if (strlen ($welcome)<3 || strlen ($welcome)>100) Core::redirect ("Приветствие должно быть не меньше 3 и не больше 100 символов!", HTTP."/anketa/welcome/");

    ## Изменяем приветствие в БД
    $UpdateWelcome = $DB -> query ("UPDATE `users` SET `welcome` = ".$DB -> quote ($welcome)." WHERE `id` = '".$user['id']."'");

    ## Редиректим на страницу юзера и выводим сообщение о удачном изменении притствия
    Core::redirect_ok ("Приветствие изменено", HTTP."/uid".$user['id']."");

 }
 else Core::redirect_ok ("Не верный CK!", HTTP."/uid".$user['id']."");

 }

 $description = NULL;
 $keywords = NULL;
 $title = $user['login'].' / Приветствие';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "/">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             Приветствие

         </div>
 ';

 Core::Error ();

 echo '

         <div class = "block">

             <div class = "status">

                 '.$user['welcome'].'

             </div>

         </div>

         <div class = "block">

             <form action = "" method = "POST">

                 <input type="hidden" name="CK" value="'.$user['CK'].'" />

                 <input type = "text" name = "welcome" value = "'.$user['welcome'].'">

                 <br />

                 <input type = "submit" name = "save" value = "Изменить">

             </form>

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             <a href = "/">

                 '.$user['login'].'

             </a>

             <span class = "ico next"></span>

             Приветствие

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>