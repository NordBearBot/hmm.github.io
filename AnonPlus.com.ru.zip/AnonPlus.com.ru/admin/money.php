<?php 
 
 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 if ($user['level'] != 1) header ('Location: '.HTTP.'/');

 $title = 'Админ-панель / Монеты';
 include_once ROOT.'/template/header.php';

 if (isset ($_POST['login']) && isset($_POST['new_money'])) {
     
     
     
     $login = (string) Core::check ($_POST['login']);
     $new_money = (int) Core::check ($_POST['new_money']);
     $DB->query("UPDATE users SET coins=".$new_money." WHERE login='".$login."'");
     Core::redirect_ok ("Запрос в базу успешно отправлен!", HTTP."/admin/money.php");
     //$DB->query("UPDATE users SET ");
 }
 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>
 
             <a href = "'.HTTP.'/admin">

                 Админ-панель

             </a>

             <span class = "ico next"></span>

             Монеты

         </div>

         <div class = "background_place">

             <form action = "" method = "POST" enctype="multipart/form-data">
                <div class="b-title b-title_first">

                 <a class="b-title__link">

                     Монеты
                 </a>

             </div>
             <div class = "main_place">
                 
                 <div class = "place">

                     Логин: <br />
         
                     <input type="text" name="login" />

                 </div> 
                 <div class = "place">

                     Новое количество монет: <br />
         
                     <input type="text" name="new_money" />

                 </div> </div>
                 <div class = "main_place">
                 <div class = "place user_info" style = "border-bottom: 1px solid #eee;">

                     <input type="submit" value="Отправить запрос" name = "open">

                 </div>

             </div>

             '.Core::Error ().'

             '.Core::Ok ().'


             </form>

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>
 
             <a href = "'.HTTP.'/admin">

                 Админ-панель

             </a>

             <span class = "ico next"></span>

             Подарки

         </div> 

 ';
 include_once ROOT.'/template/footer.php';

?>