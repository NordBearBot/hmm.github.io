<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 
 if ($user['level'] != 1) header ('Location: '.HTTP.'/');

 ## Обработка подарка

 if (isset ($_POST['add'])) {

     $photo = array('gif', 'jpg', 'jpeg', 'png');  
     $type = strtolower(substr(strrchr($_FILES['file']['name'], '.'), 1));

         ## Проверяем тип файла
         if (in_array($type, $photo)) {
            
             ## Получаем информацию о файле
             $info = getimagesize($_FILES['file']['tmp_name']); 
             $width= $info[0]; 
             $height= $info[1];

             ## Конфигурация размерор фото
             $max_image_width = 400; 
             $max_image_height = 400; 
             $min_image_width = 99; 
             $min_image_height = 99; 

             ## Проверяем размер фото в px
             if ($width < $max_image_width or $height < $max_image_height) {
                 
                 if ($width > $min_image_width or $height > $min_image_height) {

                     ## Проверяем размер файла
                     if ($_FILES['file']['size'] < 1000000) {

                         $key = rand (100000, 999999);

                         $image = new image(); 

                         $image->load($_FILES['file']['tmp_name']);  
                         $image->resize(40,40);  
                         $image->save(ROOT.'/files/gifts/40/'.$key.'.'.$type.'');
    
                         $image->load($_FILES['file']['tmp_name']);  
                         $image->save(ROOT.'/files/gifts/'.$key.'.'.$type.'');

                         $access = (int) abs ($_POST['access']);
                         $access = ($access < 0 or $access> 1) ? 0 : $access;
 
                         $coins = (int) abs ($_POST['coins']);
                         $coins = ($coins < 0 or $coins > 3) ? 0 : $coins;

                         $DB -> query ("INSERT INTO `gifts` SET `access` = '".$access."', `coins` = '".$coins."', `key` = '".$key."', `type` = ".$DB -> quote ($type)."");

                         Core::redirect_ok ("Подарок добавлен!", HTTP."/admin/gift.php");

                     } else Core::redirect ("Файл не должен превышать 1МБ!", HTTP."/admin/gift.php");

                 } else Core::redirect ("Изображения должно быть не меньше ".$min_image_width."x".$min_image_height."px!", HTTP."/admin/gift.php");

             } else Core::redirect ("Изображения должно быть не более ".$max_image_width."x".$max_image_height."px!", HTTP."/admin/gift.php");

         } else Core::redirect ("Недопустимый тип файла!", HTTP."/admin/gift.php");

 }

 $title = 'Админ-панель / Подарки';
 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>
 
             <a href = "'.HTTP.'/admin">

                 Админ-панель

             </a>

             <span class = "ico next"></span>

             Подарки

         </div>

         <div class = "background_place">

             <form action = "" method = "POST" enctype="multipart/form-data">

             <div class = "main_place">
                 
                 <div class = "place">

                     Статус: <br />
         
                     <input type="radio" name="access" value="0" checked="checked" /> Свободный <br />
         
                     <input type="radio" name="access" value="1" /> Административный

                 </div> 

             </div>

             '.Core::Error ().'

             '.Core::Ok ().'

             <div class = "main_place">

                 <div class = "place">

                     Стоимость: <br />
         
                     <input type="radio" name="coins" value="0" checked="checked" /> 5 <br />
         
                     <input type="radio" name="coins" value="1" /> 10 <br />

                     <input type="radio" name="coins" value="2" /> 30 <br />

                     <input type="radio" name="coins" value="3" /> 50

                 </div> 

             </div>

             <div class = "main_place">

                 <div class = "place">

                     <input type="file" name="file"> <br />
                         
                     <input type="submit" value="Добавить" name = "add">

                 </div> 

             </div>

             </form>

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>
 
             <a href = "'.HTTP.'/admin">

                 Админ-панель

             </a>

             <span class = "ico next"></span>

             Подарки

         </div> 

 ';

 include_once ROOT.'/template/footer.php';

?>