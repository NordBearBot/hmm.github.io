<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';
 if ($user['level'] != 1) header ('Location: '.HTTP.'/');

 $title = 'Админ-панель';
 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>
 
             Админ-панель

         </div> 

         <div class = "background_place">

             <div class = "main_place">
                 
                 <a class="home" href="'.HTTP.'/admin/gift.php">

                     Подарки

                 </a>

                 <a class="home" href="'.HTTP.'/admin/games.php">

                     Игры

                 </a>
                 <a class="home" href="'.HTTP.'/admin/money.php">

                     Изменить количество монет

                 </a>

             </div>

         </div>

         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>
 
             Админ-панель

         </div>

 ';

 include_once ROOT.'/template/footer.php';

?>