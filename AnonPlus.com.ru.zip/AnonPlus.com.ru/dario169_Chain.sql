-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июл 27 2015 г., 11:13
-- Версия сервера: 5.5.42-cll-lve
-- Версия PHP: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `dario169_Chain`
--

-- --------------------------------------------------------

--
-- Структура таблицы `block_files`
--

CREATE TABLE IF NOT EXISTS `block_files` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `file_id` int(12) NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `file_type_name` varchar(50) NOT NULL,
  `file_description` varchar(20000) NOT NULL,
  `add_file` int(12) NOT NULL,
  `ban_file` int(12) NOT NULL,
  `folder_id` int(12) NOT NULL,
  `file_key` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `blogs`
--

CREATE TABLE IF NOT EXISTS `blogs` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `message` varchar(20000) NOT NULL,
  `channel` int(2) NOT NULL DEFAULT '0',
  `access` int(1) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL,
  `view` int(10) NOT NULL DEFAULT '0',
  `comments` int(12) NOT NULL DEFAULT '0',
  `share` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `blogs_comments`
--

CREATE TABLE IF NOT EXISTS `blogs_comments` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `blog_id` int(12) NOT NULL,
  `user_id` int(12) NOT NULL,
  `reply_id` int(12) NOT NULL DEFAULT '0',
  `message` varchar(20000) NOT NULL,
  `time` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `bookmarks`
--

CREATE TABLE IF NOT EXISTS `bookmarks` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `type` int(12) NOT NULL,
  `object_id` int(12) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='type: 0 - блог, 1 - фото, 2 - пользователь, 3 тема в форуме, 4 тема в соо...' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `chat_messages`
--

CREATE TABLE IF NOT EXISTS `chat_messages` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `room_id` int(12) NOT NULL,
  `user_id` int(12) NOT NULL,
  `msg` varchar(3000) NOT NULL,
  `reply_id` int(12) NOT NULL,
  `time` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `chat_moders`
--

CREATE TABLE IF NOT EXISTS `chat_moders` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `message_id` int(12) NOT NULL,
  `user_id` int(12) NOT NULL,
  `time` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `chat_online`
--

CREATE TABLE IF NOT EXISTS `chat_online` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `room_id` int(12) NOT NULL,
  `user_id` int(12) NOT NULL,
  `time` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `chat_room`
--

CREATE TABLE IF NOT EXISTS `chat_room` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `user_id` int(12) NOT NULL,
  `time` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `count_view`
--

CREATE TABLE IF NOT EXISTS `count_view` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `object_id` int(12) NOT NULL,
  `user_id` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `downloads_files`
--

CREATE TABLE IF NOT EXISTS `downloads_files` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `folder_id` int(12) NOT NULL,
  `file_id` int(12) NOT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'files',
  `status` int(1) NOT NULL DEFAULT '1',
  `time` int(10) NOT NULL,
  `moder` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `downloads_folder`
--

CREATE TABLE IF NOT EXISTS `downloads_folder` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `folder_id` int(12) NOT NULL DEFAULT '0',
  `type` varchar(30) NOT NULL DEFAULT 'files',
  `time` int(12) NOT NULL,
  `author` varchar(50) NOT NULL,
  `count` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `email_act`
--

CREATE TABLE IF NOT EXISTS `email_act` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `user_id` int(12) NOT NULL,
  `time` int(10) NOT NULL,
  `hash` varchar(200) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(70) NOT NULL,
  `description` varchar(3000) NOT NULL,
  `consored` int(1) NOT NULL DEFAULT '0',
  `user_id` int(12) NOT NULL,
  `time` int(10) NOT NULL,
  `key_name_file` int(15) NOT NULL,
  `type` varchar(20) NOT NULL,
  `folder_id` int(12) NOT NULL,
  `download` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `files_comments`
--

CREATE TABLE IF NOT EXISTS `files_comments` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `file_id` int(12) NOT NULL,
  `user_id` int(12) NOT NULL,
  `reply_id` int(12) NOT NULL,
  `message` varchar(3000) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `files_folder`
--

CREATE TABLE IF NOT EXISTS `files_folder` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `folder_id` int(12) NOT NULL DEFAULT '0',
  `access` int(2) NOT NULL DEFAULT '0',
  `name` varchar(150) NOT NULL,
  `count` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `forum_comments`
--

CREATE TABLE IF NOT EXISTS `forum_comments` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `theme_id` int(12) NOT NULL,
  `user_id` int(12) NOT NULL,
  `msg` varchar(3000) NOT NULL,
  `time` int(12) NOT NULL,
  `reply_id` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `status_user_id` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `forum_section`
--

CREATE TABLE IF NOT EXISTS `forum_section` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `info` varchar(120) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `forum_subsection`
--

CREATE TABLE IF NOT EXISTS `forum_subsection` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `section_id` int(12) NOT NULL,
  `name` varchar(100) NOT NULL,
  `info` varchar(120) NOT NULL,
  `count_theme` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `forum_themes`
--

CREATE TABLE IF NOT EXISTS `forum_themes` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `subsection` int(12) NOT NULL,
  `user_id` int(12) NOT NULL,
  `name` varchar(70) NOT NULL,
  `msg` varchar(20000) NOT NULL,
  `time` int(12) NOT NULL,
  `closed` int(1) NOT NULL DEFAULT '0',
  `closed_id` int(12) NOT NULL DEFAULT '0',
  `locked` int(1) NOT NULL DEFAULT '0',
  `delete` int(1) NOT NULL DEFAULT '0',
  `delete_subsection` int(12) NOT NULL,
  `delete_user_id` int(12) NOT NULL,
  `status_check` int(1) NOT NULL DEFAULT '1',
  `check_user_id` int(12) NOT NULL,
  `check_time` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `friends`
--

CREATE TABLE IF NOT EXISTS `friends` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `friend_id` int(12) NOT NULL,
  `online` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `games_list`
--

CREATE TABLE IF NOT EXISTS `games_list` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `add_user_id` int(12) NOT NULL,
  `name` varchar(100) NOT NULL,
  `link` varchar(200) NOT NULL,
  `msg` varchar(500) NOT NULL,
  `key` varchar(20) NOT NULL,
  `type` varchar(30) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `geo_cities`
--

CREATE TABLE IF NOT EXISTS `geo_cities` (
  `city_id` int(12) unsigned NOT NULL,
  `rid` int(12) unsigned NOT NULL,
  `cid` int(12) unsigned NOT NULL,
  `city_name` varchar(200) NOT NULL,
  PRIMARY KEY (`city_id`),
  KEY `rid` (`rid`),
  KEY `cid` (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `geo_countries`
--

CREATE TABLE IF NOT EXISTS `geo_countries` (
  `country_id` int(12) unsigned NOT NULL,
  `country_name` varchar(100) NOT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `geo_countries`
--

INSERT INTO `geo_countries` (`country_id`, `country_name`) VALUES
(4, 'Австралия'),
(63, 'Австрия'),
(81, 'Азербайджан'),
(582079, 'Албания'),
(582059, 'Алжир'),
(582086, 'Ангола'),
(173, 'Ангуилья'),
(23269623, 'Андорра'),
(23269624, 'Антарктика'),
(23269625, 'Антигуа и Барбуда'),
(23269688, 'Антильские о-ва'),
(177, 'Аргентина'),
(245, 'Армения'),
(7716093, 'Арулько'),
(23269622, 'Афганистан'),
(23269626, 'Ашмор и Картьер о-ва'),
(582029, 'Багамские о-ва'),
(23269627, 'Бангладеш'),
(582098, 'Барбадос'),
(23269628, 'Бассас да Индия'),
(582097, 'Бахрейн'),
(248, 'Беларусь'),
(401, 'Белиз'),
(404, 'Бельгия'),
(23269629, 'Бенин'),
(425, 'Бермуды'),
(428, 'Болгария'),
(582092, 'Боливия'),
(582028, 'Босния/Герцеговина'),
(582061, 'Ботсвана'),
(467, 'Бразилия'),
(23269632, 'Британская Океания'),
(23269633, 'Британские Виргинские о-ва'),
(23269634, 'Бруней'),
(23269635, 'Буркина Фасо'),
(23269636, 'Бурунди'),
(23269630, 'Бутан'),
(23269722, 'Валлис и Футуна о-ва'),
(23269721, 'Вануату'),
(616, 'Великобритания'),
(924, 'Венгрия'),
(582053, 'Венесуэла'),
(23269652, 'Восточный Тимор'),
(971, 'Вьетнам'),
(23269661, 'Габон'),
(994, 'Гаити'),
(23269670, 'Гайана'),
(23269662, 'Гамбия'),
(582066, 'Гана'),
(1007, 'Гваделупа'),
(23269666, 'Гватемала'),
(23269668, 'Гвинея'),
(23269669, 'Гвинея-Бисау'),
(1012, 'Германия'),
(23269667, 'Гернси о-в'),
(20738587, 'Гибралтар'),
(23269664, 'Глориосо о-ва'),
(2567393, 'Гондурас'),
(277557, 'Гонконг'),
(23269665, 'Гренада'),
(582052, 'Гренландия'),
(1258, 'Греция'),
(1280, 'Грузия'),
(34850173, 'Д.Р. Конго'),
(1366, 'Дания'),
(23269674, 'Джерси о-в'),
(23269650, 'Джибути'),
(23269673, 'Джон Майен о-ва'),
(23269651, 'Доминика'),
(2577958, 'Доминиканская республика'),
(23269655, 'Европы о-в'),
(1380, 'Египет'),
(34850922, 'Еретриа'),
(582081, 'Замбия'),
(23269723, 'Западная Сахара'),
(582056, 'Зимбабве'),
(1393, 'Израиль'),
(1451, 'Индия'),
(277559, 'Индонезия'),
(277561, 'Иордания'),
(3410238, 'Ирак'),
(1663, 'Иран'),
(1696, 'Ирландия'),
(582039, 'Исландия'),
(1707, 'Испания'),
(1786, 'Италия'),
(23269724, 'Йемен'),
(23269638, 'Кабо-Верде'),
(1894, 'Казахстан'),
(23269640, 'Кайманские о-ва'),
(23269637, 'Камбоджа'),
(2163, 'Камерун'),
(2172, 'Канада'),
(23269697, 'Катар'),
(582057, 'Кения'),
(2297, 'Кипр'),
(23269676, 'Кирибати'),
(2374, 'Китай'),
(23269643, 'Клипертона о-в'),
(23269644, 'Кокосовы (Килинг) о-ва'),
(582033, 'Колумбия'),
(23269645, 'Коморские о-ва'),
(582076, 'Конго (Brazzaville)'),
(23269646, 'Конго (Kinshasa)'),
(23269648, 'Кораловое море о-ва'),
(2430, 'Коста-Рика'),
(582077, 'Куба'),
(2443, 'Кувейт'),
(23269647, 'Кука о-ва'),
(2303, 'Кыргызстан'),
(23269677, 'Лаос'),
(2448, 'Латвия'),
(23269678, 'Лесото'),
(23269679, 'Либерия'),
(582060, 'Ливан'),
(2509, 'Ливия'),
(2514, 'Литва'),
(582095, 'Лихтенштейн'),
(2614, 'Люксембург'),
(23269683, 'Маврикий'),
(582069, 'Мавритания'),
(582109, 'Мадагаскар'),
(23269684, 'Майотт'),
(23269680, 'Макао'),
(582041, 'Македония'),
(582094, 'Малави'),
(277563, 'Малайзия'),
(582108, 'Мали'),
(23269681, 'Мальдивские о-ва'),
(582043, 'Мальта'),
(23269682, 'Мартиника о-в'),
(2617, 'Мексика'),
(582082, 'Мозамбик'),
(2788, 'Молдова'),
(2833, 'Монако'),
(2687701, 'Монголия'),
(23269685, 'Монтсерат'),
(582065, 'Морокко'),
(23269686, 'Мьянма (Бирма)'),
(582105, 'Мэн о-в'),
(582063, 'Намибия'),
(23269687, 'Науру'),
(582068, 'Непал'),
(23269691, 'Нигер'),
(582080, 'Нигерия'),
(1206, 'Нидерланды (Голландия)'),
(23269690, 'Никарагуа'),
(2837, 'Новая Зеландия'),
(23269689, 'Новая Каледония о-в'),
(2880, 'Норвегия'),
(23269693, 'Норфолк о-в'),
(23269692, 'Нюэ'),
(582051, 'О.А.Э.'),
(23269694, 'Оман'),
(582044, 'Пакистан'),
(582093, 'Панама'),
(582045, 'Папуа Новая Гвинея'),
(582072, 'Парагвай'),
(23269695, 'Парасел о-ва'),
(582046, 'Перу'),
(23269696, 'Питкэрн о-в'),
(2897, 'Польша'),
(3141, 'Португалия'),
(34851252, 'Пуэрто Рико'),
(3156, 'Реюньон'),
(23269642, 'Рождественские о-ва'),
(3159, 'Россия'),
(23269698, 'Руанда'),
(277555, 'Румыния'),
(5681, 'США'),
(5647, 'Сальвадор'),
(23269704, 'Самоа'),
(23269705, 'Сан-Марино'),
(23269706, 'Сан-Томе и Принсипи'),
(582048, 'Саудовская Аравия'),
(23269715, 'Свазиленд'),
(23269714, 'Свальбэрд'),
(23269701, 'Святая Люсия'),
(23269672, 'Святая земля'),
(23269699, 'Святой Елены о-в'),
(582040, 'Северная Корея'),
(582071, 'Сейшеллы'),
(23269663, 'Сектор Газа'),
(23269702, 'Сен-Пьер и Микелон'),
(582110, 'Сенегал'),
(23269700, 'Сент Китс и Невис'),
(23269703, 'Сент-Винсент и Гренадины'),
(23269707, 'Сербия и Черногория'),
(277565, 'Сингапур'),
(582067, 'Сирия'),
(5666, 'Словакия'),
(5673, 'Словения'),
(23269709, 'Соломоновы о-ва'),
(23269710, 'Сомали'),
(23269712, 'Спратли о-ва'),
(23269713, 'Судан'),
(5678, 'Суринам'),
(23269708, 'Сьерра-Леоне'),
(9575, 'Таджикистан'),
(582050, 'Таиланд'),
(277567, 'Тайвань'),
(582062, 'Танзания'),
(582112, 'Того'),
(23269716, 'Токелау о-ва'),
(23269717, 'Тонга'),
(23269718, 'Тринидад и Тобаго'),
(23269719, 'Тромелин о-в'),
(23269720, 'Тувалу'),
(582090, 'Тунис'),
(9638, 'Туркменистан'),
(9701, 'Туркс и Кейкос'),
(9705, 'Турция'),
(9782, 'Уганда'),
(9787, 'Узбекистан'),
(9908, 'Украина'),
(582075, 'Уругвай'),
(582084, 'Фалькийские о-ва'),
(23269656, 'Фарерские о-ва'),
(23269657, 'Фиджи'),
(582047, 'Филиппины'),
(10648, 'Финляндия'),
(10668, 'Франция'),
(23269658, 'Французская Гвинея'),
(23269659, 'Французская Полинезия'),
(23269660, 'Французские юж. и антаркт. о-ва'),
(23269671, 'Херд и Мак Дональнд о-ва'),
(277553, 'Хорватия'),
(582100, 'Центральная Африка'),
(582101, 'Чад'),
(10874, 'Чехия'),
(582031, 'Чили'),
(10904, 'Швейцария'),
(10933, 'Швеция'),
(582087, 'Шри-Ланка'),
(582064, 'Эквадор'),
(23269653, 'Экваториальная Гвинея'),
(23269654, 'Эритрея'),
(10968, 'Эстония'),
(582088, 'Эфиопия'),
(3661568, 'ЮАР'),
(11014, 'Южная Корея'),
(23269711, 'Южные Сандвичевы о-ва'),
(582106, 'Ямайка'),
(23269675, 'Ян де нова о-ва'),
(11060, 'Япония');

-- --------------------------------------------------------

--
-- Структура таблицы `geo_regions`
--

CREATE TABLE IF NOT EXISTS `geo_regions` (
  `region_id` int(12) unsigned NOT NULL,
  `cid` int(12) unsigned NOT NULL,
  `region_name` varchar(100) NOT NULL,
  PRIMARY KEY (`region_id`),
  KEY `cid` (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `gifts`
--

CREATE TABLE IF NOT EXISTS `gifts` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `access` int(1) NOT NULL DEFAULT '0',
  `coins` int(3) NOT NULL DEFAULT '5',
  `key` int(6) NOT NULL DEFAULT '0',
  `type` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Дамп данных таблицы `gifts`
--

INSERT INTO `gifts` (`id`, `access`, `coins`, `key`, `type`) VALUES
(1, 0, 3, 979349, 'jpg'),
(2, 1, 1, 780219, 'jpg'),
(3, 0, 1, 432101, 'png'),
(4, 0, 1, 940846, 'jpg'),
(5, 0, 2, 403130, 'jpg'),
(6, 0, 1, 594790, 'jpg'),
(7, 0, 1, 568848, 'jpg'),
(8, 1, 1, 298009, 'jpg'),
(9, 0, 1, 508723, 'jpg'),
(10, 0, 1, 813184, 'jpg'),
(11, 0, 1, 922699, 'jpg'),
(12, 0, 1, 579749, 'jpg'),
(13, 0, 1, 522070, 'jpg'),
(14, 0, 1, 430348, 'jpg'),
(15, 0, 1, 251567, 'jpg'),
(16, 0, 1, 744481, 'jpg'),
(17, 0, 1, 163049, 'gif'),
(18, 0, 1, 648832, 'jpg'),
(19, 0, 1, 380935, 'jpg'),
(20, 0, 0, 352916, 'jpg'),
(21, 0, 2, 822438, 'jpg'),
(22, 0, 2, 949931, 'jpg'),
(23, 0, 2, 791621, 'jpg'),
(24, 0, 2, 900119, 'jpg'),
(25, 0, 2, 209680, 'jpg'),
(26, 0, 2, 441543, 'jpg'),
(27, 0, 3, 623847, 'jpg'),
(28, 0, 3, 476973, 'jpg'),
(29, 0, 3, 840234, 'jpg'),
(30, 0, 3, 363952, 'jpg'),
(31, 1, 1, 514463, 'jpg'),
(32, 1, 1, 154505, 'jpg'),
(33, 1, 0, 216134, 'png'),
(34, 0, 0, 171288, 'jpg'),
(35, 1, 2, 888159, 'jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `history_auth`
--

CREATE TABLE IF NOT EXISTS `history_auth` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `time` int(10) NOT NULL,
  `ua` varchar(300) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `hash` varchar(120) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `history_auth`
--

INSERT INTO `history_auth` (`id`, `user_id`, `time`, `ua`, `ip`, `status`, `hash`) VALUES
(1, 1, 1437983456, 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 YaBrowser/15.6.2311.5029 Safari/537.36', '5.44.168.206', 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `journal`
--

CREATE TABLE IF NOT EXISTS `journal` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `reply_id` int(12) NOT NULL,
  `message` varchar(150) NOT NULL,
  `time` int(12) NOT NULL,
  `type` int(2) NOT NULL,
  `url` varchar(150) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `act` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `lenta`
--

CREATE TABLE IF NOT EXISTS `lenta` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `object_id` int(12) NOT NULL DEFAULT '0',
  `message` varchar(150) NOT NULL,
  `type` int(1) NOT NULL DEFAULT '0',
  `url` varchar(150) NOT NULL,
  `time` int(12) NOT NULL,
  `share` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `mail_contacts`
--

CREATE TABLE IF NOT EXISTS `mail_contacts` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `kto` int(12) NOT NULL,
  `kogo` int(12) NOT NULL,
  `time` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `mail_messages`
--

CREATE TABLE IF NOT EXISTS `mail_messages` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `kto` int(12) NOT NULL,
  `komy` int(12) NOT NULL,
  `text` varchar(3000) NOT NULL,
  `time` int(12) NOT NULL,
  `new` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pictures`
--

CREATE TABLE IF NOT EXISTS `pictures` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(70) NOT NULL,
  `description` varchar(3000) NOT NULL,
  `consored` int(1) NOT NULL DEFAULT '0',
  `user_id` int(12) NOT NULL,
  `time` int(12) NOT NULL,
  `key_name_file` int(15) NOT NULL,
  `type` varchar(20) NOT NULL,
  `folder_id` int(12) NOT NULL DEFAULT '0',
  `view` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pictures_comments`
--

CREATE TABLE IF NOT EXISTS `pictures_comments` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `pic_id` int(12) NOT NULL,
  `user_id` int(12) NOT NULL,
  `reply_id` int(12) NOT NULL DEFAULT '0',
  `message` varchar(3000) NOT NULL,
  `time` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pictures_folder`
--

CREATE TABLE IF NOT EXISTS `pictures_folder` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `folder_id` int(12) NOT NULL DEFAULT '0',
  `access` int(2) NOT NULL DEFAULT '0',
  `name` varchar(150) NOT NULL,
  `count` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `query_friends`
--

CREATE TABLE IF NOT EXISTS `query_friends` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `komy` int(12) NOT NULL,
  `ot` int(12) NOT NULL,
  `code` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `rating_log`
--

CREATE TABLE IF NOT EXISTS `rating_log` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `rating` varchar(10) NOT NULL,
  `time` int(10) NOT NULL,
  `type` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `rating_log`
--

INSERT INTO `rating_log` (`id`, `user_id`, `rating`, `time`, `type`) VALUES
(1, 1, '0.3', 1437983456, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `login` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(120) NOT NULL,
  `tm` varchar(200) NOT NULL,
  `tc` int(4) NOT NULL,
  `sex` int(1) NOT NULL DEFAULT '0',
  `usid` varchar(100) NOT NULL,
  `CK` int(4) NOT NULL,
  `data_registration` int(10) NOT NULL,
  `coins` int(12) NOT NULL DEFAULT '0',
  `online` int(10) NOT NULL,
  `avatar` int(1) NOT NULL DEFAULT '0',
  `count_page` int(2) NOT NULL DEFAULT '7',
  `lenta_time` int(12) NOT NULL,
  `level` int(2) NOT NULL DEFAULT '0',
  `ban` int(1) NOT NULL DEFAULT '0',
  `welcome` varchar(250) NOT NULL DEFAULT 'Hello world ;)',
  `rating` float NOT NULL DEFAULT '0',
  `blog_info` varchar(250) NOT NULL DEFAULT 'my blog',
  `book_comments` int(1) NOT NULL DEFAULT '0',
  `book_access` int(1) NOT NULL DEFAULT '0',
  `mail_access` int(1) NOT NULL DEFAULT '0',
  `dating` int(1) NOT NULL DEFAULT '1',
  `userType` int(1) NOT NULL DEFAULT '3',
  `online_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `email`, `tm`, `tc`, `sex`, `usid`, `CK`, `data_registration`, `coins`, `online`, `avatar`, `count_page`, `lenta_time`, `level`, `ban`, `welcome`, `rating`, `blog_info`, `book_comments`, `book_access`, `mail_access`, `dating`, `userType`, `online_time`) VALUES
(1, 'ADMIN', 'dadada', '', '8de549ef3c7c8893bcdb0ec9c7423cb16dd87bf4', 2077, 0, '2fb8532814d011e0c3aa527c7c87eb11', 2417, 1437983232, 8, 1437984564, 0, 7, 1437984505, 0, 0, 'Hello world ;)', 0.3, 'my blog', 0, 0, 0, 1, 3, 246);

-- --------------------------------------------------------

--
-- Структура таблицы `users_avatar`
--

CREATE TABLE IF NOT EXISTS `users_avatar` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `pic_id` int(12) NOT NULL,
  `pic_key` int(12) NOT NULL,
  `pic_folder` int(12) NOT NULL,
  `pic_type` varchar(20) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `user_anketa`
--

CREATE TABLE IF NOT EXISTS `user_anketa` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `name` varchar(30) NOT NULL,
  `day` varchar(2) NOT NULL,
  `month` varchar(2) NOT NULL,
  `year` varchar(4) NOT NULL,
  `age` varchar(2) NOT NULL,
  `city` varchar(150) NOT NULL,
  `region` varchar(150) NOT NULL,
  `country` varchar(150) NOT NULL,
  `partner` varchar(500) NOT NULL,
  `me` varchar(500) NOT NULL,
  `interests` varchar(500) NOT NULL,
  `music` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `user_anketa`
--

INSERT INTO `user_anketa` (`id`, `user_id`, `name`, `day`, `month`, `year`, `age`, `city`, `region`, `country`, `partner`, `me`, `interests`, `music`) VALUES
(1, 1, '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `user_ban_list`
--

CREATE TABLE IF NOT EXISTS `user_ban_list` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `object_id` int(12) NOT NULL,
  `user_id` int(12) NOT NULL,
  `moder_id` int(12) NOT NULL,
  `time` int(12) NOT NULL,
  `ban_time` int(12) NOT NULL,
  `what` int(12) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `type_file` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `user_book`
--

CREATE TABLE IF NOT EXISTS `user_book` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `book_id` int(12) NOT NULL,
  `user_id` int(12) NOT NULL,
  `reply_id` int(12) NOT NULL DEFAULT '0',
  `message` varchar(3000) NOT NULL,
  `time` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `user_gifts`
--

CREATE TABLE IF NOT EXISTS `user_gifts` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_id` int(12) NOT NULL,
  `reply_id` int(12) NOT NULL,
  `message` varchar(300) NOT NULL,
  `time` int(10) NOT NULL,
  `gift_id` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
