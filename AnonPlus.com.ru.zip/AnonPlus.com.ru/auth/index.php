<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 if ($user) header ('Location: '.HTTP.'/uid'.$user['id']);
 
 if (isset ($_POST['auth'])) {
    $okey = false;

    $login = Core::check ($_POST['auth_login']);
    $password = Core::check ($_POST['auth_password']);

    if (empty ($login) or empty ($password)) {

        if (empty ($login) and empty ($password)) $authErr = 'Введите ник и пароль!';
        else if (empty ($login)) $authErr = 'Введите ник!';
        else if (empty ($password)) $authErr = 'Введите пароль!';
        else $authErr = NULL;

    }
    else $okey = true;
    
    if ($okey == true) {

    ## Делаем запрос в БД
    $auth = $DB -> query ("SELECT `id` FROM `users` WHERE `login` = ".$DB -> quote ($login)." AND `password` = ".$DB -> quote ($password)." LIMIT 1") -> RowCount ();

    ## Пускаем на ник или пишем ошибку о не правильных данных
    if ($auth > 0) {

        ## Находим юзера с таким логином и паролем
        $data = $DB -> query ("SELECT `id` FROM `users` WHERE `login` = ".$DB -> quote ($login)." LIMIT 1") -> fetch ();
        
        ## Генерируем USID, и обновляем его в БД
        $USID = md5 (time ().$login);
        $updateUSID = $DB -> query ("UPDATE `users` SET `usid` = '".$USID."' WHERE `login` = ".$DB -> quote ($login)." LIMIT 1");

        ## Отделяем CK в USID, и обновляем его в БД
        $CK = mt_rand(1000,9999);
        $updateCK = $DB -> query ("UPDATE `users` SET `CK` = '".$CK."' WHERE `login` = ".$DB -> quote ($login)." LIMIT 1");
        
        ## Уничтожаем сессию
        session_unset ();
        session_destroy ();

         $data = $DB -> query ("SELECT `tm` FROM `users` WHERE `login` = ".$DB -> quote ($login)." LIMIT 1") -> fetch ();

         header ('Location: '.HTTP.'/tm/'.$data['tm']);

    }
    else $authErr = 'Не верный Ник или Пароль!';

    }

    if ($authErr != NULL) $ERR_AUTH = '<div class = "err">'.$authErr.'</div>';
    else $ERR_AUTH = NULL;
 }

 $description = 'Авторизация на '.DOMAIN;
 $keywords = NULL;
 $title = 'Авторизация';

 include_once ROOT.'/template/header.php';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Авторизация

         </div>
 ';

 Core::Error ();
 echo $ERR_AUTH;

 echo '    

         <div class = "background_place">

             <div class = "main_place">

                 <div class = "place">

                     <form action = "" method = "POST">
                         
                         <div class = "user_info">

                         <div class = "private_info">

                         Ник:

                         <br />

                         <input type = "text" name = "auth_login" placeholder = "You nick" value = "'.$login.'">

                         <br />

                         Пароль:

                         <br />

                         <input type = "password" name = "auth_password" placeholder = "You password">

                         <br />

                         <input type = "submit" name = "auth" value = "Войти">

                     </form>

                     </div>

                     </div>

                 </div>

             </div>

             <div class = "main_place">

                 <div class = "place">
                         
                     <div class = "user_info">

                         <div class = "private_info">

                             <a href = "'.HTTP.'/signup/" alt = "Регистрация">Регистрация</a>

                             <br />

                             <a href = "'.HTTP.'/access/" alt = "Напомнить пароль?">Напомнить пароль?</a>

                         </div>

                     </div>

                 </div>

             </div>

         </div>

 ';

 echo '
         <div class = "title">

             <a href = "'.HTTP.'/">

                 <span class = "ico home-link"></span>

             </a>

             <span class = "ico next"></span>

             Авторизация

         </div>
 ';

 include_once ROOT.'/template/footer.php';

?>