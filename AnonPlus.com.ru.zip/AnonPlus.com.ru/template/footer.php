<?php

 if ($user) {

     echo '<div class="nav_menu" style = "border-top: none;">

             <table style="width: 100%;" cellspacing="0" cellpadding="0">

                 <tbody>

                     <tr> 
    
                         <td class = "lnk transition nav_conf" id = "open-left-panel">

                             <a href="'.HTTP.'/" class = "lnk_l white_fix">

                                 <img src = "'.HTTP.'/files/system.images/foot.icons/home.png" alt = "'.SITE_NAME.'">

                             </a>

                         </td>

                         <td class = "lnk nav_conf" id = "transition">

                             <a href="'.HTTP.'/help" class = "lnk_l white_fix">

                                 <img src = "'.HTTP.'/files/system.images/foot.icons/help.png" alt = "Пом">

                             </a>

                         </td>   

                         <td class = "lnk nav_conf" id = "transition">

                             <a href="'.HTTP.'/forum" class = "lnk_l white_fix">

                                 <img src = "'.HTTP.'/files/system.images/foot.icons/forum.png" alt = "Фор">

                             </a>

                         </td> 

                         <td class = "lnk nav_conf" id = "transition">

                             <a href="'.HTTP.'/bookmarks" class = "lnk_l white_fix">

                                 <img src = "'.HTTP.'/files/system.images/foot.icons/bookmarks.png" alt = "Закл">

                             </a>

                         </td>
  
                         <td class = "lnk nav_conf" id = "transition">

                             <a href="'.HTTP.'/uid'.$user['id'].'" class = "lnk_l white_fix">

                                 <img src = "'.HTTP.'/files/system.images/foot.icons/profile_'.($user['sex'] == 1 ? 'wo' : NULL).'man.png" alt = "Я">
                                
                             </a>

                         </td>  
  
                     </tr>

                 </tbody>

             </table>
   
         </div>

     ';

 }


 echo '    <div class = "end">'.($user['id'] == 1 ? '<span id = "right">PG: <b>'.round(microtime(1) - GEN, 4).'</b> сек.</span>' : '').' <div>';
 echo '</body></html>';

 if (isset ($_SESSION['err'])) unset($_SESSION['err']);
 if (isset ($_SESSION['ok'])) unset($_SESSION['ok']);

?> 