
$("#anketa_block").hide();

$(document).ready(function(){
   
   $("#anketa").click(function(){
      $("#ank_classes").removeClass("no_act").addClass("act");
      $("#news_classes").removeClass("act").addClass("no_act");
      $("#pro_classes").removeClass("act").addClass("no_act");
      $("#nav_ank").addClass("t");
      $("#nav_pro").removeClass("t");
      $("#news_news").removeClass("t");
      $("#profile_block").animate({
          "height": "toggle"
      }, 500 ).hide ();
      $("#news_block").animate({
          "height": "toggle"
      }, 500 ).hide ();
      $("#anketa_block").animate({
          "height": "show"
      }, 500 );
   });

});

$(document).ready(function(){
   
   $("#profile").click(function(){
      $("#ank_classes").removeClass("act").addClass("no_act");
      $("#news_classes").removeClass("act").addClass("no_act");
      $("#pro_classes").removeClass("no_act").addClass("act");
      $("#nav_ank").removeClass("t");
      $("#nav_pro").addClass("t");
      $("#news_news").removeClass("t");
      $("#profile_block").animate({
          "height": "show"
      }, 500 );
      $("#anketa_block").animate({
          "height": "toggle"
      }, 500 ).hide ();
      $("#news_block").animate({
          "height": "toggle"
      }, 500 ).hide ();
    });

});

$(document).ready(function(){
   
   $("#news").click(function(){
      $("#ank_classes").removeClass("act").addClass("no_act");
      $("#news_classes").removeClass("no_act").addClass("act");
      $("#pro_classes").removeClass("act").addClass("no_act");
      $("#nav_ank").removeClass("t");
      $("#nav_pro").removeClass("t");
      $("#nav_news").addClass("t");
      $("#profile_block").animate({
          "height": "toggle"
      }, 500 );
      $("#anketa_block").animate({
          "height": "toggle"
      }, 500 ).hide ();
      $("#news_block").animate({
          "height": "show"
      }, 500 );
    });

});