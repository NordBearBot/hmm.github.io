// буду пилить на jquery так как яву я особо не знаю :клоун2
// govnokode by troh ^_^
// SIDEBAR SAO v0.1 :клоун2

$(function() {
    $('#open_menu').click(function() {

         $("#left-panel").addClass("lp_view");

    });
});