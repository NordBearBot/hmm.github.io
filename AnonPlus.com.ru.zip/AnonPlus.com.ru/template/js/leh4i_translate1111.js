var Main = {
    originalChars: ["е", "г", "о", "б", "в", "ли", "па", "фи", "щи", "пу",
            "пирится", "ан", "кри", "бад", "фат", "бонии", "ха", "фай", ":клаун2"],
    replaceChars: ["и", "х", "а", "п", "ф", "ле", "ба", "ви", "ще", "бу",
            "пиреца", "он", "кре", "пад", "ват", "пании", "га", "вай", ":клоун2"],

    //Метад вешаит обработчик на все формы
    setAllFormsOnSubmit: function() {
        var forms = document.getElementsByTagName("form");
        for(var i = 0; i < forms.length; i ++)
            forms[i].onsubmit = Main.onSubmit;
    },

    //обработчик переводит садиржимае textarea на нармальная:клоун2
    onSubmit: function() {
        var textareas = this.getElementsByTagName("textarea");
        for(var i = 0; i < textareas.length; i ++)
            textareas[i].value = Main.translate(textareas[i].value);
        return true;
    },

    //сам метад для пиривода
    translate: function(sourceText) {
        for(var idx = 0; idx < Main.originalChars.length; idx ++)
            sourceText = sourceText.replace(new RegExp(Main.originalChars[idx], "gim"), Main.replaceChars[idx]);
        sourceText += ":клоун2"
        return sourceText;
    }
}

if(document.location.toString().indexOf("vizaire.ru") != -1)
    window.onload = Main.setAllFormsOnSubmit;