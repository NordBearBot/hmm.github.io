function url_escape(data) {
     return encodeURIComponent(data).replace("'", "%29");
}

if ((document.getElementById("share_link")) && (document.getElementById("share_title"))){
     var LINK = document.getElementById("share_link").innerHTML,
	 TITLE = url_escape(document.getElementById("share_title").innerHTML);
}else{
    var LINK = document.location.href,
	TITLE = url_escape(document.title);
}  
    var LOGO = url_escape(document.getElementById("site_logo").src);
    LINK = url_escape(LINK.replace(/([&?;])sid=\d+/g, '$1sid='));

function socialButtons(){
    var HTML = '<div class="sps sps-theme-color sps-small">',
	
    VK_button = '<a class="social_link sps-vkontakte" href="http://vk.com/share.php?url=' + LINK + '&title=' + TITLE + '" title="В Контакте" onclick="window.open(this.href, \'vkontakte\', \'width=626, height=278\'); return false;" target="_blank"></a>',
    OK_button = '<a class="social_link sps-odnoklassniki" href="http://www.odnoklassniki.ru/dk?st.cmd=addShare&st.s=1&st._surl=' + LINK + '" title="Одноклассники" onclick="window.open(this.href, \'odnoklassniki\', \'width=830, height=650\'); return false;" target="_blank"></a>',
    FB_button = '<a class="social_link sps-facebook" href="http://www.facebook.com/sharer.php?u=' + LINK + '&t=' + TITLE + '&src=sp" title="Facebook" onclick="window.open(this.href, \'facebook\', \'width=609, height=436\'); return false;" target="_blank"></a>',
    TW_button = '<a class="social_link sps-twitter" href="http://twitter.com/share?url=' + LINK + '&text=' + TITLE + '" title="Twitter" onclick="window.open(this.href, \'twitter\', \'width=626, height=436\'); return false;" target="_blank"></a>',
    MOIMIR_button = '<a class="social_link sps-moimir" href="http://connect.mail.ru/share?url=' + LINK + '&title=' + TITLE + '&imageurl=' + LOGO + '" title="Мой Мир@Mail.Ru" onclick="window.open(this.href, \'moimir\', \'width=626, height=436\'); return false;" target="_blank"></a>',
    LJ_button = '<a class="social_link sps-livejournal" href="http://www.livejournal.com/update.bml?subject=' + TITLE + '&event=' + LINK + '" title="LiveJournal" target="_blank"></a>',
    GOOGLEPLUS_button = '<a class="social_link sps-google" href="https://plus.google.com/share?url=' + LINK + '&hl=ru" title="Google+" onclick="window.open(this.href, \'google\', \'width=610, height=318\'); return false;" target="_blank"></a>',
    MAIL_button = '<a class="social_link sps-email" href="mailto:?Subject=' + TITLE + '&body=' + LINK + '%0A" title="Отправить на email" onclick="window.open(this.href, \'mailto\');"></a>';
	
    HTML = HTML + VK_button + OK_button + FB_button + TW_button + MOIMIR_button + LJ_button + GOOGLEPLUS_button + MAIL_button;
    document.getElementById('sharing_buttons').innerHTML = HTML;
}
socialButtons();