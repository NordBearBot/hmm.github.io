<?php

 if (device::Mobile()) {

    	 $top_icons_path = 'mobile';
         $avatar_mini_style = 'style = "width: 25px;"';
         $style_site = ' class = "s_java_class"';

 }
 else $top_icons_path = 'full';

?> 