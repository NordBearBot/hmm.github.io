<?php

 $header_description = ($description != NULL) ? '<meta name = "description" content = "'.Core::check ($description).'" />' : '<!-- Description none -->';
 $header_keywords = ($keywords != NULL) ? '<meta name = "keywords" content = "'.Core::check ($keywords).'" />' : '<!-- Keywords none -->';
 
 if ($user) {

      $queryNewMail = $DB -> query ("SELECT `id` FROM `mail_messages` WHERE `komy` = '".$user['id']."' AND `new` = '1'") -> RowCount ();  
     $countMail = ($queryNewMail > 0) ? $queryNewMail : NULL;

     $queryNewLenta = $DB -> query ("SELECT `friends`.*, `lenta`.* FROM `friends`, `lenta` WHERE `friends`.`user_id`='".$user['id']."' AND `lenta`.`user_id`=`friends`.`friend_id` AND `time`>'".$user['lenta_time']."'") -> RowCount ();
     $countLenta = ($queryNewLenta > 0) ? $queryNewLenta : NULL;
     
     $queryNewJournal = $DB -> query ("SELECT * FROM `journal` WHERE `reply_id` = '".$user['id']."' AND `status` = '1'") -> RowCount ();
     $countJournal = ($queryNewJournal > 0) ? $queryNewJournal : NULL;

     if ($user['level'] > 0) {

         $queryNewFiles = $DB -> query ("SELECT `id` FROM `downloads_files` WHERE `status` = '1'") -> RowCount ();
         $queryNewForumThemes = $DB -> query ("SELECT `id` FROM `forum_themes` WHERE `status_check` = '1'") -> RowCount ();
         $countChatRemarks = $DB -> query ("SELECT * FROM `chat_moders`") -> RowCount ();

     }

 }

 ## Обработка стиля
 include_once ROOT.'/template/inc/processing_style.php';

 echo '
<?xml version="1.0" encoding="UTF-8" ?>

<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>'.$header_description.''.$header_keywords.'<title>'.Core::check ($title).'</title>

        <meta name = "copyright" content = "Ruswap.Ru 2015">

        <meta http-equiv=pragma content=no-cache>

        <link rel = "stylesheet" href = "'.HTTP.'/template/Chainsaw.css" type="text/css" />

        <link rel = "stylesheet" href = "'.HTTP.'/template/forms.css" type="text/css" />

        
        <!--[if lt IE 9]>

           <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>

           <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script> 

        <![endif]-->
 ';
 ?>

         <script>

             (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
             (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
             m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
             })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

             ga('create', 'UA-59976946-1', 'auto');
             ga('send', 'pageview');

         </script>
 <?
 echo '
     </head>

     <body'.$style_site.'>
     
     <div id = "main">

     <div id = "left-panel" style = "position: absolute;">
 

         <div class = "block" style = "border: none;">

             <center>

                 <a href = "'.HTTP.'/"><img id = "site_logo" src = "'.HTTP.'/template/images/logo.png" alt = "*"></a>

             </center></div>';

         if (!$user) {

             echo '<div class="nav_menu" style = "padding: 12px; border-bottom: 1px solid #BBC1C3;"> Ваше меню</div>';

     }

         if ($user) {

         echo '

         <div class = "nav_sb">

             <div id="avatar">

                 '.User::avatar ($user['id'], 40, 'mini', $avatar_mini_style).'

             </div>

             <a class = "login_panel" href = "'.HTTP.'/uid'.$user['id'].'">

                 '.$user['login'].'

                 <br />

                 <small>

                     true

                 </small>

             </a>

         </div>

         <a class = "left_nav" href = "'.HTTP.'/uid'.$user['id'].'/blog">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/blog.png">

             Мой блог

             <span style = "margin-left: 10px;" class="count_web">

                 <small>

                     '.$DB -> query ("SELECT `id` FROM `blogs` WHERE `user_id` = '".$user['id']."'") -> RowCount ().'
 
                 </small>
                             
             </span>

         </a>

         <a class = "left_nav" href = "'.HTTP.'/uid'.$user['id'].'/friends">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/friends.gif">

             Друзья

             <span style = "margin-left: 10px;" class="count_web">

                 <small>

                     '.$DB -> query ("SELECT `id` FROM `friends` WHERE `user_id`= '".$user['id']."'") -> RowCount ().'
 
                 </small>
                             
             </span>

         </a>

         <a class = "left_nav" href = "'.HTTP.'/uid'.$user['id'].'/pictures">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/picture.png">

             Фотографии

             <span style = "margin-left: 10px;" class="count_web">

                 <small>

                     '.$DB -> query ("SELECT `id` FROM `pictures` WHERE `user_id` = '".$user['id']."'") -> RowCount ().'
 
                 </small>
                             
             </span>

         </a>

         <a class = "left_nav" href = "'.HTTP.'/uid'.$user['id'].'/files">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/files.png">

             Файлы

             <span style = "margin-left: 10px;" class="count_web">

                 <small>

                     '.$DB -> query ("SELECT `id` FROM `files` WHERE `user_id` = '".$user['id']."'") -> RowCount ().'
 
                 </small>
                             
             </span>

         </a>

         <a class = "left_nav" href = "'.HTTP.'/bookmarks">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/fav.png">

             Закладки

             <span style = "margin-left: 10px;" class="count_web">

                 <small>

                     '.$DB -> query ("SELECT `id` FROM `bookmarks` WHERE `user_id` = '".$user['id']."'") -> RowCount ().'
 
                 </small>
                             
             </span>

         </a>

         <a class = "left_nav" href = "'.HTTP.'/authlog">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/auth_history.png">

             История входов

         </a>

         <a class = "left_nav" href = "'.HTTP.'/edit">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/edit_info.png">

             Анкета

         </a>

         <a class = "left_nav" href = "'.HTTP.'/settings">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/settings.png">

             Настройки

         </a>

         <a class = "left_nav" href = "'.HTTP.'/logout/?CK='.$user['CK'].'">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/exit.png">

             Выход

         </a>

         ';

         }
         else {

         echo '

         <div class = "lenta_block" style = "margin: 8px; padding: 10px; line-height: 25px;">

             <form action = "/auth/index.php" method = "POST">

             <span class = "private_info">Ник:</span>

             <br />

             <input type = "text" name = "auth_login" />

             <br />

             <span class = "private_info">Пароль:</span>

             <br />

             <input type = "password" name = "auth_password" />

             <br />

             <input type = "submit" name = "auth" value = "Войти">

             </form>

         </div>

         <div style = "text-align: center; margin-bottom: 8px;">

             <a class = "edit_c" href = "'.HTTP.'/signup">Регистрация</a>

         </div>

         ';

         }

         echo '

         <div class = "nav_sb">Разделы сайта</div>

         <a class = "left_nav" href = "'.HTTP.'/dating">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/dating.png">

             Знакомства

         </a>

         <a class = "left_nav" href = "'.HTTP.'/files">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/sz.png">

             Файлы

         </a>

         <a class = "left_nav" href = "'.HTTP.'/blogs">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/blog.png">

             Блоги

         </a>

         <a class = "left_nav" href = "'.HTTP.'/people">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/people.png">

             Пользователи

         </a>

         <a class = "left_nav" href = "'.HTTP.'/forum">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/forum.png">

             Форум

         </a>

         <a class = "left_nav" href = "'.HTTP.'/chat">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/chat.png">

             Чат

         </a>

         <a class = "left_nav" href = "'.HTTP.'/people">

             <img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/comm.png">

             Сообщества

         </a>
     </div>

     <div class = "solid">

         <div class = "block" id = "ar_blocked">';

             if ($user) {

             echo '

             <a id = "logo_no_lpanel" href = "'.HTTP.'/"><img src = "'.HTTP.'/template/images/logo.png" alt = "*"></a>

             <spn class = "logo_lpanel">&nbsp;</span>

             ';

             }
             else {

             echo '

             <a id = "logo_no_lpanel" href = "'.HTTP.'/"><img src = "'.HTTP.'/template/images/logo.png" alt = "*"></a>

             <span id = "logo_no_lpanel">

                 <a id = "right" href = "'.HTTP.'/auth" class = "auth" style = "margin-top: 5px;">

                     Авторизация

                 </a>

             </span>
                          
             <span id = "logo_lpanel">

                 <a href = "'.HTTP.'/auth" class = "auth">

                     Авторизация

                 </a>

                 <span id = "right">

                     <a href = "'.HTTP.'/signup" class = "auth">

                         Регистрация

                     </a>

                 </span>

             </span>

             ';

             }
             
         echo '

         </div>

         ';

 if ($user) {

     echo '

         <div class="nav_menu">

             <table style="width: 100%;" cellspacing="0" cellpadding="0">

                 <tbody>

                     <tr> 
    
                         <div class = "open_menu">

                         <td class = "lnk transition nav_conf" style = "cursor: pointer;" id = "menu_u_p">

                             <span class = "lnk_l">

                                 <img src = "'.HTTP.'/files/system.images/user.panel/'.$top_icons_path.'/menu.png" alt = "Меню">

                             </span>

                         </td>

                         </div>

                         <td class = "lnk nav_conf" id = "transition">

                             <a href="'.HTTP.'/mail/" class = "lnk_l">

                                 <img src = "'.HTTP.'/files/system.images/user.panel/'.$top_icons_path.'/mail.png" alt = "Почта">

                                 <span style = "vertical-align: super;">

                                         '.$countMail.'

                                 </span>

                             </a>

                         </td>
  
                         <td class = "lnk nav_conf" id = "transition">

                             <a href="'.HTTP.'/journal/" class = "lnk_l">

                                 <img src = "'.HTTP.'/files/system.images/user.panel/'.$top_icons_path.'/journal.png" alt = "Журнал">

                                 <span style = "vertical-align: super;">

                                     '.$countJournal.'

                                 </span>

                             </a>

                         </td>    
  
                         <td class = "lnk nav_conf" id = "transition">

                             <a href="'.HTTP.'/lenta" class = "lnk_l">

                                 <img src = "'.HTTP.'/files/system.images/user.panel/'.$top_icons_path.'/lenta.png" alt = "Лента">

                                 <span style = "vertical-align: super;">

                                     '.$countLenta.'

                                 </span>

                             </a>

                         </td>
  
                         <td class = "lnk nav_repl" id = "transition">

                             <a href="'.HTTP.'/uid'.$user['id'].'" class = "lnk_l">

                                 '.User::avatar ($user['id'], 40, 'mini', $avatar_mini_style).'

                             </a>

                         </td>  
  
                     </tr>

                 </tbody>

             </table>
   
         </div>
     ';

 }
 else {
 
     echo '

         <div class="nav_menu" style = "border-bottom: 1px solid #BBC1C3;">

             <table style="width: 100%;" cellspacing="0" cellpadding="0">

                 <tbody>

                     <tr> 

                         <td class = "lnk nav_conf" id = "transition">

                             <a href="'.HTTP.'/files/" class = "lnk_l">

                                 <img src = "'.HTTP.'/files/system.images/site.icons/files_p.png" alt = "Файлы">

                             </a>

                         </td>           

                         <td class = "lnk nav_conf" id = "transition">

                             <a href="'.HTTP.'/dating/" class = "lnk_l">

                                 <img src = "'.HTTP.'/files/system.images/site.icons/love.png" alt = "Знакомства">

                             </a>

                         </td>

                         <td class = "lnk nav_conf" id = "transition">

                             <a href="'.HTTP.'/forum/" class = "lnk_l">

                                 <img src = "'.HTTP.'/files/system.images/site.icons/forum_top_panel.png" alt = "Форум">

                             </a>

                         </td>

                     </tr>

                 </tbody>

             </table>

         </div>

     ';

 }

 if ($user) {
 
     $auth = $DB -> query ("SELECT `status` FROM `history_auth` WHERE `user_id` = '".$user['id']."' ORDER BY `id` DESC LIMIT 1") -> fetch ();

     if ($auth['status'] == 1) {  

        include_once ROOT.'/pages/access_auth/index.php'; 

        include_once ROOT.'/template/footer.php';

        exit; 

    }

     if ($user['level'] > 0) {

         echo '

         <div class = "controll">

             '.(($user['level'] == 1 or $user['level'] == 3) ? '<a href = "'.HTTP.'/files/?check">Файлы ('.$queryNewFiles.')</a>' : '').'

             '.($user['level'] == 1 ? '<br />' : '').'

             '.(($user['level'] == 1 or $user['level'] == 4) ? '<a href = "'.HTTP.'/forum/?list_check">Форум ('.$queryNewForumThemes.')</a>' : '').'
             
             '.($user['level'] == 1 ? '<br />' : '').'

             '.(($user['level'] == 1 or $user['level'] == 5) ? '<a href = "'.HTTP.'/chat/?mod">Чат ('.$countChatRemarks.')</a>' : '').'

         </div>

         ';


     }

 }

?> 