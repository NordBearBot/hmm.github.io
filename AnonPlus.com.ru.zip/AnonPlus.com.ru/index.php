<?php 

 include_once $_SERVER['DOCUMENT_ROOT'].'/Chaincore/class.DB.php';

 $queryListBlog = $DB -> query ("SELECT * FROM `blogs` WHERE `time` > '" . (time() - 60 * 60 * 24 * 1) . "' AND `access` = '0' ORDER BY `view` DESC LIMIT 3"); /* WHERE `time` > '" . (time() - 60 * 60 * 24 * 3) . "' ORDER BY `review` DESC */

 $countPeople = $DB -> query ("SELECT `id` FROM `users`") -> RowCount ();
 $countDating = $DB -> query ("SELECT `id` FROM `users` WHERE `dating` = '1'") -> RowCount ();
 $countBlogs = $DB -> query ("SELECT `id` FROM `blogs` WHERE `access` = '0'") -> RowCount ();
 $countOnline = $DB -> query ("SELECT `id` FROM `users` WHERE `online` > '".$conf['user_online']."'") -> RowCount ();
 $countFiles = $DB -> query ("SELECT `id` FROM `downloads_files`") -> RowCount ();
 $countForumThemes = $DB -> query ("SELECT `id` FROM `forum_themes`") -> RowCount ();

 $chatUserOnline = time()-300;
 $onlineChatUsers = $DB -> query ("SELECT DISTINCT user_id FROM `chat_messages` WHERE `time` > '".$chatUserOnline."'") -> RowCount ();
 
 $keywords = 'Сайт знакомств 2015, сайт онлайн общения, сайт общения, сайт общения и знакомств, сайты общения бесплатные, знакомства и общение, сайт чат знакомств, сайт знакомств и отношений, мобильные сайты бесплатно, веб сайт общения, мобильные сайты игры, знакомства, форум';
 $description = 'Ruswap - это многофункциональный сайт онлайн общения. У нас Вы найдете форум тематических и качественных статей, бесплатный обменник, онлайн чат и новые знакомства';
 $title = DOMAIN.' - твой мобильный сайт общения и знакомств';

 include_once ROOT.'/template/header.php';

 Core::Ok ();
 Core::Error ();
 
 echo '

         <div style = "padding: 9px;" class = "nav box" id = "online_block"><center><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/author.png"> <a class = "online_link" href = "'.HTTP.'/people/?online">Сейчас онлайн: '.$countOnline.'</a></center></div>

         <div class = "block" style = "padding: 15px; border: none; ">

             <table style="width: 100%;">

               <tbody>

                     <tr>

                         <td style="width: 100%;">

                             <input type="text" placeholder="Поиск по сайту" class="search" style="width: 100%; margin-bottom: 15px;">

                         </td>

                         <td>

                             <input type="submit" style = "margin-left: 25px;" class="search_ok">
             
                         </td>

                     </tr> 

                 </tbody>

             </table>

         <div class = "box">

         <a class = "home" href = "'.HTTP.'/dating/">

             <div id = "avatar">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/home.icons/dating.png">

             </div>

             Знакомства

             <span class = "count">

                 '.$countDating.'

             </span>

             <br />

             <small>Найди себе вторую половинку ;)</small>

         </a>

         <a class = "home" href = "'.HTTP.'/files/">

             <div id = "avatar">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/home.icons/files.png">

             </div>

             Файлы

             <span class = "count">

                 '.$countFiles.'

             </span>

             <br />

             <small>Фото, Видео, Игры...</small>

         </a>

         <a class = "home" href = "'.HTTP.'/blogs/">

             <div id = "avatar">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/home.icons/blogs.png">

             </div>

             Блоги

             <span class = "count">

                 '.$countBlogs.'

             </span>

             <br />

             <small>Всё самое интересное!</small>

         </a></div></div>';

 echo '<div class = "block" style = "padding: 5px; border: none;">

             <div class="widgets-group">

                 <div class="b-title b-title_first">

                     <a class="b-title__link" href="'.HTTP.'/blogs/">

                         Интересные блоги</a></div> ';

                 
                 if ($queryListBlog -> RowCount () < 1) echo '<a class="list-link">Записей нет!</a>';
                 else {

                 while ($blog = $queryListBlog -> fetch ()) {

                     $ank = $DB -> query ("SELECT `login` FROM `users` WHERE `id` = '".$blog['user_id']."'") -> fetch ();

                 echo '

                 <div>

                     <a href="'.HTTP.'/uid'.$blog['user_id'].'/blog/?i='.$blog['id'].'" class="list-link">
            
                         <div class="list-link__ava for_avatar">

                             <!-- User::avatar (id, 40) -->
    
                         </div>
            
                         <div class="list-link__descr">

                             <span class="list-link__title">

                                 '.Core::user ($blog['user_id'], 0, 1, 0).'

                                 <small id = "right" class = "time">

                                     '.Core::date_time ($blog['time']).'

                                 </small>

                             </span>
                
                             <div class="list-link__text">

                                 <b>'.Core::CropStr (Core::without_bb($blog['message']), 250).'</b>

                                 <br />

                                 <span class="private_info">

                                     <img src = "'.HTTP.'/files/system.images/site.icons/rss.png"> '.Blog::channel ($blog['id']).'

                                 </span>

                                 <span id = "right" class = "comment_num"><img id = "menu_list" src = "'.HTTP.'/files/system.images/site.icons/comment.png"> '.$blog['comments'].'</span>

                             </div>

                         </div>
 
                     </a>

                 </div>

                 '; 

                 }

                 }
 echo '

             </div>

         </div>

         <div class = "block" style = "padding: 15px; padding-top: 0;">

         <div class = "box">

         <div class="b-title b-title_first">

             <a class="b-title__link" href="'.HTTP.'/blogs/">

                 Общение

             </a>

         </div>

         <a class = "home" href = "'.HTTP.'/forum/">

             <div id = "avatar">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/home.icons/forum.png">

             </div>

             Форум

             <span class = "count">

                 '.$countForumThemes.'

             </span>

             <br />

             <small>Обсуждения интерестных тем.</small>

         </a>

         <a class = "home" href = "'.HTTP.'/chat/">

             <div id = "avatar">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/home.icons/chat.png">

             </div>

             Чат

             <span class = "count">

                 '.$onlineChatUsers.' онлайн

             </span>

             <br />

             <small>Общайтесь с друзьями вместе ;)</small>

         </a>

         <a class = "home" href = "'.HTTP.'/people/">

             <div id = "avatar">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/home.icons/comm.png">

             </div>

             Сообщества

             <span class = "count">

                 0

             </span>

             <br />

             <small>Здесь всегда весело)</small>

         </a>

         <a class = "home" href = "'.HTTP.'/people/">

             <div id = "avatar">

                 <img id = "menu_list" src = "'.HTTP.'/files/system.images/home.icons/people.png">

             </div>

             Пользователи

             <span class = "count">

                 '.$countPeople.'

             </span>

             <br />

             <small>Найди себе друзей ;)</small>

         </a>

         </div>

             <table style="width: 100%; margin-top: 15px;">

               <tbody>

                     <tr>

                         <td style="width: 100%;">

                             <input type="text" placeholder="Поиск по сайту" class="search" style="width: 100%; margin-bottom:10px;">

                         </td>

                         <td>

                             <input type="submit" style = "margin-left: 25px;" class="search_ok">
             
                         </td>

                     </tr> 

                 </tbody>

             </table>

         </div>';

 echo '<div class = "title"><a href = "'.HTTP.'/"><span class = "ico home-link"></span></a><span class = "ico next"></span>Ruswap</div>';

 include_once ROOT.'/template/footer.php';

?>